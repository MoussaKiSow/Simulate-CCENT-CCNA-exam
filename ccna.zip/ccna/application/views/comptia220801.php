<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="author" content="e-smartsolution.co.uk">
<title>Practice ICND2 v3.0(200-105)- Cisco, CCNA certificate</title>
<meta name="description" 
 content="Practice the CCNA,ICND2, version 3.0, Interconnecting Cisco Networking Devices part 2, 200-105. Cisco Certified Networking Assotiate,The CCNA v3.0 is the latest iteration,for the accelerated path to the hugely popular certification, the Cisco Certified Network Associate (CCNA)" />
 <meta name="keywords" content="Cisco, CCNA,CCENT, Certified, Network, Associate,wifi, wireless,switch, router, certification, hub, repeater, english, test, practise, practice, Interconnecting,devices,networking, version3.0, v3.0, free, online, pass" />
<meta content='index, follow' name='robots'/>
<meta http-equiv="Cache-Control" content="no-cache, no-store, must-revalidate" />
<meta http-equiv="Pragma" content="no-cache" />
<meta http-equiv="Expires" content="0" />

<link href="<?=base_url()?>exam/css/style.css" rel="stylesheet">
<link rel='stylesheet' id='crafty-social-buttons-styles-css' 
 href='http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/css/public.min.css?ver=1.3.2' type='text/css' media='all' />
<script type="text/javascript">
	
function ActiverConfirm(){ 
	document.getElementById("btnexam1").disabled=false;
	}
	
	
function ConfirmAnswer(){
	//alert(1);
	var yourans= new Array();var j=0;
	for(var i=1;i<=4;i++){
	if(document.getElementById("Reponse"+i).checked){	
		yourans[j]=i;
		j=j+1;	
	}}
		// active the option to confirm anwser
		//alert(yourans);
		var par={"Respuesta":yourans};
		var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
		$.ajax({
			data:par,
			url:url,
			type:'post',
			beforeSend:function(){
				 $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
				},
			success:function(result){
				//alert("ok");
				$("#PracticeExam").html(result);
				//alert("new question");
				
				document.getElementById('btnexam2').style.display='block';//continue button
				document.getElementById('btnexam1').style.display='none';//confirm an
				}
			});
		
	
	}
	
 function StartPratice(){
	var url='<?=base_url()?>index.php/Praticecomptianetworkn1006ajax';
	var i=eval(document.getElementById("currentprize").value);
	var par={"currentprize":i};
			$.ajax({
		data:par,
		url:url,
		type:'post',
		beforeSend:function(){
		  $("#PracticeExam").html('<img src="<?=base_url()?>exam/img/loader.gif" class="loadoing">');
			},
		success:function(result){
		 document.getElementById("btnexam").style.display="none";
		 document.getElementById("btnexam1").style.display="block";
		 document.getElementById("btnexam1").disabled=true;
		 document.getElementById('btnexam2').style.display='none';//continue button
		 
			$("#PracticeExam").html(result);
			}
		});
  }
  
  function MaReponse(id){
	  document.getElementById("Reponse"+id).checked=true;
	  ActiverConfirm();
	  }
    </script>
    <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<script>
  (adsbygoogle = window.adsbygoogle || []).push({
    google_ad_client: "ca-pub-8270364899437567",
    enable_page_level_ads: true
  });
</script>
    </head>
    <body >
        
        <div class="wrapper">
            <header>
	            <div class="e-smartsolution-bar">
		            <a href="http://www.e-smartsolution.co.uk" class="logo" id="logo">
					<img alt="e-smartsolution.co.uk" src="<?=base_url()?>/exam/img/esmartsolution-logo.png" width="250" height="70">
		            </a>
		            
                    <div class="app-name">
                  <h5> Practice the Cisco ICND2 v3.0(200-105) exam.</h5>
                    </div>
                    
                    
	            </div>
	   
            
	            <div class="app-bar">
<span>ICND2 is the CCNA v3.0 is the latest iteration, for the accelerated path to the hugely popular certification, the Cisco Certified Network Associate (CCNA). <br>
<a href="http://www.e-smartsolution.co.uk/comptia220801/" 
 title="Pratice Comptia A+ 220-801" target="_blanck">
	Comptia A+ 220-801</a> |
 <a href="http://www.e-smartsolution.co.uk/comptia220802/" 
 title="Pratice Comptia A+ 220-802" target="_blanck">
	Comptia A+ 220-802</a> |
 <a href="http://www.e-smartsolution.co.uk/comptianetworkn10006/" 
 title="Pratice Comptia Network plus N10-006" target="_blanck">
	Comptia Network+</a>
	|
	
 <a href="http://www.e-smartsolution.co.uk/ccent/" 
 title="Pratice Cisco CCENT, ICND1 v3.0, 100-105" target="_blanck">
	CCENT</a>|
	<a href="http://www.e-smartsolution.co.uk/ccna/" 
 title="Pratice Cisco CCNA, ICND2 v3.0, 200-115" target="_blanck">
	CCNA</a>|
	
 <a href="http://www.e-smartsolution.co.uk" >e-smartsolution</a> |<a href="http://www.e-smartsolution.co.uk/blog" 
 target="_blanck" title="The blog of e-smartsolution.co.uk">Blog</a>|
 <a href="http://www.e-smartsolution.co.uk/contact" title="Contact e-smartsolution team">Contact us</a>   </span>
	            </div><!--//app-bar-->
            </header>
            <section class="main-content">

                <div class="page">
					

            <div class="primary">
	  <form action="<?=base_url()?>index.php/praticecomptia220801ajax" method="POST">                  
	<div class="exam" id="PracticeExam">
		<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Comptia220801 -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="3996032533"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
        <h5><?= $question?> </h5>
        <div class="rules-box">
            <ul class="rules-list">
                <li class="rule-item ">
                <?=$ans1?>
                </li>
                <li class="rule-item">
                <?=$ans2?>
                </li>
                 <li class="rule-item">
                <?=$note?>
                </li>
                 <li class="rule-item">
                <?=$rules?>
                </li>
            </ul>
        </div>
       
        </div>
		<!--//rules-box-->
		<input type="hidden" name="currentprize" id="currentprize" value='1'>
		<input type="button" value="Begin Test" onClick="javascript:StartPratice();" class="start-exam" id="btnexam">
		<input type="button" value="Done" onClick="javascript:ConfirmAnswer();" class="confirm-your" id="btnexam1" disabled>
		<input type="button" value="Continue" onClick="javascript:StartPratice();" class="continue-exam" id="btnexam2">
		
	</form>
	<br>
	<b>Keep in mind:</b><br>
 Multiple Choice (single and multiple answer), Drag-and-Drop, Simulations, Simlets, and Testlets.
 The cisco version 3.0 exam codes are 100-105 (ICND1), 200-105 (ICND2), 200-125 (CCNA). You may earn the CCNA certification by passing the 100-105, earning the CCENT, and then passing the 200-105 to upgrade to the full CCNA. Alternatively, you can pass the 200-125 composite exam to earn the full CCNA(<a href="http://e-smartsolution.co.uk/blog/3152-the-exam-topics-cisco-ccna-icnd2-v3-0-200-205/" title="The Exam Topics CISCO CCNA - ICND2 v3.0, 200-205" target="_blanck">List of topics</a>).
	<br>
	<div class="crafty-social-buttons crafty-social-share-buttons crafty-social-buttons-size-2 crafty-social-buttons-align-left crafty-social-buttons-caption-inline-block"><span class="crafty-social-caption">Share this, now:</span><ul class="crafty-social-buttons-list"><li>
						<a target="_blank" title="Share via Facebook" class="crafty-social-button csb-facebook" 
						href="http://www.facebook.com/sharer/sharer.php?u=http://e-smartsolution.co.uk/ccna"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/facebook.png" alt="Share via Facebook" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Google" class="crafty-social-button csb-google" href="https://plus.google.com/share?url=http://e-smartsolution.co.uk/ccna"><img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/google.png" alt="Share via Google" class="crafty-social-button-image"></a></li>
						<li><a target="_blank" title="Share via Twitter" class="crafty-social-button csb-twitter" href="http://twitter.com/share?url=http://e-smartsolution.co.uk/ccna/&amp;text=Practice the Cisco CCNA, ICND2 v3.0(200-105) exam online and free">
							<img width="24" height="24" src="http://e-smartsolution.co.uk/blog/wp-content/plugins/crafty-social-buttons/buttons/simple/twitter.png" alt="Share via Twitter" class="crafty-social-button-image"></a></li></ul></div>
		            <br>
		            <script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Comptia202801body -->
<ins class="adsbygoogle"
     style="display:block"
     data-ad-client="ca-pub-8270364899437567"
     data-ad-slot="5472765734"
     data-ad-format="auto"></ins>
<script>
(adsbygoogle = window.adsbygoogle || []).push({});
</script>
            <br>
 <span>
	 Google exams certifications:
<a class="active" href="http://www.e-smartsolution.co.uk/adwords/index.php" title="Practice Google Fundamental &Search advertising exam">Search</a>

 |<a href="http://www.e-smartsolution.co.uk/adwords/index.php?exam=display" title="Practice Google Display advertising exam">Display</a>
| <a href="http://www.e-smartsolution.co.uk/adwords/index.php?exam=video" title="Practice Google Video advertising exam">Video</a>
 |<a href="http://www.e-smartsolution.co.uk/adwords/index.php?exam=shopping" title="Practice Google Shopping advertising exam">Shopping</a>
 |<a href="http://www.e-smartsolution.co.uk/adwords/index.php?exam=mobile" title="Practice Google Mobile advertising exam">Mobile</a>
 </span>        </div><!--//primary-->

                </div><!--//page-->
            </section>
            
        </div><!--//wrapper-->
		<footer class="footer ">
		    
            <ul class="footer-links-list copyright">
                <li>© 2017 e-smartsolution</li>
            </ul>
			<div class="footer-bar"></div>
		</footer><!--//footer-->
       
    
 <!-- Core JavaScript Files -->
    <script async src="<?=base_url()?>exam/js/jquery.min.js"></script>
   

    
  <script type="text/javascript">
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-56329108-1', 'auto');
  ga('send', 'pageview');

</script>
    

</body></html>
