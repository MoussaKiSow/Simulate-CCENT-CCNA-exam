<?php
$config['protocol'] = 'smtp';
$config['smtp_host'] = 'webcloud3.uk.syrahost.com';
$config['smtp_user'] = 'info@e-smartsolution.co.uk';
$config['smtp_pass'] = 'b€b@1_%Pe?y986';
$config['wordwrap'] = TRUE;
