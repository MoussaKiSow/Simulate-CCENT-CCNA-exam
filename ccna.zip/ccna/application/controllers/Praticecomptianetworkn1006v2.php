<?php

class Praticecomptianetworkn1006v2 extends CI_Controller{
	
	public function index(){
	
	//$this->load->library('session');
	//$this->load->database();	
	/*We need a function to calculate the question but now get only the fist*/
    $this->load->driver('session');
  if(!$this->session->userdata('CurrentQuestion')){
	  $Questionsshowed=array();
    $new_data=array("NewQuestion"=>0,"CurrentQuestion"=>1,"TotalQuestions"=>100,"ToPass"=>85,"Questionsshowed"=>$Questionsshowed
    ,"CorrectAnswer"=>0);
    $this->session->set_userdata($new_data);
 }
  $this->session->set_userdata("TotalQuestions",100);
   if($_GET['see_session']){
	   print "session<pre>";print_r($this->session->userdata());//exit;
	   
	   }
   
    $data['question']='Click on the below button <b>"Begin Test" </b> to start practice CISCO CCENT(ICND1 v3.0) exam';
    $data['ans1']='45-55 questions. Is not applied, you can stop when you want!';
    $data['ans2']='Passing Score 	100-105 : 800-850 out of 1000 possible points';
    $data['note']='Time limit:90 minutes';
    $data['rules']="This is only e-smartsolution's CISCO CCENT(ICND1 v3.0) practice web. Find out more in
    <a href='http://www.cisco.com/c/en/us/training-events/training-certifications/exam-tutorial.html' target='_blanck'>Cisco Certification Exam Tutorial</a> 
    A composite exam may be substituted for the ICND1 and ICND2 exams in order to achieve CCNA in one step. This path is considered very difficult, but students that are interested should check out the Exam Profile for 200-125 CCNA v3.0.";
	//print "<pre>";print_r($data);
	$this->load->view("comptia220801v2",$data);
	}
	
	
		
	
}
