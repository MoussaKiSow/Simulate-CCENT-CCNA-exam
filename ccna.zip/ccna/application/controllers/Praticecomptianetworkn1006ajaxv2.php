<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
/**
 * we id of the question and name the player
 * 
 * */


class Praticecomptianetworkn1006ajaxv2 extends CI_Controller{
	
	public function index(){

	    $this->load->database();
	    $this->load->library('session');
	    $classokorno1='class="answer"';$classokorno2='class="answer"';
	    $classokorno3='class="answer"';$classokorno4='class="answer"';
	    
	   //by get to tes 8/10/2016
	   if(@$_GET['TestQ'])
	   $TestQ=$_GET['TestQ'];
	   
      
  $this->isradio='radio';//by default, to check answer is changed to hidden
	  if(@$_POST['Respuesta']) {
		   $queq=$this->session->userdata("IdQuestion");
		 //print "<pre>";print_r($this->session->userdata('CorrectNumber'));
	
		  $queq=$this->session->userdata("IdQuestion");
		  $goodresp=$this->session->userdata('CorrectNumber');
		  /*Reset*/
		 // print "Entroaca<pre>";print_r($_POST);//exit;
          //print "idQ".$this->session->userdata('IdQuestion');
 
		  $numeropregunta=$this->session->userdata('CurrentQuestion')+1; //add number of question
		  $this->session->set_userdata('CurrentQuestion',$numeropregunta);

				// print "<pre>";print_r($goodresp);
                   $j=0;
				  for($i=0;$i<count($_POST[Respuesta]);$i++){
					  if(in_array($_POST['Respuesta'][$i],$goodresp)){
							$j++;
							  switch($_POST['Respuesta'][$i]){
							   case 1:
								   $classokorno1='class="GoodRespuesta"';
								   break;
									case 2:
								   $classokorno2='class="GoodRespuesta"';
								   break;
									case 3:
								   $classokorno3='class="GoodRespuesta"';
								   break;
									case 4:
								   $classokorno4='class="GoodRespuesta"';
								   break;
								   case 5:
								   $classokorno5='class="GoodRespuesta"';
								   break;
								   case 6:
								   $classokorno6='class="GoodRespuesta"';
								   break;
								   case 7:
								   $classokorno7='class="GoodRespuesta"';
								   break;
								   case 8:
								   $classokorno8='class="GoodRespuesta"';
								   break;
								}
							  
						  }else{
							 
						 switch($_POST['Respuesta'][$i]){
						   case 1:
							   $classokorno1='class="BadRespuesta"';
							   break;
								case 2:
							   $classokorno2='class="BadRespuesta"';
							   break;
								case 3:
							  $classokorno3='class="BadRespuesta"';
							   break;
								case 4:
							   $classokorno4='class="BadRespuesta"';
							   break;
							   case 5:
							   $classokorno5='class="BadRespuesta"';
							   break;
							   case 6:
							   $classokorno6='class="BadRespuesta"';
							   break;
							   case 7:
							   $classokorno7='class="BadRespuesta"';
							   break;
							   case 8:
							   $classokorno8='class="BadRespuesta"';
							   break;
							 }
								   
						 }
							 
					  }
					  if($j>0){
								  $ok=$this->session->userdata('CorrectAnswer')+1;
			                      $this->session->set_userdata('CorrectAnswer',$ok);
						 }
						 
						// marque anyway the good answer
						for($i=0;$i<count($goodresp);$i++){
							  switch($goodresp[$i]){
							   case 1:
								   $classokorno1='class="GoodRespuesta"';
								   break;
									case 2:
								   $classokorno2='class="GoodRespuesta"';
								   break;
									case 3:
								   $classokorno3='class="GoodRespuesta"';
								   break;
									case 4:
								   $classokorno4='class="GoodRespuesta"';
								   break;
								   case 5:
								   $classokorno5='class="GoodRespuesta"';
								   break;
								   case 6:
								   $classokorno6='class="GoodRespuesta"';
								   break;
								   case 7:
								   $classokorno7='class="GoodRespuesta"';
								   break;
								   case 8:
								   $classokorno8='class="GoodRespuesta"';
								   break;
								}	  
						  }
						  
								 
					  //print "<br>class".$classokorno.$_POST['Respuesta'][$i];
				  			  
		  $q=$this->getQuestion($queq);//print "Question".$q;
		  $this->isRadio='hidden';
		  
	      $answers=$this->getAnswser($queq);
	      
		  }else {	 
			  if(!$TestQ)
			$queq=$this->loteriaQ(1,"Questionsccna");
			else
			$queq=$TestQ;
			
			$queq=66;
			
			$lastQuestions=$this->session->userdata('Questionsshowed');
			
		  array_push($lastQuestions,$queq);
		   $this->session->set_userdata('Questionsshowed',$lastQuestions);
			$this->session->set_userdata('IdQuestion',$queq);
		   // print "<br>id question".$queq;//exit;
			//$queq=72;// pregunta text
			$q=$this->getQuestion($queq);//print "Question".$q;
			$answers=$this->getAnswser($queq);
		 //  print "<pre>";print_r($this->session->userdata('IdQuestion'));//exit;
		   //get t
		 //  print "<br>i".$this->isRadio;
		    if($this->isRadio==2)$this->isRadio='checkbox';elseif($this->isRadio==1)$this->isRadio='radio';else $this->isRadio='hidden';
		  // print "<br>".$this->isRadio;
		 // die("Enter here lotery questions::".$queq);
		   
	   }
	 //print "<br>".$this->isRadio;
	     $url=$this->getURL($queq);
		  if($url)$pregunta='<a href="'.$url.'" title="'.$url.'" classs="aquestion" target="_blanck">'.$q.'</a>';
		  else $pregunta=$q;
		  
		
	//calculate percentage of correct answer
	$numeropregunta=$this->session->userdata('CurrentQuestion');
	$ok=$this->session->userdata('CorrectAnswer');
	$totalq=$this->session->userdata('TotalQuestions');
	  
		  $isPass=number_format(($ok/$totalq*100),0);//number of ok answer divided by the total question 
		 // $totaldone=number_format($numeropregunta/$totalq);
		//print "<br>Is pass".$isPass;
		
	//echo("numeropregunta".$numeropregunta."total q".$totalq);	
	if($numeropregunta<=$this->session->userdata('TotalQuestions'))  {
	   echo'<div class="primary" id="PracticeExam">
        <h4>'.$this->session->userdata('CurrentQuestion').' '.$pregunta.'</h4>
        <div class="rules-box">
            <ul class="rules-list">';
            $k=1;
            for($i=0;$i<count($answers);$i++){
				
				echo'<li '.$classokorno.$k.'>
                <input type="'.$this->isRadio.'" name="Reponse'.$k.'"  id="Reponse'.$k.'"  value="'.$k.'" onClick="javascript:ActiverConfirm();">
                <span class="possible-answer"><a href="javascript:MaReponse('.$k.');" class="MiRespuesta">'.$answers[$i][1].'</a>
                </span></li>';
                $k++;
				}
               /* <li '.$classokorno1.'>
                <input type="'.$this->isRadio.'" name="reponse" id="Reponse1" value="1" onClick="javascript:ActiverConfirm();">
                <span class="possible-answer"><a href="javascript:MaReponse(1);" class="MiRespuesta">'.$answers[0][1].'</a>
                </span></li>
                <li '.$classokorno2.'>
                 <input type="'.$this->isRadio.'" name="reponse" id="Reponse2" value="2" onClick="javascript:ActiverConfirm();">
                 <span class="possible-answer"><a href="javascript:MaReponse(2);" class="MiRespuesta">'.$answers[1][1].'</a></span>
                </li>
                 <li '.$classokorno3.'>
                 <input type="'.$this->isRadio.'" name="reponse" id="Reponse3" value="3" onClick="javascript:ActiverConfirm();">
                 <span class="possible-answer"><a href="javascript:MaReponse(3);" class="MiRespuesta">'.$answers[2][1].'</a></span>
                </li>
                 <li '.$classokorno4.'>
                 <input type="'.$this->isRadio.'" name="reponse" id="Reponse4" value="4" onClick="javascript:ActiverConfirm();">
                 <span class="possible-answer"><a href="javascript:MaReponse(4);" class="MiRespuesta">'.$answers[3][1].'</a></span>
                </li>
                 </li>*/
                echo' <li class="result">
        
                 <span class="result-test">Ok answer&nbsp;<strong>'.$ok.'</strong>&nbsp;of&nbsp;<strong>'.$totalq.'</strong> </span>
                 <progress value="'.$ok.'" min="1"  max="'.$totalq.'">'.$isPass.'</progress>('.$isPass.'%)
                </li>
            </ul>
        </div>';
	}else{
		$this->session->set_userdata("CurrentQuestion",0); // reset the total questions
		echo'<div class="primary" id="PracticeExam">
        <h4>You got '.$ok.'/'.$totalq.' questions correct('.$isPass.'%)</h4>
        <div class="rules-box">
            <ul class="rules-list">
                <li class="fin">
                 The passing Score of 100-105 : 800-850 out of 1000 possible points, to pass the cicsco, CCENT, You can retest again!
                </li>
               
            </ul>
        </div>';
		
		}    
	    
	    exit();

			
}
public function getQuestion($id){
	

	$this->db->select('Code,Description,Type');
	$query=$this->db->get_where('Questionsccna',array('Code'=>$id));
	$row=$query->row_array();
	$this->isRadio=$row['Type'];
	//die("Entro aca");
	return htmlentities($row['Description']);	
	}
	

	public function getAnswser($q){
		$answers=array();$okresp=array();
		$this->db->select('id,Answer,Ok_answer,id_answer');
		$this->db->order_by('id_Answer');
		$query=$this->db->get_where("QuestionsAnswersccna",array("id_question"=>$q));
		foreach($query->result_array() as $row){
		$id=$row['id'];
		$answer=htmlentities($row['Answer']);
		$ok=$row['Ok_answer'];
		$id_an=$row['id_answer'];
		if($ok=='1'){
			// that's the correct anwser
			
			array_push($okresp,$id_an);
			 $this->session->set_userdata("CorrectNumber",$okresp);
	   // print "function pregunta".$q."<pre>";print_r($this->session->userdata("CorrectNumber"));//exit;
			
			}
		array_push($answers,array($id,$answer,$ok));
	    } 
	    $this->session->set_userdata("CorrectNumber",$okresp);
	    //print "function<pre>";print_r($this->session->userdata("CorrectNumber"));//exit;
		return $answers;
	}
	

public function loteriaQ($min,$table){
	
	$idQdb=$this->lotoQuestionDB();
	if($idQdb==0){
		$this->db->like('status_mobile','01');
		$this->db->from($table);
		$total=$this->db->count_all_results(); 
		//print("<br>Total".$total);
		$yourq=$this->session->userdata("Questionsshowed");
		//print "<pre>";print_r($yourq);
		// check if the question is showed before to the user count($yourq)==0||(in_array($numeropregunta,$yourq)||($i<=$total))
		$i=0;$numeropregunta=rand($min,$total);
	}else{ 
	$numeropregunta=$idQdb; //echo "<br>By db".$idQdb;
  }
	$thiscodexists=$this->thenumberQexists($numeropregunta);
    if($thiscodexists!=$numeropregunta){
	while(in_array($numeropregunta,$yourq)&&$i<$total){
		if($thiscodexists!=$numeropregunta){
		 $numeropregunta=$this->lotoQuestionDB();// in case the loto by DB is not working
	    if($numeropregunta==0) $numeropregunta=rand($min,$total);
	     $thiscodexists=$this->thenumberQexists($numeropregunta);
	     $i++;//print "<br>i es".$i;
       }
	}}
	
	
   //print "<br>current question".$numeropregunta;exit;
   
	return $numeropregunta;
	
	}
	
	public function thenumberQexists($numeropregunta){
		
		$pregdb='';
	 $this->db->select('Code,Description,Type');
	$query=$this->db->get_where('Questionsccna',array('Code'=>$numeropregunta));
	$row=$query->row_array();
	$pregdb=$row['Code'];
	return $pregdb;
	
  }

public function getURL($queq){
	//print "<br>Idquestion".$queq;
	$this->db->select("Url");
	$url='';
	$query=$this->db->get_where("Questionsccna",array('Code'=>$queq));
	if($query->num_rows()>0){
		$row=$query->row_array();
		//print "<pre>";print_r($row);exit;
		$alias=$row['Url'];
		$url=$alias; 
	}
	return $url;
	}
	
public function checkUrl($url){
	if(@file_get_contents($url,0,null,0,1))
	return 1;
	else return 0;
	}
	

	
public function saveuserinfo($_userinfo){
	//print "<pre>";print_r($_userinfo);exit;
	$info=$this->db->insert('users_session',$_userinfo);
	//die("save---".$info);
	
	}

public function getIdsession($id){
	$this->db->select("session_id");
	$query=$this->db->get_where("users_session",array("session_id"=>$id));
	$row=$query->row_array();
	if($row['session_id']==$id)return 1;
	else return 0;
	}
	
	
 public function lotoQuestionDB(){
	 $_sql="SELECT Code FROM Questionsccna ORDER BY RAND() DESC LIMIT 0,1";
	 //print "<br>".$_sql;
	 $query=$this->db->query($_sql);
	 if($query->num_rows()>0){
	 $row=$query->row_array();
	 return $row['Code'];
      }
      else return 0;
	 }
}
