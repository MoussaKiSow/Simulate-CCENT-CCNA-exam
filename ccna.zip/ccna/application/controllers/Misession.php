<?php
header("Cache-Control: no-store, no-cache, must-revalidate");
/**
 * we id of the question and name the player
 * 
 * */
 
class Misession extends CI_Controller{
	
	public function index(){


	    $this->load->library('session');
	   
	    $queq=$this->session->userdata("IdQuestion");
		 print "Session<pre>";print_r($this->session->userdata());
		 
		 $yourq=$this->session->userdata("Questionsshowed");
		 if(!in_array($queq,$yourq)) echo "No existe";
		 echo 'Existe';

}}
?>
