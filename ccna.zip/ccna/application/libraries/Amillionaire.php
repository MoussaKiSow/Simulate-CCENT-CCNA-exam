<?php
if(!define(BASEPATH) die("Not directed access allow");
class Amillionaire {
	
public function getQuestion($id){
	$this->db->select('Code,Description');
	$query=$this->db->get_where('Questions',array('id'=>$id));
	$row=$query->row_array();
	return $row['Description'];	
	}
	
	public function getAnswser($q){
		$answers=array();
		$this->db->select('id,Answer');
		$this->db->order_by('id_Answer');
		$query=$this->db->get_where("QuestionsAnswers",array("id_question"=>$q));
		foreach($query->result_array() as $row){
		$id=$row['id'];
		$answer=$row['Answer'];
		array_push($answers,array($id,$answer));
	    }
		return $answers;
	}
	

public function loteriaQ($min,$table){
	$total=$this->db->count_all($table); 
	$numeropregunta=rand($min,$total);
	return $numeropregunta;
	}
	
	
public function checkanwser($quest,$answer){
	$this->db->select("id,Answer,Ok_answer");
	$query=$this->db->get_where("QuestionsAnswers",array("id_question"=>$quest,"Ok_answer"=>"1"));
	if($query->num_rows()>0){
		$row=$query->row_array();
		//print"<pre>";print_r($row);
			$idanswerok=$row['id'];
	 }
	return $idanswerok;
 }
 

public function getURL($queq){
	//print "<br>Idquestion".$queq;
	$this->db->select("alias");
	$query=$this->db->get_where("jos_content",array('idQuestion'=>$queq));
	if($query->num_rows()>0){
		$row=$query->row_array();
		//print "<pre>";print_r($row);exit;
		$url=$row['alias']; 
	}
	return $url;
	}
	
public function getPrizes($lan){
		$prizes=array();
		$this->db->select('Code,Canquit,Description');
		$this->db->order_by('Id',"DESC");
		$query=$this->db->get_where('Prizes',array('Language'=>$lan));
		
		if($query->num_rows()>0){
			foreach($query->result_array() as $row){
				$des=$row['Description'];
				$canquit=$row['Canquit'];
				$code=$row['Code'];
				array_push($prizes,array($code,$canquit,$des));	
				}
			}
	//	print "<pre>";print_r($prizes);
		return $prizes;
		
	}
}
?>
