<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-15 11:07:25 --> Config Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:07:25 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:07:25 --> URI Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Router Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Output Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Security Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Input Class Initialized
DEBUG - 2015-02-15 11:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:07:25 --> Language Class Initialized
ERROR - 2015-02-15 11:07:25 --> 404 Page Not Found: /index
DEBUG - 2015-02-15 11:07:28 --> Config Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:07:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:07:28 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:07:28 --> URI Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Router Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Output Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Security Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Input Class Initialized
DEBUG - 2015-02-15 11:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:07:28 --> Language Class Initialized
ERROR - 2015-02-15 11:07:28 --> 404 Page Not Found: /index
DEBUG - 2015-02-15 11:07:40 --> Config Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:07:40 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:07:40 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:07:40 --> URI Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Router Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Output Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Security Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Input Class Initialized
DEBUG - 2015-02-15 11:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:07:40 --> Language Class Initialized
ERROR - 2015-02-15 11:07:40 --> 404 Page Not Found: /index
DEBUG - 2015-02-15 11:08:12 --> Config Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:08:12 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:08:12 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:08:12 --> URI Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Router Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Output Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Security Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Input Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:08:12 --> Language Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Loader Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:08:12 --> Controller Class Initialized
DEBUG - 2015-02-15 11:08:12 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:08:12 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-02-15 11:08:12 --> Final output sent to browser
DEBUG - 2015-02-15 11:08:12 --> Total execution time: 0.1874
DEBUG - 2015-02-15 11:08:18 --> Config Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:08:18 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:08:18 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:08:18 --> URI Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Router Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Output Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Security Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Input Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:08:18 --> Language Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Loader Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:08:18 --> Controller Class Initialized
DEBUG - 2015-02-15 11:08:18 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:08:18 --> CI_Session Class Initialized
ERROR - 2015-02-15 11:08:18 --> Session: HMAC mismatch. The session cookie data did not match what was expected.
DEBUG - 2015-02-15 11:08:18 --> Session: Creating new session (9c81b715f4bf0aefb8b79f6c01a4313c)
DEBUG - 2015-02-15 11:08:18 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:08:18 --> User Agent Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Config Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:08:26 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:08:26 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:08:26 --> URI Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Router Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Output Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Security Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Input Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:08:26 --> Language Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Loader Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:08:26 --> Controller Class Initialized
DEBUG - 2015-02-15 11:08:26 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:08:26 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:08:26 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:08:26 --> Final output sent to browser
DEBUG - 2015-02-15 11:08:26 --> Total execution time: 0.0443
DEBUG - 2015-02-15 11:08:28 --> Config Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:08:28 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:08:28 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:08:28 --> URI Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Router Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Output Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Security Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Input Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:08:28 --> Language Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Loader Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:08:28 --> Controller Class Initialized
DEBUG - 2015-02-15 11:08:28 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:08:28 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:08:28 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:08:28 --> Final output sent to browser
DEBUG - 2015-02-15 11:08:28 --> Total execution time: 0.0076
DEBUG - 2015-02-15 11:08:31 --> Config Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Hooks Class Initialized
DEBUG - 2015-02-15 11:08:31 --> UTF-8 Support Enabled
DEBUG - 2015-02-15 11:08:31 --> Utf8 Class Initialized
DEBUG - 2015-02-15 11:08:31 --> URI Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Router Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Output Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Security Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Input Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-15 11:08:31 --> Language Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Loader Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Helper loaded: url_helper
DEBUG - 2015-02-15 11:08:31 --> Controller Class Initialized
DEBUG - 2015-02-15 11:08:31 --> Database Driver Class Initialized
DEBUG - 2015-02-15 11:08:31 --> CI_Session Class Initialized
DEBUG - 2015-02-15 11:08:31 --> CI_Session routines successfully run
DEBUG - 2015-02-15 11:08:31 --> Final output sent to browser
DEBUG - 2015-02-15 11:08:31 --> Total execution time: 0.0059
