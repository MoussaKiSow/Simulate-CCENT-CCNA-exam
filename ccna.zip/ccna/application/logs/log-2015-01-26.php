<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-26 21:25:41 --> Config Class Initialized
DEBUG - 2015-01-26 21:25:41 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:25:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:25:41 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:25:42 --> URI Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Router Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Output Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Security Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Input Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:25:42 --> Language Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Loader Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:25:42 --> Controller Class Initialized
DEBUG - 2015-01-26 21:25:42 --> Database Driver Class Initialized
DEBUG - 2015-01-26 21:25:42 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-26 21:25:42 --> Final output sent to browser
DEBUG - 2015-01-26 21:25:42 --> Total execution time: 0.2716
DEBUG - 2015-01-26 21:25:45 --> Config Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:25:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:25:45 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:25:45 --> URI Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Router Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Output Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Security Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Input Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:25:45 --> Language Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Loader Class Initialized
DEBUG - 2015-01-26 21:25:45 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:25:45 --> Controller Class Initialized
DEBUG - 2015-01-26 21:25:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-26 21:25:45 --> Final output sent to browser
DEBUG - 2015-01-26 21:25:45 --> Total execution time: 0.0227
DEBUG - 2015-01-26 21:27:26 --> Config Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:27:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:27:26 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:27:26 --> URI Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Router Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Output Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Security Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Input Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:27:26 --> Language Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Loader Class Initialized
DEBUG - 2015-01-26 21:27:26 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:27:26 --> Controller Class Initialized
DEBUG - 2015-01-26 21:27:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-26 21:27:26 --> Final output sent to browser
DEBUG - 2015-01-26 21:27:26 --> Total execution time: 0.0057
DEBUG - 2015-01-26 21:27:27 --> Config Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:27:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:27:27 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:27:27 --> URI Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Router Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Output Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Security Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Input Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:27:27 --> Language Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Loader Class Initialized
DEBUG - 2015-01-26 21:27:27 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:27:27 --> Controller Class Initialized
DEBUG - 2015-01-26 21:27:27 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-26 21:27:27 --> Final output sent to browser
DEBUG - 2015-01-26 21:27:27 --> Total execution time: 0.0019
DEBUG - 2015-01-26 21:30:03 --> Config Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:30:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:30:03 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:30:03 --> URI Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Router Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Output Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Security Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Input Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:30:03 --> Language Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Loader Class Initialized
DEBUG - 2015-01-26 21:30:03 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:30:03 --> Controller Class Initialized
ERROR - 2015-01-26 21:30:03 --> Severity: Notice --> Undefined variable: Prizes /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php 350
ERROR - 2015-01-26 21:30:03 --> Severity: Warning --> Invalid argument supplied for foreach() /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php 350
DEBUG - 2015-01-26 21:30:03 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-26 21:30:03 --> Final output sent to browser
DEBUG - 2015-01-26 21:30:03 --> Total execution time: 0.0371
DEBUG - 2015-01-26 21:33:45 --> Config Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Hooks Class Initialized
DEBUG - 2015-01-26 21:33:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-26 21:33:45 --> Utf8 Class Initialized
DEBUG - 2015-01-26 21:33:45 --> URI Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Router Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Output Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Security Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Input Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-26 21:33:45 --> Language Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Loader Class Initialized
DEBUG - 2015-01-26 21:33:45 --> Helper loaded: url_helper
DEBUG - 2015-01-26 21:33:45 --> Controller Class Initialized
DEBUG - 2015-01-26 21:33:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-26 21:33:45 --> Final output sent to browser
DEBUG - 2015-01-26 21:33:45 --> Total execution time: 0.0086
