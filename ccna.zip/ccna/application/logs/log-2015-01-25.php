<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-25 09:26:15 --> Config Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:26:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:26:15 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:26:15 --> URI Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Router Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Output Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Security Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Input Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:26:15 --> Language Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Loader Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:26:15 --> Controller Class Initialized
DEBUG - 2015-01-25 09:26:15 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:26:15 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:26:15 --> A session cookie was not found.
DEBUG - 2015-01-25 09:26:15 --> Session: Creating new session (37729dcffb7d4959ba412496129feab9)
DEBUG - 2015-01-25 09:26:15 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:26:15 --> Final output sent to browser
DEBUG - 2015-01-25 09:26:15 --> Total execution time: 0.2796
DEBUG - 2015-01-25 09:26:25 --> Config Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:26:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:26:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:26:25 --> URI Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Router Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Output Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Security Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Input Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:26:25 --> Language Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Loader Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:26:25 --> Controller Class Initialized
DEBUG - 2015-01-25 09:26:25 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:26:25 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 09:26:25 --> Final output sent to browser
DEBUG - 2015-01-25 09:26:25 --> Total execution time: 0.0290
DEBUG - 2015-01-25 09:26:30 --> Config Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:26:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:26:30 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:26:30 --> URI Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Router Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Output Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Security Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Input Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:26:30 --> Language Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Loader Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:26:30 --> Controller Class Initialized
DEBUG - 2015-01-25 09:26:30 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:26:30 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:26:30 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:26:30 --> User Agent Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Config Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:26:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:26:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:26:46 --> URI Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Router Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Output Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Security Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Input Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:26:46 --> Language Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Loader Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:26:46 --> Controller Class Initialized
DEBUG - 2015-01-25 09:26:46 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:26:46 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:26:46 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:26:46 --> Final output sent to browser
DEBUG - 2015-01-25 09:26:46 --> Total execution time: 0.0517
DEBUG - 2015-01-25 09:26:49 --> Config Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:26:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:26:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:26:49 --> URI Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Router Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Output Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Security Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Input Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:26:49 --> Language Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Loader Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:26:49 --> Controller Class Initialized
DEBUG - 2015-01-25 09:26:49 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:26:49 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:26:49 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:26:49 --> User Agent Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Config Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:27:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:27:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:27:38 --> URI Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Router Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Output Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Security Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Input Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:27:38 --> Language Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Loader Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:27:38 --> Controller Class Initialized
DEBUG - 2015-01-25 09:27:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:27:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:27:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:27:38 --> Final output sent to browser
DEBUG - 2015-01-25 09:27:38 --> Total execution time: 0.0157
DEBUG - 2015-01-25 09:27:52 --> Config Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:27:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:27:52 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:27:52 --> URI Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Router Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Output Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Security Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Input Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:27:52 --> Language Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Loader Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:27:52 --> Controller Class Initialized
DEBUG - 2015-01-25 09:27:52 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:27:52 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:27:52 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:27:52 --> User Agent Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Config Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:28:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:28:51 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:28:51 --> URI Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Router Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Output Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Security Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Input Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:28:51 --> Language Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Loader Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:28:51 --> Controller Class Initialized
DEBUG - 2015-01-25 09:28:51 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:28:51 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:28:51 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:28:51 --> Final output sent to browser
DEBUG - 2015-01-25 09:28:51 --> Total execution time: 0.0183
DEBUG - 2015-01-25 09:29:02 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:02 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:02 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:02 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:02 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:02 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:02 --> User Agent Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:18 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:18 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:18 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:18 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:18 --> Total execution time: 0.0141
DEBUG - 2015-01-25 09:29:21 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:21 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:21 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:21 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:21 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:21 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:21 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:21 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:21 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:21 --> Total execution time: 0.0090
DEBUG - 2015-01-25 09:29:24 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:24 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:24 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:24 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:24 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:24 --> Total execution time: 0.0083
DEBUG - 2015-01-25 09:29:42 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:42 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:42 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:42 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:42 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:42 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:42 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:42 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:42 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:42 --> Total execution time: 0.0074
DEBUG - 2015-01-25 09:29:45 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:45 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:45 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:45 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:45 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:45 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:45 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:45 --> Total execution time: 0.0063
DEBUG - 2015-01-25 09:29:47 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:47 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:47 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:47 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:47 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:47 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:47 --> Final output sent to browser
DEBUG - 2015-01-25 09:29:47 --> Total execution time: 0.0168
DEBUG - 2015-01-25 09:29:53 --> Config Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:29:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:29:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:29:53 --> URI Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Router Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Output Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Security Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Input Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:29:53 --> Language Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Loader Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:29:53 --> Controller Class Initialized
DEBUG - 2015-01-25 09:29:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:29:53 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:29:53 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:29:53 --> User Agent Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Config Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 09:41:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 09:41:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 09:41:23 --> URI Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Router Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Output Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Security Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Input Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 09:41:23 --> Language Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Loader Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Helper loaded: url_helper
DEBUG - 2015-01-25 09:41:23 --> Controller Class Initialized
DEBUG - 2015-01-25 09:41:23 --> Database Driver Class Initialized
DEBUG - 2015-01-25 09:41:23 --> CI_Session Class Initialized
DEBUG - 2015-01-25 09:41:23 --> CI_Session routines successfully run
DEBUG - 2015-01-25 09:41:23 --> Final output sent to browser
DEBUG - 2015-01-25 09:41:23 --> Total execution time: 0.0106
DEBUG - 2015-01-25 10:02:41 --> Config Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:02:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:02:41 --> URI Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Router Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Output Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Security Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Input Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:02:41 --> Language Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Loader Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:02:41 --> Controller Class Initialized
DEBUG - 2015-01-25 10:02:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:02:41 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:02:41 --> Final output sent to browser
DEBUG - 2015-01-25 10:02:41 --> Total execution time: 0.0043
DEBUG - 2015-01-25 10:02:46 --> Config Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:02:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:02:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:02:46 --> URI Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Router Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Output Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Security Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Input Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:02:46 --> Language Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Loader Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:02:46 --> Controller Class Initialized
DEBUG - 2015-01-25 10:02:46 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:02:46 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:02:46 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:02:46 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Config Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:07:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:07:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:07:53 --> URI Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Router Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Output Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Security Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Input Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:07:53 --> Language Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Loader Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:07:53 --> Controller Class Initialized
DEBUG - 2015-01-25 10:07:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:07:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:07:53 --> Final output sent to browser
DEBUG - 2015-01-25 10:07:53 --> Total execution time: 0.0050
DEBUG - 2015-01-25 10:07:56 --> Config Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:07:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:07:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:07:56 --> URI Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Router Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Output Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Security Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Input Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:07:56 --> Language Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Loader Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:07:56 --> Controller Class Initialized
DEBUG - 2015-01-25 10:07:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:07:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:07:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:07:56 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Config Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:12:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:12:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:12:08 --> URI Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Router Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Output Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Security Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Input Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:12:08 --> Language Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Loader Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:12:08 --> Controller Class Initialized
DEBUG - 2015-01-25 10:12:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:12:08 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:12:08 --> Final output sent to browser
DEBUG - 2015-01-25 10:12:08 --> Total execution time: 0.0198
DEBUG - 2015-01-25 10:12:11 --> Config Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:12:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:12:11 --> URI Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Router Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Output Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Security Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Input Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:12:11 --> Language Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Loader Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:12:11 --> Controller Class Initialized
DEBUG - 2015-01-25 10:12:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:12:11 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:12:11 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:12:11 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Config Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:12:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:12:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:12:48 --> URI Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Router Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Output Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Security Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Input Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:12:48 --> Language Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Loader Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:12:48 --> Controller Class Initialized
DEBUG - 2015-01-25 10:12:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:12:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:12:48 --> Final output sent to browser
DEBUG - 2015-01-25 10:12:48 --> Total execution time: 0.0036
DEBUG - 2015-01-25 10:12:50 --> Config Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:12:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:12:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:12:50 --> URI Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Router Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Output Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Security Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Input Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:12:50 --> Language Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Loader Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:12:50 --> Controller Class Initialized
DEBUG - 2015-01-25 10:12:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:12:50 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:12:50 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:12:50 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Config Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:14:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:14:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:14:35 --> URI Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Router Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Output Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Security Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Input Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:14:35 --> Language Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Loader Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:14:35 --> Controller Class Initialized
DEBUG - 2015-01-25 10:14:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:14:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:14:35 --> Final output sent to browser
DEBUG - 2015-01-25 10:14:35 --> Total execution time: 0.0054
DEBUG - 2015-01-25 10:14:37 --> Config Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:14:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:14:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:14:37 --> URI Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Router Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Output Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Security Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Input Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:14:37 --> Language Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Loader Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:14:37 --> Controller Class Initialized
DEBUG - 2015-01-25 10:14:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:14:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:14:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:14:37 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Config Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:16:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:16:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:16:07 --> URI Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Router Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Output Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Security Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Input Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:16:07 --> Language Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Loader Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:16:07 --> Controller Class Initialized
DEBUG - 2015-01-25 10:16:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:16:07 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:16:07 --> Final output sent to browser
DEBUG - 2015-01-25 10:16:07 --> Total execution time: 0.0048
DEBUG - 2015-01-25 10:16:12 --> Config Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:16:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:16:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:16:12 --> URI Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Router Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Output Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Security Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Input Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:16:12 --> Language Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Loader Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:16:12 --> Controller Class Initialized
DEBUG - 2015-01-25 10:16:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:16:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:16:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:16:12 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Config Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:17:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:17:15 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:17:15 --> URI Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Router Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Output Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Security Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Input Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:17:15 --> Language Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Loader Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:17:15 --> Controller Class Initialized
DEBUG - 2015-01-25 10:17:15 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:17:15 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:17:15 --> Final output sent to browser
DEBUG - 2015-01-25 10:17:15 --> Total execution time: 0.0052
DEBUG - 2015-01-25 10:17:17 --> Config Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:17:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:17:17 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:17:17 --> URI Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Router Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Output Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Security Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Input Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:17:17 --> Language Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Loader Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:17:17 --> Controller Class Initialized
DEBUG - 2015-01-25 10:17:17 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:17:17 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:17:17 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:17:17 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Config Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:18:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:18:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:18:31 --> URI Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Router Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Output Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Security Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Input Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:18:31 --> Language Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Loader Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:18:31 --> Controller Class Initialized
DEBUG - 2015-01-25 10:18:31 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:18:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:18:31 --> Final output sent to browser
DEBUG - 2015-01-25 10:18:31 --> Total execution time: 0.0036
DEBUG - 2015-01-25 10:18:34 --> Config Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:18:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:18:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:18:34 --> URI Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Router Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Output Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Security Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Input Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:18:34 --> Language Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Loader Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:18:34 --> Controller Class Initialized
DEBUG - 2015-01-25 10:18:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:18:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:18:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:18:34 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Config Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:19:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:19:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:19:31 --> URI Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Router Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Output Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Security Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Input Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:19:31 --> Language Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Loader Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:19:31 --> Controller Class Initialized
DEBUG - 2015-01-25 10:19:31 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:19:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:19:31 --> Final output sent to browser
DEBUG - 2015-01-25 10:19:31 --> Total execution time: 0.0064
DEBUG - 2015-01-25 10:19:34 --> Config Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:19:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:19:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:19:34 --> URI Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Router Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Output Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Security Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Input Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:19:34 --> Language Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Loader Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:19:34 --> Controller Class Initialized
DEBUG - 2015-01-25 10:19:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:19:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:19:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:19:34 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Config Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:20:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:20:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:20:31 --> URI Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Router Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Output Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Security Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Input Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:20:31 --> Language Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Loader Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:20:31 --> Controller Class Initialized
DEBUG - 2015-01-25 10:20:31 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:20:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:20:31 --> Final output sent to browser
DEBUG - 2015-01-25 10:20:31 --> Total execution time: 0.0054
DEBUG - 2015-01-25 10:20:34 --> Config Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:20:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:20:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:20:34 --> URI Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Router Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Output Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Security Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Input Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:20:34 --> Language Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Loader Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:20:34 --> Controller Class Initialized
DEBUG - 2015-01-25 10:20:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:20:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:20:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:20:34 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Config Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:21:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:21:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:21:35 --> URI Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Router Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Output Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Security Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Input Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:21:35 --> Language Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Loader Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:21:35 --> Controller Class Initialized
DEBUG - 2015-01-25 10:21:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:21:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:21:35 --> Final output sent to browser
DEBUG - 2015-01-25 10:21:35 --> Total execution time: 0.0138
DEBUG - 2015-01-25 10:21:38 --> Config Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:21:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:21:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:21:38 --> URI Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Router Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Output Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Security Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Input Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:21:38 --> Language Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Loader Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:21:38 --> Controller Class Initialized
DEBUG - 2015-01-25 10:21:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:21:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:21:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:21:38 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Config Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:25:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:25:08 --> URI Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Router Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Output Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Security Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Input Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:25:08 --> Language Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Loader Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:25:08 --> Controller Class Initialized
DEBUG - 2015-01-25 10:25:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:25:08 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:25:08 --> Final output sent to browser
DEBUG - 2015-01-25 10:25:08 --> Total execution time: 0.0159
DEBUG - 2015-01-25 10:25:12 --> Config Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:25:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:25:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:25:12 --> URI Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Router Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Output Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Security Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Input Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:25:12 --> Language Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Loader Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:25:12 --> Controller Class Initialized
DEBUG - 2015-01-25 10:25:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:25:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:25:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:25:12 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Config Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:36:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:36:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:36:45 --> URI Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Router Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Output Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Security Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Input Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:36:45 --> Language Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Loader Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:36:45 --> Controller Class Initialized
DEBUG - 2015-01-25 10:36:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:36:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:36:45 --> Final output sent to browser
DEBUG - 2015-01-25 10:36:45 --> Total execution time: 0.0109
DEBUG - 2015-01-25 10:36:50 --> Config Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:36:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:36:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:36:50 --> URI Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Router Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Output Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Security Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Input Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:36:50 --> Language Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Loader Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:36:50 --> Controller Class Initialized
DEBUG - 2015-01-25 10:36:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:36:50 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:36:50 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:36:50 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Config Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:39:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:39:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:39:48 --> URI Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Router Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Output Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Security Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Input Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:39:48 --> Language Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Loader Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:39:48 --> Controller Class Initialized
DEBUG - 2015-01-25 10:39:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:39:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:39:48 --> Final output sent to browser
DEBUG - 2015-01-25 10:39:48 --> Total execution time: 0.0091
DEBUG - 2015-01-25 10:39:57 --> Config Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:39:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:39:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:39:57 --> URI Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Router Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Output Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Security Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Input Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:39:57 --> Language Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Loader Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:39:57 --> Controller Class Initialized
DEBUG - 2015-01-25 10:39:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:39:57 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:39:57 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:39:57 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Config Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:41:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:41:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:41:35 --> URI Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Router Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Output Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Security Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Input Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:41:35 --> Language Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Loader Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:41:35 --> Controller Class Initialized
DEBUG - 2015-01-25 10:41:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:41:35 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:41:35 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:41:35 --> Final output sent to browser
DEBUG - 2015-01-25 10:41:35 --> Total execution time: 0.0190
DEBUG - 2015-01-25 10:45:02 --> Config Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:45:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:45:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:45:02 --> URI Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Router Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Output Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Security Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Input Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:45:02 --> Language Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Loader Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:45:02 --> Controller Class Initialized
DEBUG - 2015-01-25 10:45:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:45:02 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:45:02 --> Final output sent to browser
DEBUG - 2015-01-25 10:45:02 --> Total execution time: 0.0039
DEBUG - 2015-01-25 10:45:05 --> Config Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:45:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:45:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:45:05 --> URI Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Router Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Output Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Security Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Input Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:45:05 --> Language Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Loader Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:45:05 --> Controller Class Initialized
DEBUG - 2015-01-25 10:45:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:45:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:45:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:45:05 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Config Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:45:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:45:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:45:41 --> URI Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Router Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Output Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Security Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Input Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:45:41 --> Language Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Loader Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:45:41 --> Controller Class Initialized
DEBUG - 2015-01-25 10:45:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:45:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:45:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:45:41 --> Final output sent to browser
DEBUG - 2015-01-25 10:45:41 --> Total execution time: 0.0201
DEBUG - 2015-01-25 10:47:40 --> Config Class Initialized
DEBUG - 2015-01-25 10:47:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:47:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:47:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:47:40 --> URI Class Initialized
DEBUG - 2015-01-25 10:47:40 --> Router Class Initialized
DEBUG - 2015-01-25 10:47:40 --> Output Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Security Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Input Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:47:41 --> Language Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Loader Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:47:41 --> Controller Class Initialized
DEBUG - 2015-01-25 10:47:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:47:41 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:47:41 --> Final output sent to browser
DEBUG - 2015-01-25 10:47:41 --> Total execution time: 0.0041
DEBUG - 2015-01-25 10:47:43 --> Config Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:47:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:47:43 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:47:43 --> URI Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Router Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Output Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Security Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Input Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:47:43 --> Language Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Loader Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:47:43 --> Controller Class Initialized
DEBUG - 2015-01-25 10:47:43 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:47:43 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:47:43 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:47:43 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Config Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:50:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:50:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:50:24 --> URI Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Router Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Output Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Security Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Input Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:50:24 --> Language Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Loader Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:50:24 --> Controller Class Initialized
DEBUG - 2015-01-25 10:50:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:50:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:50:24 --> Final output sent to browser
DEBUG - 2015-01-25 10:50:24 --> Total execution time: 0.0040
DEBUG - 2015-01-25 10:50:27 --> Config Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:50:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:50:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:50:27 --> URI Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Router Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Output Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Security Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Input Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:50:27 --> Language Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Loader Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:50:27 --> Controller Class Initialized
DEBUG - 2015-01-25 10:50:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:50:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:50:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:50:27 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Config Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:51:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:51:34 --> URI Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Router Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Output Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Security Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Input Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:51:34 --> Language Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Loader Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:51:34 --> Controller Class Initialized
DEBUG - 2015-01-25 10:51:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:51:34 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:51:34 --> Final output sent to browser
DEBUG - 2015-01-25 10:51:34 --> Total execution time: 0.0045
DEBUG - 2015-01-25 10:51:36 --> Config Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:51:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:51:36 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:51:36 --> URI Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Router Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Output Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Security Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Input Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:51:36 --> Language Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Loader Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:51:36 --> Controller Class Initialized
DEBUG - 2015-01-25 10:51:36 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:51:36 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:51:36 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:51:36 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Config Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:52:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:52:08 --> URI Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Router Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Output Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Security Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Input Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:52:08 --> Language Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Loader Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:52:08 --> Controller Class Initialized
DEBUG - 2015-01-25 10:52:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:52:08 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:52:08 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:52:08 --> Final output sent to browser
DEBUG - 2015-01-25 10:52:08 --> Total execution time: 0.0086
DEBUG - 2015-01-25 10:53:16 --> Config Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:53:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:53:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:53:16 --> URI Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Router Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Output Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Security Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Input Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:53:16 --> Language Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Loader Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:53:16 --> Controller Class Initialized
DEBUG - 2015-01-25 10:53:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:53:16 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:53:16 --> Final output sent to browser
DEBUG - 2015-01-25 10:53:16 --> Total execution time: 0.0040
DEBUG - 2015-01-25 10:53:22 --> Config Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:53:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:53:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:53:22 --> URI Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Router Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Output Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Security Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Input Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:53:22 --> Language Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Loader Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:53:22 --> Controller Class Initialized
DEBUG - 2015-01-25 10:53:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:53:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:53:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:53:22 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Config Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:53:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:53:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:53:35 --> URI Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Router Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Output Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Security Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Input Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:53:35 --> Language Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Loader Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:53:35 --> Controller Class Initialized
DEBUG - 2015-01-25 10:53:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:53:35 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:53:35 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:53:35 --> Final output sent to browser
DEBUG - 2015-01-25 10:53:35 --> Total execution time: 0.0115
DEBUG - 2015-01-25 10:53:37 --> Config Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:53:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:53:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:53:37 --> URI Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Router Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Output Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Security Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Input Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:53:37 --> Language Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Loader Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:53:37 --> Controller Class Initialized
DEBUG - 2015-01-25 10:53:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:53:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:53:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:53:37 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Config Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:53:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:53:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:53:54 --> URI Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Router Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Output Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Security Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Input Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:53:54 --> Language Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Loader Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:53:54 --> Controller Class Initialized
DEBUG - 2015-01-25 10:53:54 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:53:54 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:53:54 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:53:54 --> Final output sent to browser
DEBUG - 2015-01-25 10:53:54 --> Total execution time: 0.0180
DEBUG - 2015-01-25 10:56:34 --> Config Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:56:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:56:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:56:34 --> URI Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Router Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Output Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Security Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Input Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:56:34 --> Language Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Loader Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:56:34 --> Controller Class Initialized
DEBUG - 2015-01-25 10:56:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:56:34 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:56:34 --> Final output sent to browser
DEBUG - 2015-01-25 10:56:34 --> Total execution time: 0.0419
DEBUG - 2015-01-25 10:56:37 --> Config Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:56:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:56:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:56:37 --> URI Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Router Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Output Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Security Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Input Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:56:37 --> Language Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Loader Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:56:37 --> Controller Class Initialized
DEBUG - 2015-01-25 10:56:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:56:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:56:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:56:37 --> User Agent Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Config Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:56:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:56:55 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:56:55 --> URI Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Router Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Output Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Security Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Input Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:56:55 --> Language Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Loader Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:56:55 --> Controller Class Initialized
DEBUG - 2015-01-25 10:56:55 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:56:55 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:56:55 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:56:55 --> Final output sent to browser
DEBUG - 2015-01-25 10:56:55 --> Total execution time: 0.0207
DEBUG - 2015-01-25 10:57:16 --> Config Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:57:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:57:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:57:16 --> URI Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Router Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Output Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Security Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Input Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:57:16 --> Language Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Loader Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:57:16 --> Controller Class Initialized
DEBUG - 2015-01-25 10:57:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:57:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:57:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:57:16 --> Final output sent to browser
DEBUG - 2015-01-25 10:57:16 --> Total execution time: 0.0111
DEBUG - 2015-01-25 10:57:20 --> Config Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:57:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:57:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:57:20 --> URI Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Router Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Output Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Security Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Input Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:57:20 --> Language Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Loader Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:57:20 --> Controller Class Initialized
DEBUG - 2015-01-25 10:57:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:57:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:57:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:57:20 --> Final output sent to browser
DEBUG - 2015-01-25 10:57:20 --> Total execution time: 0.0054
DEBUG - 2015-01-25 10:57:25 --> Config Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:57:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:57:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:57:25 --> URI Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Router Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Output Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Security Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Input Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:57:25 --> Language Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Loader Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:57:25 --> Controller Class Initialized
DEBUG - 2015-01-25 10:57:25 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:57:25 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:57:25 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:57:25 --> Final output sent to browser
DEBUG - 2015-01-25 10:57:25 --> Total execution time: 0.0073
DEBUG - 2015-01-25 10:59:06 --> Config Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:59:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:59:06 --> URI Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Router Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Output Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Security Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Input Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:59:06 --> Language Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Loader Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:59:06 --> Controller Class Initialized
DEBUG - 2015-01-25 10:59:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:59:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 10:59:06 --> Final output sent to browser
DEBUG - 2015-01-25 10:59:06 --> Total execution time: 0.0115
DEBUG - 2015-01-25 10:59:10 --> Config Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 10:59:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 10:59:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 10:59:10 --> URI Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Router Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Output Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Security Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Input Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 10:59:10 --> Language Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Loader Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 10:59:10 --> Controller Class Initialized
DEBUG - 2015-01-25 10:59:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 10:59:10 --> CI_Session Class Initialized
DEBUG - 2015-01-25 10:59:10 --> CI_Session routines successfully run
DEBUG - 2015-01-25 10:59:10 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Config Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:00:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:00:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:00:23 --> URI Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Router Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Output Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Security Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Input Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:00:23 --> Language Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Loader Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:00:23 --> Controller Class Initialized
DEBUG - 2015-01-25 11:00:23 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:00:23 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:00:23 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:00:23 --> Final output sent to browser
DEBUG - 2015-01-25 11:00:23 --> Total execution time: 0.0088
DEBUG - 2015-01-25 11:00:34 --> Config Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:00:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:00:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:00:34 --> URI Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Router Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Output Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Security Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Input Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:00:34 --> Language Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Loader Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:00:34 --> Controller Class Initialized
DEBUG - 2015-01-25 11:00:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:00:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:00:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:00:34 --> Final output sent to browser
DEBUG - 2015-01-25 11:00:34 --> Total execution time: 0.0061
DEBUG - 2015-01-25 11:00:59 --> Config Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:00:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:00:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:00:59 --> URI Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Router Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Output Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Security Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Input Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:00:59 --> Language Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Loader Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:00:59 --> Controller Class Initialized
DEBUG - 2015-01-25 11:00:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:00:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:00:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:00:59 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Config Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:01:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:01:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:01:07 --> URI Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Router Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Output Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Security Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Input Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:01:07 --> Language Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Loader Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:01:07 --> Controller Class Initialized
DEBUG - 2015-01-25 11:01:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:01:07 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:01:07 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:01:07 --> Final output sent to browser
DEBUG - 2015-01-25 11:01:07 --> Total execution time: 0.0174
DEBUG - 2015-01-25 11:04:11 --> Config Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:04:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:04:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:04:11 --> URI Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Router Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Output Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Security Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Input Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:04:11 --> Language Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Loader Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:04:11 --> Controller Class Initialized
DEBUG - 2015-01-25 11:04:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:04:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:04:11 --> Final output sent to browser
DEBUG - 2015-01-25 11:04:11 --> Total execution time: 0.0091
DEBUG - 2015-01-25 11:04:13 --> Config Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:04:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:04:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:04:13 --> URI Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Router Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Output Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Security Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Input Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:04:13 --> Language Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Loader Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:04:13 --> Controller Class Initialized
DEBUG - 2015-01-25 11:04:13 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:04:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:04:13 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:04:13 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Config Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:04:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:04:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:04:26 --> URI Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Router Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Output Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Security Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Input Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:04:26 --> Language Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Loader Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:04:26 --> Controller Class Initialized
DEBUG - 2015-01-25 11:04:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:04:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:04:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:04:26 --> Final output sent to browser
DEBUG - 2015-01-25 11:04:26 --> Total execution time: 0.0097
DEBUG - 2015-01-25 11:05:35 --> Config Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:05:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:05:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:05:35 --> URI Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Router Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Output Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Security Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Input Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:05:35 --> Language Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Loader Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:05:35 --> Controller Class Initialized
DEBUG - 2015-01-25 11:05:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:05:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:05:35 --> Final output sent to browser
DEBUG - 2015-01-25 11:05:35 --> Total execution time: 0.0034
DEBUG - 2015-01-25 11:05:37 --> Config Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:05:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:05:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:05:37 --> URI Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Router Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Output Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Security Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Input Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:05:37 --> Language Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Loader Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:05:37 --> Controller Class Initialized
DEBUG - 2015-01-25 11:05:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:05:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:05:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:05:37 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Config Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:05:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:05:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:05:47 --> URI Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Router Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Output Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Security Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Input Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:05:47 --> Language Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Loader Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:05:47 --> Controller Class Initialized
DEBUG - 2015-01-25 11:05:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:05:47 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:05:47 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:05:47 --> Final output sent to browser
DEBUG - 2015-01-25 11:05:47 --> Total execution time: 0.0111
DEBUG - 2015-01-25 11:06:32 --> Config Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:06:32 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:06:32 --> URI Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Router Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Output Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Security Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Input Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:06:32 --> Language Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Loader Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:06:32 --> Controller Class Initialized
DEBUG - 2015-01-25 11:06:32 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:06:32 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:06:32 --> Final output sent to browser
DEBUG - 2015-01-25 11:06:32 --> Total execution time: 0.0049
DEBUG - 2015-01-25 11:06:34 --> Config Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:06:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:06:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:06:34 --> URI Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Router Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Output Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Security Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Input Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:06:34 --> Language Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Loader Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:06:34 --> Controller Class Initialized
DEBUG - 2015-01-25 11:06:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:06:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:06:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:06:34 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Config Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:06:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:06:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:06:40 --> URI Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Router Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Output Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Security Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Input Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:06:40 --> Language Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Loader Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:06:40 --> Controller Class Initialized
DEBUG - 2015-01-25 11:06:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:06:40 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:06:40 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:06:40 --> Final output sent to browser
DEBUG - 2015-01-25 11:06:40 --> Total execution time: 0.0200
DEBUG - 2015-01-25 11:07:46 --> Config Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:07:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:07:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:07:46 --> URI Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Router Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Output Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Security Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Input Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:07:46 --> Language Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Loader Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:07:46 --> Controller Class Initialized
DEBUG - 2015-01-25 11:07:46 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:07:46 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:07:46 --> Final output sent to browser
DEBUG - 2015-01-25 11:07:46 --> Total execution time: 0.0040
DEBUG - 2015-01-25 11:07:48 --> Config Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:07:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:07:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:07:48 --> URI Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Router Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Output Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Security Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Input Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:07:48 --> Language Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Loader Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:07:48 --> Controller Class Initialized
DEBUG - 2015-01-25 11:07:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:07:48 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:07:48 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:07:48 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Config Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:07:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:07:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:07:53 --> URI Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Router Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Output Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Security Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Input Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:07:53 --> Language Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Loader Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:07:53 --> Controller Class Initialized
DEBUG - 2015-01-25 11:07:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:07:53 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:07:53 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:07:53 --> Final output sent to browser
DEBUG - 2015-01-25 11:07:53 --> Total execution time: 0.0130
DEBUG - 2015-01-25 11:08:02 --> Config Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:08:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:08:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:08:02 --> URI Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Router Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Output Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Security Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Input Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:08:02 --> Language Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Loader Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:08:02 --> Controller Class Initialized
DEBUG - 2015-01-25 11:08:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:08:02 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:08:02 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:08:02 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Config Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:08:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:08:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:08:05 --> URI Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Router Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Output Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Security Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Input Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:08:05 --> Language Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Loader Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:08:05 --> Controller Class Initialized
DEBUG - 2015-01-25 11:08:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:08:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:08:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:08:05 --> Final output sent to browser
DEBUG - 2015-01-25 11:08:05 --> Total execution time: 0.0091
DEBUG - 2015-01-25 11:08:33 --> Config Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:08:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:08:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:08:33 --> URI Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Router Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Output Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Security Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Input Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:08:33 --> Language Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Loader Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:08:33 --> Controller Class Initialized
DEBUG - 2015-01-25 11:08:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:08:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:08:33 --> Final output sent to browser
DEBUG - 2015-01-25 11:08:33 --> Total execution time: 0.0034
DEBUG - 2015-01-25 11:08:36 --> Config Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:08:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:08:36 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:08:36 --> URI Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Router Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Output Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Security Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Input Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:08:36 --> Language Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Loader Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:08:36 --> Controller Class Initialized
DEBUG - 2015-01-25 11:08:36 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:08:36 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:08:36 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:08:36 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Config Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:08:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:08:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:08:41 --> URI Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Router Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Output Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Security Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Input Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:08:41 --> Language Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Loader Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:08:41 --> Controller Class Initialized
DEBUG - 2015-01-25 11:08:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:08:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:08:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:08:41 --> Final output sent to browser
DEBUG - 2015-01-25 11:08:41 --> Total execution time: 0.0186
DEBUG - 2015-01-25 11:10:09 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:09 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:09 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:10 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:10 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:10 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:10:10 --> Final output sent to browser
DEBUG - 2015-01-25 11:10:10 --> Total execution time: 0.0045
DEBUG - 2015-01-25 11:10:12 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:12 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:12 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:12 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:10:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:10:12 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:26 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:26 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:26 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:10:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:10:26 --> Final output sent to browser
DEBUG - 2015-01-25 11:10:26 --> Total execution time: 0.0157
DEBUG - 2015-01-25 11:10:34 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:34 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:34 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:34 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:10:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:10:34 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:38 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:38 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:38 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:10:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:10:38 --> Final output sent to browser
DEBUG - 2015-01-25 11:10:38 --> Total execution time: 0.0119
DEBUG - 2015-01-25 11:10:51 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:51 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:51 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:51 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:51 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:51 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:51 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:10:51 --> Final output sent to browser
DEBUG - 2015-01-25 11:10:51 --> Total execution time: 0.0038
DEBUG - 2015-01-25 11:10:54 --> Config Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:10:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:10:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:10:54 --> URI Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Router Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Output Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Security Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Input Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:10:54 --> Language Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Loader Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:10:54 --> Controller Class Initialized
DEBUG - 2015-01-25 11:10:54 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:10:54 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:10:54 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:10:54 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:05 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:05 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:05 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:05 --> Final output sent to browser
DEBUG - 2015-01-25 11:11:05 --> Total execution time: 0.0133
DEBUG - 2015-01-25 11:11:16 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:16 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:16 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:16 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:16 --> Final output sent to browser
DEBUG - 2015-01-25 11:11:16 --> Total execution time: 0.0114
DEBUG - 2015-01-25 11:11:19 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:19 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:19 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:19 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:19 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:19 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:19 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:19 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:19 --> Final output sent to browser
DEBUG - 2015-01-25 11:11:19 --> Total execution time: 0.0067
DEBUG - 2015-01-25 11:11:22 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:22 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:22 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:22 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:22 --> Final output sent to browser
DEBUG - 2015-01-25 11:11:22 --> Total execution time: 0.0054
DEBUG - 2015-01-25 11:11:26 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:26 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:26 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:26 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:26 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Config Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:11:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:11:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:11:29 --> URI Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Router Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Output Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Security Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Input Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:11:29 --> Language Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Loader Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:11:29 --> Controller Class Initialized
DEBUG - 2015-01-25 11:11:29 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:11:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:11:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:11:29 --> Final output sent to browser
DEBUG - 2015-01-25 11:11:29 --> Total execution time: 0.0085
DEBUG - 2015-01-25 11:12:05 --> Config Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:12:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:12:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:12:05 --> URI Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Router Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Output Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Security Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Input Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:12:05 --> Language Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Loader Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:12:05 --> Controller Class Initialized
DEBUG - 2015-01-25 11:12:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:12:05 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:12:05 --> Final output sent to browser
DEBUG - 2015-01-25 11:12:05 --> Total execution time: 0.0057
DEBUG - 2015-01-25 11:12:07 --> Config Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:12:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:12:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:12:07 --> URI Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Router Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Output Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Security Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Input Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:12:07 --> Language Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Loader Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:12:07 --> Controller Class Initialized
DEBUG - 2015-01-25 11:12:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:12:07 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:12:07 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:12:07 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Config Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:13:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:13:21 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:13:21 --> URI Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Router Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Output Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Security Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Input Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:13:21 --> Language Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Loader Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:13:21 --> Controller Class Initialized
DEBUG - 2015-01-25 11:13:21 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:13:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:13:21 --> Final output sent to browser
DEBUG - 2015-01-25 11:13:21 --> Total execution time: 0.0038
DEBUG - 2015-01-25 11:13:23 --> Config Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:13:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:13:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:13:23 --> URI Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Router Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Output Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Security Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Input Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:13:23 --> Language Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Loader Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:13:23 --> Controller Class Initialized
DEBUG - 2015-01-25 11:13:23 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:13:23 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:13:23 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:13:23 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Config Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:13:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:13:32 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:13:32 --> URI Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Router Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Output Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Security Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Input Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:13:32 --> Language Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Loader Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:13:32 --> Controller Class Initialized
DEBUG - 2015-01-25 11:13:32 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:13:32 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:13:32 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:13:32 --> Final output sent to browser
DEBUG - 2015-01-25 11:13:32 --> Total execution time: 0.0149
DEBUG - 2015-01-25 11:13:36 --> Config Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:13:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:13:36 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:13:36 --> URI Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Router Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Output Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Security Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Input Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:13:36 --> Language Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Loader Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:13:36 --> Controller Class Initialized
DEBUG - 2015-01-25 11:13:36 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:13:36 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:13:36 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:13:36 --> Final output sent to browser
DEBUG - 2015-01-25 11:13:36 --> Total execution time: 0.0060
DEBUG - 2015-01-25 11:14:40 --> Config Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:14:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:14:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:14:40 --> URI Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Router Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Output Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Security Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Input Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:14:40 --> Language Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Loader Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:14:40 --> Controller Class Initialized
DEBUG - 2015-01-25 11:14:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:14:40 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:14:40 --> Final output sent to browser
DEBUG - 2015-01-25 11:14:40 --> Total execution time: 0.0048
DEBUG - 2015-01-25 11:14:42 --> Config Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:14:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:14:42 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:14:42 --> URI Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Router Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Output Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Security Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Input Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:14:42 --> Language Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Loader Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:14:42 --> Controller Class Initialized
DEBUG - 2015-01-25 11:14:42 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:14:42 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:14:42 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:14:42 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Config Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:17:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:17:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:17:08 --> URI Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Router Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Output Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Security Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Input Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:17:08 --> Language Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Loader Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:17:08 --> Controller Class Initialized
DEBUG - 2015-01-25 11:17:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:17:08 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:17:08 --> Final output sent to browser
DEBUG - 2015-01-25 11:17:08 --> Total execution time: 0.0041
DEBUG - 2015-01-25 11:17:10 --> Config Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:17:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:17:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:17:10 --> URI Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Router Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Output Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Security Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Input Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:17:10 --> Language Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Loader Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:17:10 --> Controller Class Initialized
DEBUG - 2015-01-25 11:17:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:17:10 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:17:10 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:17:10 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Config Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:17:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:17:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:17:57 --> URI Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Router Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Output Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Security Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Input Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:17:57 --> Language Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Loader Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:17:57 --> Controller Class Initialized
DEBUG - 2015-01-25 11:17:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:17:57 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 11:17:57 --> Final output sent to browser
DEBUG - 2015-01-25 11:17:57 --> Total execution time: 0.0112
DEBUG - 2015-01-25 11:18:00 --> Config Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:18:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:18:00 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:18:00 --> URI Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Router Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Output Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Security Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Input Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:18:00 --> Language Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Loader Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:18:00 --> Controller Class Initialized
DEBUG - 2015-01-25 11:18:00 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:18:00 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:18:00 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:18:00 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Config Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:18:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:18:15 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:18:15 --> URI Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Router Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Output Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Security Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Input Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:18:15 --> Language Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Loader Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:18:15 --> Controller Class Initialized
DEBUG - 2015-01-25 11:18:15 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:18:15 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:18:15 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:18:15 --> Final output sent to browser
DEBUG - 2015-01-25 11:18:15 --> Total execution time: 0.0111
DEBUG - 2015-01-25 11:18:20 --> Config Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:18:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:18:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:18:20 --> URI Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Router Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Output Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Security Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Input Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:18:20 --> Language Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Loader Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:18:20 --> Controller Class Initialized
DEBUG - 2015-01-25 11:18:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:18:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:18:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:18:20 --> User Agent Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Config Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:18:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:18:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:18:41 --> URI Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Router Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Output Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Security Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Input Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:18:41 --> Language Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Loader Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:18:41 --> Controller Class Initialized
DEBUG - 2015-01-25 11:18:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:18:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:18:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:18:41 --> Final output sent to browser
DEBUG - 2015-01-25 11:18:41 --> Total execution time: 0.0086
DEBUG - 2015-01-25 11:18:59 --> Config Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:18:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:18:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:18:59 --> URI Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Router Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Output Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Security Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Input Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:18:59 --> Language Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Loader Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:18:59 --> Controller Class Initialized
DEBUG - 2015-01-25 11:18:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:18:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:18:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:18:59 --> Final output sent to browser
DEBUG - 2015-01-25 11:18:59 --> Total execution time: 0.0049
DEBUG - 2015-01-25 11:19:03 --> Config Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:19:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:19:03 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:19:03 --> URI Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Router Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Output Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Security Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Input Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:19:03 --> Language Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Loader Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:19:03 --> Controller Class Initialized
DEBUG - 2015-01-25 11:19:03 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:19:03 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:19:03 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:19:03 --> Final output sent to browser
DEBUG - 2015-01-25 11:19:03 --> Total execution time: 0.0051
DEBUG - 2015-01-25 11:19:06 --> Config Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 11:19:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 11:19:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 11:19:06 --> URI Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Router Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Output Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Security Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Input Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 11:19:06 --> Language Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Loader Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 11:19:06 --> Controller Class Initialized
DEBUG - 2015-01-25 11:19:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 11:19:06 --> CI_Session Class Initialized
DEBUG - 2015-01-25 11:19:06 --> CI_Session routines successfully run
DEBUG - 2015-01-25 11:19:06 --> Final output sent to browser
DEBUG - 2015-01-25 11:19:06 --> Total execution time: 0.0050
DEBUG - 2015-01-25 13:04:27 --> Config Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:04:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:04:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:04:27 --> URI Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Router Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Output Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Security Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Input Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:04:27 --> Language Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Loader Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:04:27 --> Controller Class Initialized
DEBUG - 2015-01-25 13:04:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:04:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:04:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:04:27 --> Final output sent to browser
DEBUG - 2015-01-25 13:04:27 --> Total execution time: 0.0857
DEBUG - 2015-01-25 13:04:41 --> Config Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:04:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:04:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:04:41 --> URI Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Router Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Output Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Security Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Input Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:04:41 --> Language Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Loader Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:04:41 --> Controller Class Initialized
DEBUG - 2015-01-25 13:04:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:04:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:04:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:04:41 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:02 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:02 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:02 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:02 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:02 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:02 --> Final output sent to browser
DEBUG - 2015-01-25 13:05:02 --> Total execution time: 0.0191
DEBUG - 2015-01-25 13:05:10 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:10 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:10 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:10 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:10 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:10 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:10 --> Final output sent to browser
DEBUG - 2015-01-25 13:05:10 --> Total execution time: 0.0074
DEBUG - 2015-01-25 13:05:14 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:14 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:14 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:14 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:14 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:14 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:14 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:14 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:14 --> Final output sent to browser
DEBUG - 2015-01-25 13:05:14 --> Total execution time: 0.0075
DEBUG - 2015-01-25 13:05:16 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:16 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:16 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:16 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:16 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:26 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:26 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:26 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:26 --> Final output sent to browser
DEBUG - 2015-01-25 13:05:26 --> Total execution time: 0.0110
DEBUG - 2015-01-25 13:05:36 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:36 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:36 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:36 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:36 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:36 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:36 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:36 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:36 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Config Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:05:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:05:52 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:05:52 --> URI Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Router Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Output Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Security Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Input Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:05:52 --> Language Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Loader Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:05:52 --> Controller Class Initialized
DEBUG - 2015-01-25 13:05:52 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:05:52 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:05:52 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:05:52 --> Final output sent to browser
DEBUG - 2015-01-25 13:05:52 --> Total execution time: 0.0135
DEBUG - 2015-01-25 13:07:21 --> Config Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:07:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:07:21 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:07:21 --> URI Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Router Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Output Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Security Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Input Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:07:21 --> Language Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Loader Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:07:21 --> Controller Class Initialized
DEBUG - 2015-01-25 13:07:21 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:07:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:07:21 --> Final output sent to browser
DEBUG - 2015-01-25 13:07:21 --> Total execution time: 0.0081
DEBUG - 2015-01-25 13:07:25 --> Config Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:07:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:07:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:07:25 --> URI Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Router Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Output Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Security Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Input Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:07:25 --> Language Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Loader Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:07:25 --> Controller Class Initialized
DEBUG - 2015-01-25 13:07:25 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:07:25 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:07:25 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:07:25 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Config Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:07:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:07:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:07:40 --> URI Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Router Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Output Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Security Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Input Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:07:40 --> Language Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Loader Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:07:40 --> Controller Class Initialized
DEBUG - 2015-01-25 13:07:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:07:40 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:07:40 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:07:40 --> Final output sent to browser
DEBUG - 2015-01-25 13:07:40 --> Total execution time: 0.0127
DEBUG - 2015-01-25 13:07:44 --> Config Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:07:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:07:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:07:44 --> URI Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Router Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Output Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Security Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Input Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:07:44 --> Language Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Loader Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:07:44 --> Controller Class Initialized
DEBUG - 2015-01-25 13:07:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:07:44 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:07:44 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:07:44 --> Final output sent to browser
DEBUG - 2015-01-25 13:07:44 --> Total execution time: 0.0048
DEBUG - 2015-01-25 13:07:51 --> Config Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:07:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:07:51 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:07:51 --> URI Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Router Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Output Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Security Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Input Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:07:51 --> Language Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Loader Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:07:51 --> Controller Class Initialized
DEBUG - 2015-01-25 13:07:51 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:07:51 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:07:51 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:07:51 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Config Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:09:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:09:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:09:09 --> URI Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Router Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Output Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Security Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Input Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:09:09 --> Language Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Loader Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:09:09 --> Controller Class Initialized
DEBUG - 2015-01-25 13:09:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:09:09 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:09:09 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:09:09 --> Final output sent to browser
DEBUG - 2015-01-25 13:09:09 --> Total execution time: 0.0087
DEBUG - 2015-01-25 13:09:37 --> Config Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:09:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:09:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:09:37 --> URI Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Router Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Output Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Security Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Input Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:09:37 --> Language Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Loader Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:09:37 --> Controller Class Initialized
DEBUG - 2015-01-25 13:09:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:09:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:09:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:09:37 --> Final output sent to browser
DEBUG - 2015-01-25 13:09:37 --> Total execution time: 0.0050
DEBUG - 2015-01-25 13:09:40 --> Config Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:09:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:09:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:09:40 --> URI Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Router Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Output Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Security Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Input Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:09:40 --> Language Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Loader Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:09:40 --> Controller Class Initialized
DEBUG - 2015-01-25 13:09:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:09:40 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:09:40 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:09:40 --> Final output sent to browser
DEBUG - 2015-01-25 13:09:40 --> Total execution time: 0.0083
DEBUG - 2015-01-25 13:09:47 --> Config Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:09:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:09:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:09:47 --> URI Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Router Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Output Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Security Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Input Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:09:47 --> Language Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Loader Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:09:47 --> Controller Class Initialized
DEBUG - 2015-01-25 13:09:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:09:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:09:47 --> Final output sent to browser
DEBUG - 2015-01-25 13:09:47 --> Total execution time: 0.0071
DEBUG - 2015-01-25 13:10:06 --> Config Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:10:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:10:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:10:06 --> URI Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Router Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Output Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Security Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Input Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:10:06 --> Language Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Loader Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:10:06 --> Controller Class Initialized
DEBUG - 2015-01-25 13:10:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:10:06 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:10:06 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:10:06 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Config Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:10:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:10:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:10:37 --> URI Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Router Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Output Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Security Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Input Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:10:37 --> Language Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Loader Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:10:37 --> Controller Class Initialized
DEBUG - 2015-01-25 13:10:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:10:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:10:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:10:37 --> Final output sent to browser
DEBUG - 2015-01-25 13:10:37 --> Total execution time: 0.0105
DEBUG - 2015-01-25 13:10:39 --> Config Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:10:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:10:39 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:10:39 --> URI Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Router Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Output Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Security Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Input Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:10:39 --> Language Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Loader Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:10:39 --> Controller Class Initialized
DEBUG - 2015-01-25 13:10:39 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:10:39 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:10:39 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:10:39 --> Final output sent to browser
DEBUG - 2015-01-25 13:10:39 --> Total execution time: 0.0303
DEBUG - 2015-01-25 13:12:33 --> Config Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:12:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:12:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:12:33 --> URI Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Router Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Output Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Security Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Input Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:12:33 --> Language Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Loader Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:12:33 --> Controller Class Initialized
DEBUG - 2015-01-25 13:12:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:12:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:12:33 --> Final output sent to browser
DEBUG - 2015-01-25 13:12:33 --> Total execution time: 0.0069
DEBUG - 2015-01-25 13:12:40 --> Config Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:12:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:12:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:12:40 --> URI Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Router Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Output Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Security Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Input Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:12:40 --> Language Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Loader Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:12:40 --> Controller Class Initialized
DEBUG - 2015-01-25 13:12:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:12:40 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:12:40 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:12:40 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Config Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:12:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:12:55 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:12:55 --> URI Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Router Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Output Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Security Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Input Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:12:55 --> Language Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Loader Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:12:55 --> Controller Class Initialized
DEBUG - 2015-01-25 13:12:55 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:12:55 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:12:55 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:12:55 --> Final output sent to browser
DEBUG - 2015-01-25 13:12:55 --> Total execution time: 0.0098
DEBUG - 2015-01-25 13:12:59 --> Config Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:12:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:12:59 --> URI Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Router Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Output Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Security Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Input Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:12:59 --> Language Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Loader Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:12:59 --> Controller Class Initialized
DEBUG - 2015-01-25 13:12:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:12:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:12:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:12:59 --> Final output sent to browser
DEBUG - 2015-01-25 13:12:59 --> Total execution time: 0.0068
DEBUG - 2015-01-25 13:13:01 --> Config Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:13:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:13:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:13:01 --> URI Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Router Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Output Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Security Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Input Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:13:01 --> Language Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Loader Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:13:01 --> Controller Class Initialized
DEBUG - 2015-01-25 13:13:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:13:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:13:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:13:01 --> Final output sent to browser
DEBUG - 2015-01-25 13:13:01 --> Total execution time: 0.0328
DEBUG - 2015-01-25 13:14:08 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:08 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:08 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:08 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:08 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:14:08 --> Final output sent to browser
DEBUG - 2015-01-25 13:14:08 --> Total execution time: 0.0049
DEBUG - 2015-01-25 13:14:11 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:11 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:11 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:11 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:11 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:11 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:11 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:20 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:20 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:20 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:20 --> Final output sent to browser
DEBUG - 2015-01-25 13:14:20 --> Total execution time: 0.0168
DEBUG - 2015-01-25 13:14:23 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:23 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:23 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:23 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:23 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:23 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:23 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:23 --> Final output sent to browser
DEBUG - 2015-01-25 13:14:23 --> Total execution time: 0.0062
DEBUG - 2015-01-25 13:14:26 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:26 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:26 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:26 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:26 --> Final output sent to browser
DEBUG - 2015-01-25 13:14:26 --> Total execution time: 0.0385
DEBUG - 2015-01-25 13:14:40 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:40 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:40 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:40 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:40 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:40 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:40 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Config Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:14:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:14:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:14:45 --> URI Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Router Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Output Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Security Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Input Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:14:45 --> Language Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Loader Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:14:45 --> Controller Class Initialized
DEBUG - 2015-01-25 13:14:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:14:45 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:14:45 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:14:45 --> Final output sent to browser
DEBUG - 2015-01-25 13:14:45 --> Total execution time: 0.0089
DEBUG - 2015-01-25 13:16:06 --> Config Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:16:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:16:06 --> URI Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Router Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Output Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Security Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Input Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:16:06 --> Language Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Loader Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:16:06 --> Controller Class Initialized
DEBUG - 2015-01-25 13:16:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:16:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:16:06 --> Final output sent to browser
DEBUG - 2015-01-25 13:16:06 --> Total execution time: 0.0048
DEBUG - 2015-01-25 13:16:08 --> Config Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:16:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:16:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:16:08 --> URI Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Router Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Output Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Security Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Input Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:16:08 --> Language Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Loader Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:16:08 --> Controller Class Initialized
DEBUG - 2015-01-25 13:16:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:16:08 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:16:08 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:16:08 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Config Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:16:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:16:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:16:18 --> URI Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Router Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Output Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Security Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Input Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:16:18 --> Language Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Loader Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:16:18 --> Controller Class Initialized
DEBUG - 2015-01-25 13:16:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:16:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:16:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:16:18 --> Final output sent to browser
DEBUG - 2015-01-25 13:16:18 --> Total execution time: 0.0109
DEBUG - 2015-01-25 13:16:21 --> Config Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:16:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:16:21 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:16:21 --> URI Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Router Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Output Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Security Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Input Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:16:21 --> Language Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Loader Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:16:21 --> Controller Class Initialized
DEBUG - 2015-01-25 13:16:21 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:16:21 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:16:21 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:16:21 --> Final output sent to browser
DEBUG - 2015-01-25 13:16:21 --> Total execution time: 0.0374
DEBUG - 2015-01-25 13:17:07 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:07 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:07 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:07 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:07 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:17:07 --> Final output sent to browser
DEBUG - 2015-01-25 13:17:07 --> Total execution time: 0.0049
DEBUG - 2015-01-25 13:17:10 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:10 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:10 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:10 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:10 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:17:10 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:17:10 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:17 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:17 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:17 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:17 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:17 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:17 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:17:17 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:17:17 --> Final output sent to browser
DEBUG - 2015-01-25 13:17:17 --> Total execution time: 0.0153
DEBUG - 2015-01-25 13:17:20 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:20 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:20 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:20 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:17:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:17:20 --> Final output sent to browser
DEBUG - 2015-01-25 13:17:20 --> Total execution time: 0.0384
DEBUG - 2015-01-25 13:17:53 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:53 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:53 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:53 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:17:53 --> Final output sent to browser
DEBUG - 2015-01-25 13:17:53 --> Total execution time: 0.0045
DEBUG - 2015-01-25 13:17:56 --> Config Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:17:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:17:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:17:56 --> URI Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Router Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Output Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Security Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Input Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:17:56 --> Language Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Loader Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:17:56 --> Controller Class Initialized
DEBUG - 2015-01-25 13:17:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:17:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:17:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:17:56 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Config Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:18:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:18:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:18:07 --> URI Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Router Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Output Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Security Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Input Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:18:07 --> Language Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Loader Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:18:07 --> Controller Class Initialized
DEBUG - 2015-01-25 13:18:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:18:07 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:18:07 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:18:07 --> Final output sent to browser
DEBUG - 2015-01-25 13:18:07 --> Total execution time: 0.0121
DEBUG - 2015-01-25 13:18:09 --> Config Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:18:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:18:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:18:09 --> URI Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Router Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Output Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Security Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Input Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:18:09 --> Language Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Loader Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:18:09 --> Controller Class Initialized
DEBUG - 2015-01-25 13:18:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:18:09 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:18:09 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:18:09 --> Final output sent to browser
DEBUG - 2015-01-25 13:18:09 --> Total execution time: 0.0088
DEBUG - 2015-01-25 13:18:12 --> Config Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:18:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:18:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:18:12 --> URI Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Router Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Output Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Security Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Input Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:18:12 --> Language Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Loader Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:18:12 --> Controller Class Initialized
DEBUG - 2015-01-25 13:18:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:18:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:18:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:18:12 --> Final output sent to browser
DEBUG - 2015-01-25 13:18:12 --> Total execution time: 0.0059
DEBUG - 2015-01-25 13:18:14 --> Config Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:18:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:18:14 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:18:14 --> URI Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Router Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Output Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Security Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Input Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:18:14 --> Language Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Loader Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:18:14 --> Controller Class Initialized
DEBUG - 2015-01-25 13:18:14 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:18:14 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:18:14 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:18:14 --> Final output sent to browser
DEBUG - 2015-01-25 13:18:14 --> Total execution time: 0.0420
DEBUG - 2015-01-25 13:22:53 --> Config Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:22:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:22:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:22:53 --> URI Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Router Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Output Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Security Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Input Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:22:53 --> Language Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Loader Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:22:53 --> Controller Class Initialized
DEBUG - 2015-01-25 13:22:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:22:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 13:22:53 --> Final output sent to browser
DEBUG - 2015-01-25 13:22:53 --> Total execution time: 0.0161
DEBUG - 2015-01-25 13:22:56 --> Config Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:22:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:22:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:22:56 --> URI Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Router Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Output Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Security Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Input Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:22:56 --> Language Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Loader Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:22:56 --> Controller Class Initialized
DEBUG - 2015-01-25 13:22:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:22:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:22:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:22:56 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Config Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:23:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:23:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:23:12 --> URI Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Router Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Output Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Security Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Input Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:23:12 --> Language Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Loader Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:23:12 --> Controller Class Initialized
DEBUG - 2015-01-25 13:23:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:23:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:23:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:23:12 --> Final output sent to browser
DEBUG - 2015-01-25 13:23:12 --> Total execution time: 0.0165
DEBUG - 2015-01-25 13:23:16 --> Config Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:23:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:23:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:23:16 --> URI Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Router Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Output Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Security Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Input Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:23:16 --> Language Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Loader Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:23:16 --> Controller Class Initialized
DEBUG - 2015-01-25 13:23:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:23:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:23:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:23:16 --> Final output sent to browser
DEBUG - 2015-01-25 13:23:16 --> Total execution time: 0.0057
DEBUG - 2015-01-25 13:23:22 --> Config Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:23:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:23:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:23:22 --> URI Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Router Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Output Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Security Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Input Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:23:22 --> Language Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Loader Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:23:22 --> Controller Class Initialized
DEBUG - 2015-01-25 13:23:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:23:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:23:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:23:22 --> Final output sent to browser
DEBUG - 2015-01-25 13:23:22 --> Total execution time: 0.0471
DEBUG - 2015-01-25 13:24:19 --> Config Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:24:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:24:19 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:24:19 --> URI Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Router Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Output Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Security Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Input Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:24:19 --> Language Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Loader Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:24:19 --> Controller Class Initialized
DEBUG - 2015-01-25 13:24:19 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:24:19 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:24:19 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:24:19 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Config Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:24:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:24:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:24:31 --> URI Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Router Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Output Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Security Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Input Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:24:31 --> Language Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Loader Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:24:31 --> Controller Class Initialized
DEBUG - 2015-01-25 13:24:31 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:24:31 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:24:31 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:24:31 --> Final output sent to browser
DEBUG - 2015-01-25 13:24:31 --> Total execution time: 0.0111
DEBUG - 2015-01-25 13:24:33 --> Config Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:24:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:24:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:24:33 --> URI Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Router Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Output Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Security Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Input Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:24:33 --> Language Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Loader Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:24:33 --> Controller Class Initialized
DEBUG - 2015-01-25 13:24:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:24:33 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:24:33 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:24:33 --> Final output sent to browser
DEBUG - 2015-01-25 13:24:33 --> Total execution time: 0.0438
DEBUG - 2015-01-25 13:25:38 --> Config Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:25:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:25:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:25:38 --> URI Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Router Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Output Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Security Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Input Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:25:38 --> Language Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Loader Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:25:38 --> Controller Class Initialized
DEBUG - 2015-01-25 13:25:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:25:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:25:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:25:38 --> User Agent Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Config Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 13:50:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 13:50:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 13:50:27 --> URI Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Router Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Output Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Security Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Input Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 13:50:27 --> Language Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Loader Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 13:50:27 --> Controller Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 13:50:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 13:50:27 --> Session: Regenerate ID
DEBUG - 2015-01-25 13:50:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 13:50:27 --> Final output sent to browser
DEBUG - 2015-01-25 13:50:27 --> Total execution time: 0.0544
DEBUG - 2015-01-25 14:30:12 --> Config Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:30:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:30:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:30:12 --> URI Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Router Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Output Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Security Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Input Class Initialized
DEBUG - 2015-01-25 14:30:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:30:12 --> Language Class Initialized
ERROR - 2015-01-25 14:30:12 --> 404 Page Not Found: ThegameAjaxTakeaway/index
DEBUG - 2015-01-25 14:31:15 --> Config Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:31:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:31:15 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:31:15 --> URI Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Router Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Output Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Security Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Input Class Initialized
DEBUG - 2015-01-25 14:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:31:15 --> Language Class Initialized
ERROR - 2015-01-25 14:31:15 --> 404 Page Not Found: ThegameAjaxTakeAway/index
DEBUG - 2015-01-25 14:31:25 --> Config Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:31:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:31:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:31:25 --> URI Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Router Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Output Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Security Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Input Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:31:25 --> Language Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Loader Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:31:25 --> Controller Class Initialized
DEBUG - 2015-01-25 14:31:25 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:31:25 --> Session: Regenerate ID
DEBUG - 2015-01-25 14:31:25 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:38:24 --> Config Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:38:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:38:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:38:24 --> URI Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Router Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Output Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Security Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Input Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:38:24 --> Language Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Loader Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:38:24 --> Controller Class Initialized
DEBUG - 2015-01-25 14:38:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:38:24 --> Session: Regenerate ID
DEBUG - 2015-01-25 14:38:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:39:37 --> Config Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:39:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:39:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:39:37 --> URI Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Router Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Output Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Security Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Input Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:39:37 --> Language Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Loader Class Initialized
DEBUG - 2015-01-25 14:39:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:39:37 --> Controller Class Initialized
DEBUG - 2015-01-25 14:39:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:39:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:39:53 --> Config Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:39:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:39:53 --> URI Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Router Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Output Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Security Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Input Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:39:53 --> Language Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Loader Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:39:53 --> Controller Class Initialized
DEBUG - 2015-01-25 14:39:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:39:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:39:53 --> Final output sent to browser
DEBUG - 2015-01-25 14:39:53 --> Total execution time: 0.0039
DEBUG - 2015-01-25 14:41:49 --> Config Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:41:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:41:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:41:49 --> URI Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Router Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Output Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Security Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Input Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:41:49 --> Language Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Loader Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:41:49 --> Controller Class Initialized
DEBUG - 2015-01-25 14:41:49 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:41:49 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:41:49 --> Final output sent to browser
DEBUG - 2015-01-25 14:41:49 --> Total execution time: 0.0090
DEBUG - 2015-01-25 14:43:19 --> Config Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:43:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:43:19 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:43:19 --> URI Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Router Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Output Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Security Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Input Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:43:19 --> Language Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Loader Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:43:19 --> Controller Class Initialized
DEBUG - 2015-01-25 14:43:19 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:43:19 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:43:19 --> Final output sent to browser
DEBUG - 2015-01-25 14:43:19 --> Total execution time: 0.0064
DEBUG - 2015-01-25 14:44:07 --> Config Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:44:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:44:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:44:07 --> URI Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Router Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Output Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Security Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Input Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:44:07 --> Language Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Loader Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:44:07 --> Controller Class Initialized
DEBUG - 2015-01-25 14:44:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:44:07 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:44:07 --> Final output sent to browser
DEBUG - 2015-01-25 14:44:07 --> Total execution time: 0.0035
DEBUG - 2015-01-25 14:44:41 --> Config Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:44:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:44:41 --> URI Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Router Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Output Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Security Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Input Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:44:41 --> Language Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Loader Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:44:41 --> Controller Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:44:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:44:41 --> Session: Regenerate ID
DEBUG - 2015-01-25 14:44:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:44:41 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Config Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:44:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:44:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:44:46 --> URI Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Router Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Output Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Security Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Input Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:44:46 --> Language Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Loader Class Initialized
DEBUG - 2015-01-25 14:44:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:44:46 --> Controller Class Initialized
DEBUG - 2015-01-25 14:44:46 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:44:46 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:44:49 --> Config Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:44:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:44:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:44:49 --> URI Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Router Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Output Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Security Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Input Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:44:49 --> Language Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Loader Class Initialized
DEBUG - 2015-01-25 14:44:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:44:49 --> Controller Class Initialized
DEBUG - 2015-01-25 14:44:49 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:44:49 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:44:59 --> Config Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:44:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:44:59 --> URI Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Router Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Output Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Security Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Input Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:44:59 --> Language Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Loader Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:44:59 --> Controller Class Initialized
DEBUG - 2015-01-25 14:44:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:44:59 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:44:59 --> Final output sent to browser
DEBUG - 2015-01-25 14:44:59 --> Total execution time: 0.0034
DEBUG - 2015-01-25 14:45:17 --> Config Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:45:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:45:17 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:45:17 --> URI Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Router Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Output Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Security Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Input Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:45:17 --> Language Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Loader Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:45:17 --> Controller Class Initialized
DEBUG - 2015-01-25 14:45:17 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:45:17 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:45:17 --> Final output sent to browser
DEBUG - 2015-01-25 14:45:17 --> Total execution time: 0.0045
DEBUG - 2015-01-25 14:46:17 --> Config Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:46:17 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:46:17 --> URI Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Router Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Output Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Security Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Input Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:46:17 --> Language Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Loader Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:46:17 --> Controller Class Initialized
DEBUG - 2015-01-25 14:46:17 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:46:17 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:46:17 --> Final output sent to browser
DEBUG - 2015-01-25 14:46:17 --> Total execution time: 0.0169
DEBUG - 2015-01-25 14:46:19 --> Config Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:46:19 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:46:19 --> URI Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Router Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Output Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Security Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Input Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:46:19 --> Language Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Loader Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:46:19 --> Controller Class Initialized
DEBUG - 2015-01-25 14:46:19 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:46:19 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:46:19 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:46:19 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Config Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:47:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:47:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:47:27 --> URI Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Router Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Output Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Security Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Input Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:47:27 --> Language Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Loader Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:47:27 --> Controller Class Initialized
DEBUG - 2015-01-25 14:47:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:47:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:47:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:47:27 --> Final output sent to browser
DEBUG - 2015-01-25 14:47:27 --> Total execution time: 0.0082
DEBUG - 2015-01-25 14:47:31 --> Config Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:47:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:47:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:47:31 --> URI Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Router Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Output Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Security Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Input Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:47:31 --> Language Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Loader Class Initialized
DEBUG - 2015-01-25 14:47:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:47:31 --> Controller Class Initialized
DEBUG - 2015-01-25 14:47:31 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:47:31 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:48:38 --> Config Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:48:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:48:38 --> URI Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Router Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Output Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Security Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Input Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:48:38 --> Language Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Loader Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:48:38 --> Controller Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Config Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:48:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:48:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:48:38 --> URI Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Router Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Output Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Security Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Input Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:48:38 --> Language Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Loader Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:48:38 --> Controller Class Initialized
DEBUG - 2015-01-25 14:48:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:48:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:48:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:48:38 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Config Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:48:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:48:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:48:48 --> URI Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Router Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Output Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Security Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Input Class Initialized
DEBUG - 2015-01-25 14:48:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:48:48 --> Language Class Initialized
ERROR - 2015-01-25 14:48:48 --> 404 Page Not Found: ThegameAjaxAway/index
DEBUG - 2015-01-25 14:48:58 --> Config Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:48:58 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:48:58 --> URI Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Router Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Output Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Security Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Input Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:48:58 --> Language Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Loader Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:48:58 --> Controller Class Initialized
DEBUG - 2015-01-25 14:48:58 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:48:58 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:48:58 --> Final output sent to browser
DEBUG - 2015-01-25 14:48:58 --> Total execution time: 0.0124
DEBUG - 2015-01-25 14:49:01 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:01 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:01 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:01 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:49:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:49:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:49:01 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:19 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:19 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:19 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:19 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:19 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:49:19 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:49:19 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:49:19 --> Final output sent to browser
DEBUG - 2015-01-25 14:49:19 --> Total execution time: 0.0126
DEBUG - 2015-01-25 14:49:22 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:22 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:22 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:22 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:49:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:49:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:49:22 --> Final output sent to browser
DEBUG - 2015-01-25 14:49:22 --> Total execution time: 0.0051
DEBUG - 2015-01-25 14:49:26 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:26 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:26 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:26 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:49:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:49:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:49:26 --> Final output sent to browser
DEBUG - 2015-01-25 14:49:26 --> Total execution time: 0.0092
DEBUG - 2015-01-25 14:49:32 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:32 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:32 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:32 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:32 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:32 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:49:32 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:49:32 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:49:32 --> Final output sent to browser
DEBUG - 2015-01-25 14:49:32 --> Total execution time: 0.0062
DEBUG - 2015-01-25 14:49:35 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:35 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:35 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:35 --> Controller Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Config Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:49:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:49:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:49:54 --> URI Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Router Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Output Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Security Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Input Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:49:54 --> Language Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Loader Class Initialized
DEBUG - 2015-01-25 14:49:54 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:49:54 --> Controller Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Config Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:50:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:50:06 --> URI Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Router Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Output Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Security Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Input Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:50:06 --> Language Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Loader Class Initialized
DEBUG - 2015-01-25 14:50:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:50:06 --> Controller Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Config Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:50:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:50:26 --> URI Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Router Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Output Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Security Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Input Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:50:26 --> Language Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Loader Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:50:26 --> Controller Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:50:26 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:50:26 --> Session: Regenerate ID
DEBUG - 2015-01-25 14:50:26 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:50:26 --> Final output sent to browser
DEBUG - 2015-01-25 14:50:26 --> Total execution time: 0.0153
DEBUG - 2015-01-25 14:50:27 --> Config Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:50:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:50:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:50:27 --> URI Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Router Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Output Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Security Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Input Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:50:27 --> Language Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Loader Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:50:27 --> Controller Class Initialized
DEBUG - 2015-01-25 14:50:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:50:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:50:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:50:27 --> Final output sent to browser
DEBUG - 2015-01-25 14:50:27 --> Total execution time: 0.0048
DEBUG - 2015-01-25 14:51:02 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:02 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:02 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Loader Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:51:02 --> Controller Class Initialized
DEBUG - 2015-01-25 14:51:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:51:02 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:51:02 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:51:02 --> Final output sent to browser
DEBUG - 2015-01-25 14:51:02 --> Total execution time: 0.0061
DEBUG - 2015-01-25 14:51:03 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:03 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:03 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:03 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Loader Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:51:03 --> Controller Class Initialized
DEBUG - 2015-01-25 14:51:03 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:51:03 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:51:03 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:51:03 --> Final output sent to browser
DEBUG - 2015-01-25 14:51:03 --> Total execution time: 0.0033
DEBUG - 2015-01-25 14:51:28 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:28 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:28 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:28 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:39 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:39 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:39 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:40 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:40 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:40 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:40 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:40 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:40 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:41 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:41 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:41 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:41 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:41 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:41 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:49 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:49 --> Language Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Config Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:51:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:51:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:51:50 --> URI Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Router Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Output Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Security Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Input Class Initialized
DEBUG - 2015-01-25 14:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:51:50 --> Language Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Config Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:52:43 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:52:43 --> URI Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Router Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Output Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Security Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Input Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:52:43 --> Language Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Config Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:52:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:52:43 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:52:43 --> URI Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Router Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Output Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Security Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Input Class Initialized
DEBUG - 2015-01-25 14:52:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:52:43 --> Language Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Config Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:53:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:53:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:53:02 --> URI Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Router Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Output Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Security Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Input Class Initialized
DEBUG - 2015-01-25 14:53:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:53:02 --> Language Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Config Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:53:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:53:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:53:06 --> URI Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Router Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Output Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Security Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Input Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:53:06 --> Language Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Loader Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:53:06 --> Controller Class Initialized
DEBUG - 2015-01-25 14:53:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:53:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:53:06 --> Final output sent to browser
DEBUG - 2015-01-25 14:53:06 --> Total execution time: 0.0046
DEBUG - 2015-01-25 14:53:09 --> Config Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:53:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:53:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:53:09 --> URI Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Router Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Output Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Security Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Input Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:53:09 --> Language Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Loader Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:53:09 --> Controller Class Initialized
DEBUG - 2015-01-25 14:53:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:53:09 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:53:09 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:53:09 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Config Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:53:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:53:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:53:13 --> URI Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Router Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Output Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Security Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Input Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:53:13 --> Language Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Loader Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:53:13 --> Controller Class Initialized
DEBUG - 2015-01-25 14:53:13 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:53:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:53:13 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:53:13 --> Final output sent to browser
DEBUG - 2015-01-25 14:53:13 --> Total execution time: 0.0147
DEBUG - 2015-01-25 14:53:30 --> Config Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:53:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:53:30 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:53:30 --> URI Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Router Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Output Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Security Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Input Class Initialized
DEBUG - 2015-01-25 14:53:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:53:30 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:08 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:08 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:08 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:08 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:54:08 --> Final output sent to browser
DEBUG - 2015-01-25 14:54:08 --> Total execution time: 0.0050
DEBUG - 2015-01-25 14:54:16 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:16 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:16 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:16 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:54:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:54:16 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:24 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:24 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:24 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:54:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:54:24 --> Final output sent to browser
DEBUG - 2015-01-25 14:54:24 --> Total execution time: 0.0113
DEBUG - 2015-01-25 14:54:26 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:26 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:26 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:26 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:30 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:30 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:30 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:30 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:30 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:30 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 14:54:30 --> Final output sent to browser
DEBUG - 2015-01-25 14:54:30 --> Total execution time: 0.0049
DEBUG - 2015-01-25 14:54:45 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:45 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:45 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:45 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:45 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:54:45 --> A session cookie was not found.
DEBUG - 2015-01-25 14:54:45 --> Session: Creating new session (fc4b0556923d806bae6d472a2923b148)
DEBUG - 2015-01-25 14:54:45 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:54:45 --> User Agent Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Config Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:54:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:54:58 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:54:58 --> URI Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Router Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Output Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Security Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Input Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:54:58 --> Language Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Loader Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Helper loaded: url_helper
DEBUG - 2015-01-25 14:54:58 --> Controller Class Initialized
DEBUG - 2015-01-25 14:54:58 --> Database Driver Class Initialized
DEBUG - 2015-01-25 14:54:58 --> CI_Session Class Initialized
DEBUG - 2015-01-25 14:54:58 --> CI_Session routines successfully run
DEBUG - 2015-01-25 14:54:58 --> Final output sent to browser
DEBUG - 2015-01-25 14:54:58 --> Total execution time: 0.0112
DEBUG - 2015-01-25 14:55:10 --> Config Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:55:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:55:10 --> URI Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Router Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Output Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Security Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Input Class Initialized
DEBUG - 2015-01-25 14:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:55:10 --> Language Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Config Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:55:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:55:15 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:55:15 --> URI Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Router Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Output Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Security Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Input Class Initialized
DEBUG - 2015-01-25 14:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:55:15 --> Language Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Config Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 14:55:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 14:55:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 14:55:16 --> URI Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Router Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Output Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Security Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Input Class Initialized
DEBUG - 2015-01-25 14:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 14:55:16 --> Language Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Config Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:06:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:06:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:06:34 --> URI Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Router Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Output Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Security Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Input Class Initialized
DEBUG - 2015-01-25 15:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:06:34 --> Language Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Config Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:06:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:06:52 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:06:52 --> URI Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Router Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Output Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Security Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Input Class Initialized
DEBUG - 2015-01-25 15:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:06:52 --> Language Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Config Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:06:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:06:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:06:53 --> URI Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Router Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Output Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Security Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Input Class Initialized
DEBUG - 2015-01-25 15:06:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:06:53 --> Language Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Config Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:06:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:06:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:06:54 --> URI Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Router Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Output Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Security Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Input Class Initialized
DEBUG - 2015-01-25 15:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:06:54 --> Language Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Config Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:07:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:07:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:07:13 --> URI Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Router Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Output Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Security Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Input Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:07:13 --> Language Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Loader Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:07:13 --> Controller Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:07:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:07:13 --> Session: Regenerate ID
DEBUG - 2015-01-25 15:07:13 --> CI_Session routines successfully run
ERROR - 2015-01-25 15:07:13 --> Severity: Notice --> Undefined index: currentprize /var/www/WhoWantsToBeAMilionaire/application/controllers/ThegameAjaxTakeAway.php 22
ERROR - 2015-01-25 15:07:13 --> Severity: Notice --> Undefined variable: _precioactual /var/www/WhoWantsToBeAMilionaire/application/controllers/ThegameAjaxTakeAway.php 34
DEBUG - 2015-01-25 15:07:13 --> Final output sent to browser
DEBUG - 2015-01-25 15:07:13 --> Total execution time: 0.0255
DEBUG - 2015-01-25 15:07:29 --> Config Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:07:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:07:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:07:29 --> URI Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Router Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Output Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Security Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Input Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:07:29 --> Language Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Loader Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:07:29 --> Controller Class Initialized
DEBUG - 2015-01-25 15:07:29 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:07:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:07:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:07:29 --> Final output sent to browser
DEBUG - 2015-01-25 15:07:29 --> Total execution time: 0.0037
DEBUG - 2015-01-25 15:08:10 --> Config Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:08:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:08:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:08:10 --> URI Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Router Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Output Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Security Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Input Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:08:10 --> Language Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Loader Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:08:10 --> Controller Class Initialized
DEBUG - 2015-01-25 15:08:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:08:10 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:08:10 --> Final output sent to browser
DEBUG - 2015-01-25 15:08:10 --> Total execution time: 0.0045
DEBUG - 2015-01-25 15:08:22 --> Config Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:08:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:08:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:08:22 --> URI Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Router Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Output Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Security Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Input Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:08:22 --> Language Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Loader Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:08:22 --> Controller Class Initialized
DEBUG - 2015-01-25 15:08:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:08:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:08:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:08:22 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Config Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:08:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:08:34 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:08:34 --> URI Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Router Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Output Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Security Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Input Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:08:34 --> Language Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Loader Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:08:34 --> Controller Class Initialized
DEBUG - 2015-01-25 15:08:34 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:08:34 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:08:34 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:08:34 --> Final output sent to browser
DEBUG - 2015-01-25 15:08:34 --> Total execution time: 0.0111
DEBUG - 2015-01-25 15:08:38 --> Config Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:08:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:08:38 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:08:38 --> URI Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Router Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Output Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Security Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Input Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:08:38 --> Language Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Loader Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:08:38 --> Controller Class Initialized
DEBUG - 2015-01-25 15:08:38 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:08:38 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:08:38 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:08:38 --> Final output sent to browser
DEBUG - 2015-01-25 15:08:38 --> Total execution time: 0.0053
DEBUG - 2015-01-25 15:10:40 --> Config Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:10:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:10:40 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:10:40 --> URI Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Router Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Output Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Security Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Input Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:10:40 --> Language Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Loader Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:10:40 --> Controller Class Initialized
DEBUG - 2015-01-25 15:10:40 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:10:40 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:10:40 --> Final output sent to browser
DEBUG - 2015-01-25 15:10:40 --> Total execution time: 0.0042
DEBUG - 2015-01-25 15:10:49 --> Config Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:10:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:10:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:10:49 --> URI Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Router Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Output Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Security Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Input Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:10:49 --> Language Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Loader Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:10:49 --> Controller Class Initialized
DEBUG - 2015-01-25 15:10:49 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:10:49 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:10:49 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:10:49 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Config Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:11:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:11:02 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:11:02 --> URI Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Router Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Output Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Security Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Input Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:11:02 --> Language Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Loader Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:11:02 --> Controller Class Initialized
DEBUG - 2015-01-25 15:11:02 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:11:02 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:11:02 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:11:02 --> Final output sent to browser
DEBUG - 2015-01-25 15:11:02 --> Total execution time: 0.0136
DEBUG - 2015-01-25 15:11:05 --> Config Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:11:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:11:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:11:05 --> URI Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Router Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Output Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Security Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Input Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:11:05 --> Language Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Loader Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:11:05 --> Controller Class Initialized
DEBUG - 2015-01-25 15:11:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:11:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:11:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:11:05 --> Final output sent to browser
DEBUG - 2015-01-25 15:11:05 --> Total execution time: 0.0048
DEBUG - 2015-01-25 15:11:08 --> Config Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:11:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:11:08 --> URI Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Router Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Output Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Security Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Input Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:11:08 --> Language Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Loader Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:11:08 --> Controller Class Initialized
DEBUG - 2015-01-25 15:11:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:11:08 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:11:08 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:11:08 --> Final output sent to browser
DEBUG - 2015-01-25 15:11:08 --> Total execution time: 0.0049
DEBUG - 2015-01-25 15:11:11 --> Config Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:11:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:11:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:11:11 --> URI Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Router Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Output Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Security Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Input Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:11:11 --> Language Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Loader Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:11:11 --> Controller Class Initialized
DEBUG - 2015-01-25 15:11:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:11:11 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:11:11 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:11:11 --> Final output sent to browser
DEBUG - 2015-01-25 15:11:11 --> Total execution time: 0.0042
DEBUG - 2015-01-25 15:12:59 --> Config Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:12:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:12:59 --> URI Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Router Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Output Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Security Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Input Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:12:59 --> Language Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Loader Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:12:59 --> Controller Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:12:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:12:59 --> Session: Regenerate ID
DEBUG - 2015-01-25 15:12:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:12:59 --> Final output sent to browser
DEBUG - 2015-01-25 15:12:59 --> Total execution time: 0.0062
DEBUG - 2015-01-25 15:13:10 --> Config Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:13:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:13:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:13:10 --> URI Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Router Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Output Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Security Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Input Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:13:10 --> Language Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Loader Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:13:10 --> Controller Class Initialized
DEBUG - 2015-01-25 15:13:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:13:10 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:13:10 --> Final output sent to browser
DEBUG - 2015-01-25 15:13:10 --> Total execution time: 0.0041
DEBUG - 2015-01-25 15:17:47 --> Config Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:17:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:17:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:17:47 --> URI Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Router Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Output Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Security Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Input Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:17:47 --> Language Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Loader Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:17:47 --> Controller Class Initialized
DEBUG - 2015-01-25 15:17:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:17:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:17:47 --> Final output sent to browser
DEBUG - 2015-01-25 15:17:47 --> Total execution time: 0.0098
DEBUG - 2015-01-25 15:18:39 --> Config Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:18:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:18:39 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:18:39 --> URI Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Router Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Output Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Security Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Input Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:18:39 --> Language Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Loader Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:18:39 --> Controller Class Initialized
DEBUG - 2015-01-25 15:18:39 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:18:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:18:39 --> Final output sent to browser
DEBUG - 2015-01-25 15:18:39 --> Total execution time: 0.0034
DEBUG - 2015-01-25 15:18:47 --> Config Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:18:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:18:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:18:47 --> URI Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Router Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Output Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Security Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Input Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:18:47 --> Language Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Loader Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:18:47 --> Controller Class Initialized
DEBUG - 2015-01-25 15:18:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:18:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:18:47 --> Final output sent to browser
DEBUG - 2015-01-25 15:18:47 --> Total execution time: 0.0036
DEBUG - 2015-01-25 15:19:50 --> Config Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:19:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:19:50 --> URI Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Router Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Output Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Security Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Input Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:19:50 --> Language Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Loader Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:19:50 --> Controller Class Initialized
DEBUG - 2015-01-25 15:19:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:19:50 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:19:50 --> Final output sent to browser
DEBUG - 2015-01-25 15:19:50 --> Total execution time: 0.0050
DEBUG - 2015-01-25 15:20:00 --> Config Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:20:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:20:00 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:20:00 --> URI Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Router Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Output Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Security Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Input Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:20:00 --> Language Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Loader Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:20:00 --> Controller Class Initialized
DEBUG - 2015-01-25 15:20:00 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:20:00 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:20:00 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:20:00 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Config Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:27:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:27:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:27:56 --> URI Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Router Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Output Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Security Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Input Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:27:56 --> Language Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Loader Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:27:56 --> Controller Class Initialized
DEBUG - 2015-01-25 15:27:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:27:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:27:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:27:56 --> Final output sent to browser
DEBUG - 2015-01-25 15:27:56 --> Total execution time: 0.0116
DEBUG - 2015-01-25 15:27:58 --> Config Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:27:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:27:58 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:27:58 --> URI Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Router Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Output Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Security Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Input Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:27:58 --> Language Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Loader Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:27:58 --> Controller Class Initialized
DEBUG - 2015-01-25 15:27:58 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:27:58 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:27:58 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:27:58 --> Final output sent to browser
DEBUG - 2015-01-25 15:27:58 --> Total execution time: 0.0051
DEBUG - 2015-01-25 15:28:01 --> Config Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:28:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:28:01 --> URI Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Router Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Output Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Security Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Input Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:28:01 --> Language Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Loader Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:28:01 --> Controller Class Initialized
DEBUG - 2015-01-25 15:28:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:28:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:28:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:28:01 --> Final output sent to browser
DEBUG - 2015-01-25 15:28:01 --> Total execution time: 0.0070
DEBUG - 2015-01-25 15:28:04 --> Config Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:28:04 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:28:04 --> URI Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Router Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Output Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Security Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Input Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:28:04 --> Language Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Loader Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:28:04 --> Controller Class Initialized
DEBUG - 2015-01-25 15:28:04 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:28:04 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:28:04 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:28:04 --> Final output sent to browser
DEBUG - 2015-01-25 15:28:04 --> Total execution time: 0.0041
DEBUG - 2015-01-25 15:28:20 --> Config Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:28:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:28:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:28:20 --> URI Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Router Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Output Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Security Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Input Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:28:20 --> Language Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Loader Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:28:20 --> Controller Class Initialized
DEBUG - 2015-01-25 15:28:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:28:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:28:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:28:20 --> Final output sent to browser
DEBUG - 2015-01-25 15:28:20 --> Total execution time: 0.0044
DEBUG - 2015-01-25 15:30:16 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:16 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:16 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:16 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:16 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:30:16 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:16 --> Total execution time: 0.0060
DEBUG - 2015-01-25 15:30:23 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:23 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:24 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:24 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:24 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:24 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:45 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:45 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:45 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:45 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:45 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:45 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:45 --> Total execution time: 0.0147
DEBUG - 2015-01-25 15:30:47 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:47 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:47 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:47 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:47 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:47 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:47 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:47 --> Total execution time: 0.0048
DEBUG - 2015-01-25 15:30:51 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:51 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:51 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:51 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:51 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:51 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:51 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:51 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:51 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:51 --> Total execution time: 0.0047
DEBUG - 2015-01-25 15:30:54 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:54 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:54 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:54 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:54 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:54 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:54 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:54 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:54 --> Total execution time: 0.0056
DEBUG - 2015-01-25 15:30:56 --> Config Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:30:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:30:56 --> URI Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Router Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Output Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Security Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Input Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:30:56 --> Language Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Loader Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:30:56 --> Controller Class Initialized
DEBUG - 2015-01-25 15:30:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:30:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:30:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:30:56 --> Final output sent to browser
DEBUG - 2015-01-25 15:30:56 --> Total execution time: 0.0043
DEBUG - 2015-01-25 15:32:48 --> Config Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:32:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:32:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:32:48 --> URI Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Router Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Output Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Security Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Input Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:32:48 --> Language Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Loader Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:32:48 --> Controller Class Initialized
DEBUG - 2015-01-25 15:32:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:32:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:32:48 --> Final output sent to browser
DEBUG - 2015-01-25 15:32:48 --> Total execution time: 0.0107
DEBUG - 2015-01-25 15:32:50 --> Config Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:32:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:32:50 --> URI Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Router Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Output Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Security Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Input Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:32:50 --> Language Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Loader Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:32:50 --> Controller Class Initialized
DEBUG - 2015-01-25 15:32:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:32:50 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:32:50 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:32:50 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Config Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:33:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:33:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:33:01 --> URI Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Router Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Output Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Security Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Input Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:33:01 --> Language Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Loader Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:33:01 --> Controller Class Initialized
DEBUG - 2015-01-25 15:33:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:33:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:33:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:33:01 --> Final output sent to browser
DEBUG - 2015-01-25 15:33:01 --> Total execution time: 0.0065
DEBUG - 2015-01-25 15:33:03 --> Config Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:33:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:33:03 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:33:03 --> URI Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Router Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Output Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Security Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Input Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:33:03 --> Language Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Loader Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:33:03 --> Controller Class Initialized
DEBUG - 2015-01-25 15:33:03 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:33:03 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:33:03 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:33:03 --> Final output sent to browser
DEBUG - 2015-01-25 15:33:03 --> Total execution time: 0.0051
DEBUG - 2015-01-25 15:33:57 --> Config Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:33:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:33:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:33:57 --> URI Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Router Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Output Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Security Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Input Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:33:57 --> Language Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Loader Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:33:57 --> Controller Class Initialized
DEBUG - 2015-01-25 15:33:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:33:57 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:33:57 --> Final output sent to browser
DEBUG - 2015-01-25 15:33:57 --> Total execution time: 0.0040
DEBUG - 2015-01-25 15:33:59 --> Config Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:33:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:33:59 --> URI Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Router Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Output Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Security Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Input Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:33:59 --> Language Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Loader Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:33:59 --> Controller Class Initialized
DEBUG - 2015-01-25 15:33:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:33:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:33:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:33:59 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Config Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:34:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:34:08 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:34:08 --> URI Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Router Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Output Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Security Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Input Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:34:08 --> Language Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Loader Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:34:08 --> Controller Class Initialized
DEBUG - 2015-01-25 15:34:08 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:34:08 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:34:08 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:34:08 --> Final output sent to browser
DEBUG - 2015-01-25 15:34:08 --> Total execution time: 0.0203
DEBUG - 2015-01-25 15:34:10 --> Config Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:34:10 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:34:10 --> URI Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Router Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Output Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Security Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Input Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:34:10 --> Language Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Loader Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:34:10 --> Controller Class Initialized
DEBUG - 2015-01-25 15:34:10 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:34:10 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:34:10 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:34:10 --> Final output sent to browser
DEBUG - 2015-01-25 15:34:10 --> Total execution time: 0.0087
DEBUG - 2015-01-25 15:34:13 --> Config Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:34:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:34:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:34:13 --> URI Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Router Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Output Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Security Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Input Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:34:13 --> Language Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Loader Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:34:13 --> Controller Class Initialized
DEBUG - 2015-01-25 15:34:13 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:34:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:34:13 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:34:13 --> Final output sent to browser
DEBUG - 2015-01-25 15:34:13 --> Total execution time: 0.0052
DEBUG - 2015-01-25 15:34:18 --> Config Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:34:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:34:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:34:18 --> URI Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Router Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Output Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Security Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Input Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:34:18 --> Language Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Loader Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:34:18 --> Controller Class Initialized
DEBUG - 2015-01-25 15:34:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:34:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:34:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:34:18 --> Final output sent to browser
DEBUG - 2015-01-25 15:34:18 --> Total execution time: 0.0058
DEBUG - 2015-01-25 15:34:22 --> Config Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:34:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:34:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:34:22 --> URI Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Router Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Output Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Security Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Input Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:34:22 --> Language Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Loader Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:34:22 --> Controller Class Initialized
DEBUG - 2015-01-25 15:34:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:34:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:34:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:34:22 --> Final output sent to browser
DEBUG - 2015-01-25 15:34:22 --> Total execution time: 0.0047
DEBUG - 2015-01-25 15:35:03 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:03 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:03 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:03 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:03 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:03 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:03 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:35:03 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:03 --> Total execution time: 0.0049
DEBUG - 2015-01-25 15:35:06 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:06 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:06 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:06 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:06 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:06 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:06 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:06 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:25 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:25 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:25 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:25 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:25 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:25 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:25 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:25 --> Total execution time: 0.0123
DEBUG - 2015-01-25 15:35:29 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:29 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:29 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:29 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:29 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:29 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:29 --> Total execution time: 0.0064
DEBUG - 2015-01-25 15:35:33 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:33 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:33 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:33 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:33 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:33 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:33 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:33 --> Total execution time: 0.0063
DEBUG - 2015-01-25 15:35:44 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:44 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:44 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:44 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:44 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:44 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:44 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:44 --> Total execution time: 0.0088
DEBUG - 2015-01-25 15:35:48 --> Config Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:35:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:35:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:35:48 --> URI Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Router Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Output Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Security Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Input Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:35:48 --> Language Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Loader Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:35:48 --> Controller Class Initialized
DEBUG - 2015-01-25 15:35:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:35:48 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:35:48 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:35:48 --> Final output sent to browser
DEBUG - 2015-01-25 15:35:48 --> Total execution time: 0.0050
DEBUG - 2015-01-25 15:36:44 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:44 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:44 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:44 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:44 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:36:44 --> Final output sent to browser
DEBUG - 2015-01-25 15:36:44 --> Total execution time: 0.0049
DEBUG - 2015-01-25 15:36:46 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:46 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:46 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:46 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:46 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:46 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:36:46 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:36:46 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:52 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:52 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:52 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:52 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:52 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:52 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:36:52 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:36:52 --> Final output sent to browser
DEBUG - 2015-01-25 15:36:52 --> Total execution time: 0.0116
DEBUG - 2015-01-25 15:36:54 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:54 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:54 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:54 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:54 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:54 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:54 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:36:54 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:36:54 --> Final output sent to browser
DEBUG - 2015-01-25 15:36:54 --> Total execution time: 0.0064
DEBUG - 2015-01-25 15:36:57 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:57 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:57 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:57 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:57 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:36:57 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:36:57 --> Final output sent to browser
DEBUG - 2015-01-25 15:36:57 --> Total execution time: 0.0050
DEBUG - 2015-01-25 15:36:59 --> Config Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:36:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:36:59 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:36:59 --> URI Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Router Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Output Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Security Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Input Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:36:59 --> Language Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Loader Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:36:59 --> Controller Class Initialized
DEBUG - 2015-01-25 15:36:59 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:36:59 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:36:59 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:36:59 --> Final output sent to browser
DEBUG - 2015-01-25 15:36:59 --> Total execution time: 0.0068
DEBUG - 2015-01-25 15:37:01 --> Config Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:37:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:37:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:37:01 --> URI Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Router Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Output Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Security Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Input Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:37:01 --> Language Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Loader Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:37:01 --> Controller Class Initialized
DEBUG - 2015-01-25 15:37:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:37:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:37:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:37:01 --> Final output sent to browser
DEBUG - 2015-01-25 15:37:01 --> Total execution time: 0.0039
DEBUG - 2015-01-25 15:46:14 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:14 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:14 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:14 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:14 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:14 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:46:14 --> Final output sent to browser
DEBUG - 2015-01-25 15:46:14 --> Total execution time: 0.0057
DEBUG - 2015-01-25 15:46:16 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:16 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:16 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:16 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:46:16 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:35 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:35 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:35 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:35 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:35 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:46:35 --> Final output sent to browser
DEBUG - 2015-01-25 15:46:35 --> Total execution time: 0.0110
DEBUG - 2015-01-25 15:46:39 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:39 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:39 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:39 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:39 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:39 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:39 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:39 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:46:39 --> Final output sent to browser
DEBUG - 2015-01-25 15:46:39 --> Total execution time: 0.0048
DEBUG - 2015-01-25 15:46:43 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:43 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:43 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:43 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:43 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:43 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:43 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:43 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:46:43 --> Final output sent to browser
DEBUG - 2015-01-25 15:46:43 --> Total execution time: 0.0051
DEBUG - 2015-01-25 15:46:44 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:44 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:44 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:44 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:46:44 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:44 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:46:44 --> Final output sent to browser
DEBUG - 2015-01-25 15:46:44 --> Total execution time: 0.0047
DEBUG - 2015-01-25 15:46:49 --> Config Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:46:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:46:49 --> URI Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Router Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Output Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Security Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Input Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:46:49 --> Language Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Loader Class Initialized
DEBUG - 2015-01-25 15:46:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:46:49 --> Controller Class Initialized
DEBUG - 2015-01-25 15:46:49 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:46:49 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:48:28 --> Config Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:48:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:48:28 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:48:28 --> URI Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Router Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Output Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Security Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Input Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:48:28 --> Language Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Loader Class Initialized
DEBUG - 2015-01-25 15:48:28 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:48:28 --> Controller Class Initialized
DEBUG - 2015-01-25 15:48:28 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:48:28 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:48:29 --> Config Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:48:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:48:29 --> URI Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Router Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Output Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Security Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Input Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:48:29 --> Language Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Loader Class Initialized
DEBUG - 2015-01-25 15:48:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:48:29 --> Controller Class Initialized
DEBUG - 2015-01-25 15:48:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:48:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:49:57 --> Config Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:49:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:49:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:49:57 --> URI Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Router Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Output Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Security Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Input Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:49:57 --> Language Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Loader Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:49:57 --> Controller Class Initialized
DEBUG - 2015-01-25 15:49:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:49:57 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 15:49:57 --> Final output sent to browser
DEBUG - 2015-01-25 15:49:57 --> Total execution time: 0.0045
DEBUG - 2015-01-25 15:50:00 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:00 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:00 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:00 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:00 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:00 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:50:00 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:00 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:00 --> User Agent Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:09 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:09 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:09 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:50:09 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:09 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:09 --> Final output sent to browser
DEBUG - 2015-01-25 15:50:09 --> Total execution time: 0.0086
DEBUG - 2015-01-25 15:50:11 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:11 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:11 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:11 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:50:11 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:11 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:11 --> Final output sent to browser
DEBUG - 2015-01-25 15:50:11 --> Total execution time: 0.0074
DEBUG - 2015-01-25 15:50:13 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:13 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:13 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:13 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:13 --> Database Driver Class Initialized
DEBUG - 2015-01-25 15:50:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:13 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:13 --> Final output sent to browser
DEBUG - 2015-01-25 15:50:13 --> Total execution time: 0.0048
DEBUG - 2015-01-25 15:50:18 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:18 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:18 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:18 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:20 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:20 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:20 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:20 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 15:50:21 --> Config Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Hooks Class Initialized
DEBUG - 2015-01-25 15:50:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 15:50:21 --> Utf8 Class Initialized
DEBUG - 2015-01-25 15:50:21 --> URI Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Router Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Output Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Security Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Input Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 15:50:21 --> Language Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Loader Class Initialized
DEBUG - 2015-01-25 15:50:21 --> Helper loaded: url_helper
DEBUG - 2015-01-25 15:50:21 --> Controller Class Initialized
DEBUG - 2015-01-25 15:50:21 --> CI_Session Class Initialized
DEBUG - 2015-01-25 15:50:21 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:47:12 --> Config Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:47:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:47:12 --> URI Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Router Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Output Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Security Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Input Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:47:12 --> Language Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Loader Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:47:12 --> Controller Class Initialized
DEBUG - 2015-01-25 17:47:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:47:12 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 17:47:12 --> Final output sent to browser
DEBUG - 2015-01-25 17:47:12 --> Total execution time: 0.2920
DEBUG - 2015-01-25 17:47:18 --> Config Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:47:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:47:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:47:18 --> URI Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Router Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Output Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Security Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Input Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:47:18 --> Language Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Loader Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:47:18 --> Controller Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:47:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:47:18 --> Session: Expired
DEBUG - 2015-01-25 17:47:18 --> Session: Creating new session (e7a0d7a7d773776dbc24e2bd116e00fd)
DEBUG - 2015-01-25 17:47:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:47:18 --> User Agent Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Config Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:47:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:47:30 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:47:30 --> URI Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Router Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Output Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Security Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Input Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:47:30 --> Language Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Loader Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:47:30 --> Controller Class Initialized
DEBUG - 2015-01-25 17:47:30 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:47:30 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:47:30 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:47:30 --> Final output sent to browser
DEBUG - 2015-01-25 17:47:30 --> Total execution time: 0.0555
DEBUG - 2015-01-25 17:47:33 --> Config Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:47:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:47:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:47:33 --> URI Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Router Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Output Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Security Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Input Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:47:33 --> Language Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Loader Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:47:33 --> Controller Class Initialized
DEBUG - 2015-01-25 17:47:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:47:33 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:47:33 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:47:33 --> Final output sent to browser
DEBUG - 2015-01-25 17:47:33 --> Total execution time: 0.0843
DEBUG - 2015-01-25 17:49:35 --> Config Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:49:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:49:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:49:35 --> URI Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Router Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Output Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Security Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Input Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:49:35 --> Language Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Loader Class Initialized
DEBUG - 2015-01-25 17:49:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:49:35 --> Controller Class Initialized
DEBUG - 2015-01-25 17:49:35 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:49:35 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:49:36 --> Config Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:49:36 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:49:36 --> URI Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Router Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Output Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Security Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Input Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:49:36 --> Language Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Loader Class Initialized
DEBUG - 2015-01-25 17:49:36 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:49:36 --> Controller Class Initialized
DEBUG - 2015-01-25 17:49:36 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:49:36 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:52:45 --> Config Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:52:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:52:45 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:52:45 --> URI Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Router Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Output Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Security Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Input Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:52:45 --> Language Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Loader Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:52:45 --> Controller Class Initialized
DEBUG - 2015-01-25 17:52:45 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:52:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 17:52:45 --> Final output sent to browser
DEBUG - 2015-01-25 17:52:45 --> Total execution time: 0.0096
DEBUG - 2015-01-25 17:52:48 --> Config Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:52:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:52:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:52:48 --> URI Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Router Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Output Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Security Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Input Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:52:48 --> Language Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Loader Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:52:48 --> Controller Class Initialized
DEBUG - 2015-01-25 17:52:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:52:48 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:52:48 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:52:48 --> User Agent Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Config Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:53:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:53:04 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:53:04 --> URI Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Router Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Output Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Security Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Input Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:53:04 --> Language Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Loader Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:53:04 --> Controller Class Initialized
DEBUG - 2015-01-25 17:53:04 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:53:04 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:53:04 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:53:04 --> Final output sent to browser
DEBUG - 2015-01-25 17:53:04 --> Total execution time: 0.0173
DEBUG - 2015-01-25 17:53:07 --> Config Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:53:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:53:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:53:07 --> URI Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Router Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Output Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Security Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Input Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:53:07 --> Language Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Loader Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:53:07 --> Controller Class Initialized
DEBUG - 2015-01-25 17:53:07 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:53:07 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:53:07 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:53:07 --> Final output sent to browser
DEBUG - 2015-01-25 17:53:07 --> Total execution time: 0.0079
DEBUG - 2015-01-25 17:53:09 --> Config Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:53:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:53:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:53:09 --> URI Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Router Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Output Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Security Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Input Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:53:09 --> Language Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Loader Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:53:09 --> Controller Class Initialized
DEBUG - 2015-01-25 17:53:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:53:09 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:53:09 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:53:09 --> Final output sent to browser
DEBUG - 2015-01-25 17:53:09 --> Total execution time: 0.0049
DEBUG - 2015-01-25 17:53:13 --> Config Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:53:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:53:13 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:53:13 --> URI Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Router Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Output Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Security Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Input Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:53:13 --> Language Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Loader Class Initialized
DEBUG - 2015-01-25 17:53:13 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:53:13 --> Controller Class Initialized
DEBUG - 2015-01-25 17:53:13 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:53:13 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:53:14 --> Config Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:53:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:53:14 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:53:14 --> URI Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Router Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Output Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Security Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Input Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:53:14 --> Language Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Loader Class Initialized
DEBUG - 2015-01-25 17:53:14 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:53:14 --> Controller Class Initialized
DEBUG - 2015-01-25 17:53:14 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:53:14 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:54:31 --> Config Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:54:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:54:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:54:31 --> URI Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Router Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Output Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Security Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Input Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:54:31 --> Language Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Loader Class Initialized
DEBUG - 2015-01-25 17:54:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:54:31 --> Controller Class Initialized
DEBUG - 2015-01-25 17:54:31 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:54:31 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:54:32 --> Config Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:54:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:54:32 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:54:32 --> URI Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Router Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Output Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Security Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Input Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:54:32 --> Language Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Loader Class Initialized
DEBUG - 2015-01-25 17:54:32 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:54:32 --> Controller Class Initialized
DEBUG - 2015-01-25 17:54:32 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:54:32 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:54:33 --> Config Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:54:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:54:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:54:33 --> URI Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Router Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Output Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Security Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Input Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:54:33 --> Language Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Loader Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:54:33 --> Controller Class Initialized
DEBUG - 2015-01-25 17:54:33 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:54:33 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:54:33 --> Config Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:54:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:54:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:54:33 --> URI Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Router Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Output Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Security Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Input Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:54:33 --> Language Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Loader Class Initialized
DEBUG - 2015-01-25 17:54:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:54:33 --> Controller Class Initialized
DEBUG - 2015-01-25 17:54:33 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:54:33 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:06 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:06 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:06 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:06 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:06 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:06 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:06 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:06 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:09 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:09 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:09 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:09 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:09 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 17:59:09 --> Final output sent to browser
DEBUG - 2015-01-25 17:59:09 --> Total execution time: 0.0068
DEBUG - 2015-01-25 17:59:12 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:12 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:12 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:12 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:12 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:12 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:12 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:12 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:12 --> User Agent Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:18 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:18 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:18 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:18 --> Final output sent to browser
DEBUG - 2015-01-25 17:59:18 --> Total execution time: 0.0127
DEBUG - 2015-01-25 17:59:22 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:22 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:22 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:22 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:22 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:22 --> Final output sent to browser
DEBUG - 2015-01-25 17:59:22 --> Total execution time: 0.0077
DEBUG - 2015-01-25 17:59:24 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:24 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:24 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:24 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:24 --> Final output sent to browser
DEBUG - 2015-01-25 17:59:24 --> Total execution time: 0.0073
DEBUG - 2015-01-25 17:59:27 --> Config Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Hooks Class Initialized
DEBUG - 2015-01-25 17:59:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 17:59:27 --> Utf8 Class Initialized
DEBUG - 2015-01-25 17:59:27 --> URI Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Router Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Output Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Security Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Input Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 17:59:27 --> Language Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Loader Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Helper loaded: url_helper
DEBUG - 2015-01-25 17:59:27 --> Controller Class Initialized
DEBUG - 2015-01-25 17:59:27 --> Database Driver Class Initialized
DEBUG - 2015-01-25 17:59:27 --> CI_Session Class Initialized
DEBUG - 2015-01-25 17:59:27 --> CI_Session routines successfully run
DEBUG - 2015-01-25 17:59:27 --> Final output sent to browser
DEBUG - 2015-01-25 17:59:27 --> Total execution time: 0.0033
DEBUG - 2015-01-25 18:06:42 --> Config Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:06:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:06:42 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:06:42 --> URI Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Router Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Output Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Security Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Input Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:06:42 --> Language Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Loader Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:06:42 --> Controller Class Initialized
DEBUG - 2015-01-25 18:06:42 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:06:42 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:06:42 --> Final output sent to browser
DEBUG - 2015-01-25 18:06:42 --> Total execution time: 0.0089
DEBUG - 2015-01-25 18:06:48 --> Config Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:06:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:06:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:06:48 --> URI Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Router Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Output Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Security Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Input Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:06:48 --> Language Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Loader Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:06:48 --> Controller Class Initialized
DEBUG - 2015-01-25 18:06:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:06:48 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:06:48 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:06:48 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Config Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:07:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:07:03 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:07:03 --> URI Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Router Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Output Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Security Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Input Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:07:03 --> Language Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Loader Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:07:03 --> Controller Class Initialized
DEBUG - 2015-01-25 18:07:03 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:07:03 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:07:03 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:07:03 --> Final output sent to browser
DEBUG - 2015-01-25 18:07:03 --> Total execution time: 0.0089
DEBUG - 2015-01-25 18:07:05 --> Config Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:07:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:07:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:07:05 --> URI Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Router Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Output Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Security Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Input Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:07:05 --> Language Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Loader Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:07:05 --> Controller Class Initialized
DEBUG - 2015-01-25 18:07:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:07:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:07:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:07:05 --> Final output sent to browser
DEBUG - 2015-01-25 18:07:05 --> Total execution time: 0.0039
DEBUG - 2015-01-25 18:12:09 --> Config Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:12:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:12:09 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:12:09 --> URI Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Router Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Output Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Security Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Input Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:12:09 --> Language Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Loader Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:12:09 --> Controller Class Initialized
DEBUG - 2015-01-25 18:12:09 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:12:09 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:12:09 --> Final output sent to browser
DEBUG - 2015-01-25 18:12:09 --> Total execution time: 0.0079
DEBUG - 2015-01-25 18:12:11 --> Config Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:12:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:12:11 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:12:11 --> URI Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Router Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Output Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Security Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Input Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:12:11 --> Language Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Loader Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:12:11 --> Controller Class Initialized
DEBUG - 2015-01-25 18:12:11 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:12:11 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:12:11 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:12:11 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Config Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:12:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:12:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:12:20 --> URI Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Router Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Output Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Security Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Input Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:12:20 --> Language Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Loader Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:12:20 --> Controller Class Initialized
DEBUG - 2015-01-25 18:12:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:12:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:12:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:12:20 --> Final output sent to browser
DEBUG - 2015-01-25 18:12:20 --> Total execution time: 0.0123
DEBUG - 2015-01-25 18:12:23 --> Config Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:12:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:12:23 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:12:23 --> URI Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Router Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Output Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Security Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Input Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:12:23 --> Language Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Loader Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:12:23 --> Controller Class Initialized
DEBUG - 2015-01-25 18:12:23 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:12:23 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:12:23 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:12:23 --> Final output sent to browser
DEBUG - 2015-01-25 18:12:23 --> Total execution time: 0.0081
DEBUG - 2015-01-25 18:12:29 --> Config Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:12:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:12:29 --> URI Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Router Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Output Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Security Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Input Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:12:29 --> Language Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Loader Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:12:29 --> Controller Class Initialized
DEBUG - 2015-01-25 18:12:29 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:12:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:12:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:12:29 --> Final output sent to browser
DEBUG - 2015-01-25 18:12:29 --> Total execution time: 0.0043
DEBUG - 2015-01-25 18:16:33 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:33 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:33 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:33 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:33 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:33 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:16:33 --> Final output sent to browser
DEBUG - 2015-01-25 18:16:33 --> Total execution time: 0.0039
DEBUG - 2015-01-25 18:16:37 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:37 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:37 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:37 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:37 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:37 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:37 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:16:37 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:16:37 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:47 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:47 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:47 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:47 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:47 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:47 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:16:47 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:16:47 --> Final output sent to browser
DEBUG - 2015-01-25 18:16:47 --> Total execution time: 0.0116
DEBUG - 2015-01-25 18:16:50 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:50 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:50 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:50 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:50 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:16:50 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:16:50 --> Final output sent to browser
DEBUG - 2015-01-25 18:16:50 --> Total execution time: 0.0057
DEBUG - 2015-01-25 18:16:53 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:53 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:53 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:53 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:53 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:53 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:53 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:16:53 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:16:53 --> Final output sent to browser
DEBUG - 2015-01-25 18:16:53 --> Total execution time: 0.0064
DEBUG - 2015-01-25 18:16:57 --> Config Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:16:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:16:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:16:57 --> URI Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Router Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Output Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Security Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Input Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:16:57 --> Language Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Loader Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:16:57 --> Controller Class Initialized
DEBUG - 2015-01-25 18:16:57 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:16:57 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:16:57 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:16:57 --> Final output sent to browser
DEBUG - 2015-01-25 18:16:57 --> Total execution time: 0.0033
DEBUG - 2015-01-25 18:17:01 --> Config Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:17:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:17:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:17:01 --> URI Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Router Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Output Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Security Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Input Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:17:01 --> Language Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Loader Class Initialized
DEBUG - 2015-01-25 18:17:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:17:01 --> Controller Class Initialized
DEBUG - 2015-01-25 18:17:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:17:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:19:52 --> Config Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:19:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:19:52 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:19:52 --> URI Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Router Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Output Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Security Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Input Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:19:52 --> Language Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Loader Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:19:52 --> Controller Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:19:52 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:19:52 --> Session: Regenerate ID
DEBUG - 2015-01-25 18:19:52 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:19:52 --> Final output sent to browser
DEBUG - 2015-01-25 18:19:52 --> Total execution time: 0.0052
DEBUG - 2015-01-25 18:19:57 --> Config Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:19:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:19:57 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:19:57 --> URI Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Router Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Output Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Security Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Input Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:19:57 --> Language Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Loader Class Initialized
DEBUG - 2015-01-25 18:19:57 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:19:57 --> Controller Class Initialized
DEBUG - 2015-01-25 18:19:57 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:19:57 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:20:31 --> Config Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:20:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:20:31 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:20:31 --> URI Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Router Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Output Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Security Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Input Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:20:31 --> Language Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Loader Class Initialized
DEBUG - 2015-01-25 18:20:31 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:20:31 --> Controller Class Initialized
DEBUG - 2015-01-25 18:20:31 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:20:31 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:21:07 --> Config Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:21:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:21:07 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:21:07 --> URI Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Router Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Output Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Security Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Input Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:21:07 --> Language Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Loader Class Initialized
DEBUG - 2015-01-25 18:21:07 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:21:07 --> Controller Class Initialized
DEBUG - 2015-01-25 18:21:07 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:21:07 --> CI_Session routines successfully run
ERROR - 2015-01-25 18:21:07 --> Severity: Error --> Call to undefined method CI_Session::sess_detroy() /var/www/WhoWantsToBeAMilionaire/application/controllers/KillSession.php 13
DEBUG - 2015-01-25 18:26:22 --> Config Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:26:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:26:22 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:26:22 --> URI Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Router Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Output Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Security Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Input Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:26:22 --> Language Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Loader Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:26:22 --> Controller Class Initialized
DEBUG - 2015-01-25 18:26:22 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:26:22 --> Session: Regenerate ID
DEBUG - 2015-01-25 18:26:22 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:26:22 --> Final output sent to browser
DEBUG - 2015-01-25 18:26:22 --> Total execution time: 0.0038
DEBUG - 2015-01-25 18:27:25 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:25 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:25 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:25 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:25 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:27:25 --> A session cookie was not found.
DEBUG - 2015-01-25 18:27:25 --> Session: Creating new session (3220ccbecb1c93cc3848df598dcc20d7)
DEBUG - 2015-01-25 18:27:25 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:27:25 --> Final output sent to browser
DEBUG - 2015-01-25 18:27:25 --> Total execution time: 0.0028
DEBUG - 2015-01-25 18:27:25 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:25 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:25 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:25 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:25 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:25 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:27:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:27:26 --> Final output sent to browser
DEBUG - 2015-01-25 18:27:26 --> Total execution time: 0.0074
DEBUG - 2015-01-25 18:27:29 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:29 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:29 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:29 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:29 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:29 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:27:29 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:27:29 --> A session cookie was not found.
DEBUG - 2015-01-25 18:27:29 --> Session: Creating new session (ea4a95294a82b60dfbeaceba4d9b2446)
DEBUG - 2015-01-25 18:27:29 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:27:29 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:41 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:41 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:41 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:41 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:41 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:27:41 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:27:41 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:27:41 --> Final output sent to browser
DEBUG - 2015-01-25 18:27:41 --> Total execution time: 0.0163
DEBUG - 2015-01-25 18:27:44 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:44 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:44 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:44 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:27:44 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:27:44 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:27:44 --> Final output sent to browser
DEBUG - 2015-01-25 18:27:44 --> Total execution time: 0.0075
DEBUG - 2015-01-25 18:27:56 --> Config Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:27:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:27:56 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:27:56 --> URI Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Router Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Output Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Security Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Input Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:27:56 --> Language Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Loader Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:27:56 --> Controller Class Initialized
DEBUG - 2015-01-25 18:27:56 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:27:56 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:27:56 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:27:56 --> Final output sent to browser
DEBUG - 2015-01-25 18:27:56 --> Total execution time: 0.0099
DEBUG - 2015-01-25 18:28:01 --> Config Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:28:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:28:01 --> URI Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Router Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Output Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Security Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Input Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:28:01 --> Language Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Loader Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:28:01 --> Controller Class Initialized
DEBUG - 2015-01-25 18:28:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:28:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:28:01 --> Final output sent to browser
DEBUG - 2015-01-25 18:28:01 --> Total execution time: 0.0034
DEBUG - 2015-01-25 18:28:01 --> Config Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:28:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:28:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:28:01 --> URI Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Router Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Output Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Security Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Input Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:28:01 --> Language Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Loader Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:28:01 --> Controller Class Initialized
DEBUG - 2015-01-25 18:28:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:28:01 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:28:01 --> Final output sent to browser
DEBUG - 2015-01-25 18:28:01 --> Total execution time: 0.0044
DEBUG - 2015-01-25 18:33:35 --> Config Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:33:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:33:35 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:33:35 --> URI Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Router Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Output Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Security Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Input Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:33:35 --> Language Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Loader Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:33:35 --> Controller Class Initialized
DEBUG - 2015-01-25 18:33:35 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:33:35 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:33:35 --> A session cookie was not found.
DEBUG - 2015-01-25 18:33:35 --> Session: Creating new session (db8f91c43fd70f98a854ae3cbce196f8)
DEBUG - 2015-01-25 18:33:35 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:33:35 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Config Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:33:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:33:44 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:33:44 --> URI Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Router Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Output Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Security Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Input Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:33:44 --> Language Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Loader Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:33:44 --> Controller Class Initialized
DEBUG - 2015-01-25 18:33:44 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:33:44 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:33:44 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:33:44 --> Final output sent to browser
DEBUG - 2015-01-25 18:33:44 --> Total execution time: 0.0146
DEBUG - 2015-01-25 18:33:48 --> Config Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:33:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:33:48 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:33:48 --> URI Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Router Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Output Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Security Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Input Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:33:48 --> Language Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Loader Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:33:48 --> Controller Class Initialized
DEBUG - 2015-01-25 18:33:48 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:33:48 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:33:48 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:33:48 --> Final output sent to browser
DEBUG - 2015-01-25 18:33:48 --> Total execution time: 0.0053
DEBUG - 2015-01-25 18:33:50 --> Config Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:33:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:33:50 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:33:50 --> URI Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Router Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Output Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Security Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Input Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:33:50 --> Language Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Loader Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:33:50 --> Controller Class Initialized
DEBUG - 2015-01-25 18:33:50 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:33:50 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:33:50 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:33:50 --> Final output sent to browser
DEBUG - 2015-01-25 18:33:50 --> Total execution time: 0.0083
DEBUG - 2015-01-25 18:33:55 --> Config Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:33:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:33:55 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:33:55 --> URI Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Router Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Output Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Security Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Input Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:33:55 --> Language Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Loader Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:33:55 --> Controller Class Initialized
DEBUG - 2015-01-25 18:33:55 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:33:55 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:33:55 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:33:55 --> Final output sent to browser
DEBUG - 2015-01-25 18:33:55 --> Total execution time: 0.0035
DEBUG - 2015-01-25 18:46:46 --> Config Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:46:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:46:46 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:46:46 --> URI Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Router Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Output Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Security Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Input Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:46:46 --> Language Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Loader Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:46:46 --> Controller Class Initialized
DEBUG - 2015-01-25 18:46:46 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:46:46 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:46:46 --> Final output sent to browser
DEBUG - 2015-01-25 18:46:46 --> Total execution time: 0.0129
DEBUG - 2015-01-25 18:46:49 --> Config Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:46:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:46:49 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:46:49 --> URI Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Router Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Output Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Security Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Input Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:46:49 --> Language Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Loader Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:46:49 --> Controller Class Initialized
DEBUG - 2015-01-25 18:46:49 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:46:49 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:46:49 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:46:49 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Config Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:46:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:46:58 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:46:58 --> URI Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Router Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Output Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Security Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Input Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:46:58 --> Language Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Loader Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:46:58 --> Controller Class Initialized
DEBUG - 2015-01-25 18:46:58 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:46:58 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:46:58 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:46:58 --> Final output sent to browser
DEBUG - 2015-01-25 18:46:58 --> Total execution time: 0.0113
DEBUG - 2015-01-25 18:47:01 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:01 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:01 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:01 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:01 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:01 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:01 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:01 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:01 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:01 --> Total execution time: 0.0058
DEBUG - 2015-01-25 18:47:05 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:05 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:05 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:05 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:05 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:05 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:05 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:05 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:05 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:05 --> Total execution time: 0.0060
DEBUG - 2015-01-25 18:47:16 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:16 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:16 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:16 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:16 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:16 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:16 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:16 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:16 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:16 --> Total execution time: 0.0044
DEBUG - 2015-01-25 18:47:18 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:18 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:18 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:18 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:18 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:18 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:18 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:18 --> Total execution time: 0.0021
DEBUG - 2015-01-25 18:47:18 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:18 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:18 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:18 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:18 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:18 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:18 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-25 18:47:18 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:18 --> Total execution time: 0.0043
DEBUG - 2015-01-25 18:47:20 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:20 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:20 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:20 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:20 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:20 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:20 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:20 --> A session cookie was not found.
DEBUG - 2015-01-25 18:47:20 --> Session: Creating new session (7a4c850e6d24bc07ddfed8a82a82151a)
DEBUG - 2015-01-25 18:47:20 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:20 --> User Agent Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Config Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Hooks Class Initialized
DEBUG - 2015-01-25 18:47:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-25 18:47:24 --> Utf8 Class Initialized
DEBUG - 2015-01-25 18:47:24 --> URI Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Router Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Output Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Security Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Input Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-25 18:47:24 --> Language Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Loader Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Helper loaded: url_helper
DEBUG - 2015-01-25 18:47:24 --> Controller Class Initialized
DEBUG - 2015-01-25 18:47:24 --> Database Driver Class Initialized
DEBUG - 2015-01-25 18:47:24 --> CI_Session Class Initialized
DEBUG - 2015-01-25 18:47:24 --> CI_Session routines successfully run
DEBUG - 2015-01-25 18:47:24 --> Final output sent to browser
DEBUG - 2015-01-25 18:47:24 --> Total execution time: 0.0146
