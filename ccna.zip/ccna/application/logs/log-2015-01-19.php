<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-19 11:17:25 --> Config Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:17:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:17:25 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:17:25 --> URI Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Router Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Output Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Security Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Input Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:17:25 --> Language Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Loader Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:17:25 --> Controller Class Initialized
DEBUG - 2015-01-19 11:17:25 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:17:25 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-19 11:17:25 --> Final output sent to browser
DEBUG - 2015-01-19 11:17:25 --> Total execution time: 0.2752
DEBUG - 2015-01-19 11:17:30 --> Config Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:17:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:17:30 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:17:30 --> URI Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Router Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Output Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Security Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Input Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:17:30 --> Language Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Loader Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:17:30 --> Controller Class Initialized
DEBUG - 2015-01-19 11:17:30 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:17:30 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:17:30 --> A session cookie was not found.
DEBUG - 2015-01-19 11:17:30 --> Session: Creating new session (bbfd887ec018686e1fce011504b11f21)
DEBUG - 2015-01-19 11:17:30 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:17:30 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Config Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:21:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:21:27 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:21:27 --> URI Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Router Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Output Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Security Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Input Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:21:27 --> Language Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Loader Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:21:27 --> Controller Class Initialized
DEBUG - 2015-01-19 11:21:27 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:21:27 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:21:27 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:21:27 --> Final output sent to browser
DEBUG - 2015-01-19 11:21:27 --> Total execution time: 0.0613
DEBUG - 2015-01-19 11:21:31 --> Config Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:21:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:21:31 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:21:31 --> URI Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Router Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Output Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Security Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Input Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:21:31 --> Language Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Loader Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:21:31 --> Controller Class Initialized
DEBUG - 2015-01-19 11:21:31 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:21:31 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:21:31 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:21:31 --> Final output sent to browser
DEBUG - 2015-01-19 11:21:31 --> Total execution time: 0.0075
DEBUG - 2015-01-19 11:21:41 --> Config Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:21:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:21:41 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:21:41 --> URI Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Router Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Output Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Security Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Input Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:21:41 --> Language Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Loader Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:21:41 --> Controller Class Initialized
DEBUG - 2015-01-19 11:21:41 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:21:41 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:21:41 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:21:41 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Config Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:24:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:24:42 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:24:42 --> URI Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Router Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Output Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Security Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Input Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:24:42 --> Language Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Loader Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:24:42 --> Controller Class Initialized
DEBUG - 2015-01-19 11:24:42 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:24:42 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:24:42 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:24:42 --> Final output sent to browser
DEBUG - 2015-01-19 11:24:42 --> Total execution time: 0.0208
DEBUG - 2015-01-19 11:31:26 --> Config Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:31:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:31:26 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:31:26 --> URI Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Router Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Output Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Security Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Input Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:31:26 --> Language Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Loader Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:31:26 --> Controller Class Initialized
DEBUG - 2015-01-19 11:31:26 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:31:26 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:31:26 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:31:26 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Config Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:31:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:31:39 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:31:39 --> URI Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Router Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Output Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Security Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Input Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:31:39 --> Language Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Loader Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:31:39 --> Controller Class Initialized
DEBUG - 2015-01-19 11:31:39 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:31:39 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:31:39 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:31:39 --> Final output sent to browser
DEBUG - 2015-01-19 11:31:39 --> Total execution time: 0.0226
DEBUG - 2015-01-19 11:31:41 --> Config Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:31:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:31:41 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:31:41 --> URI Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Router Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Output Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Security Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Input Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:31:41 --> Language Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Loader Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:31:41 --> Controller Class Initialized
DEBUG - 2015-01-19 11:31:41 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:31:41 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:31:41 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:31:41 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Config Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:37:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:37:15 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:37:15 --> URI Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Router Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Output Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Security Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Input Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:37:15 --> Language Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Loader Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:37:15 --> Controller Class Initialized
DEBUG - 2015-01-19 11:37:15 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:37:15 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:37:15 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:37:15 --> Final output sent to browser
DEBUG - 2015-01-19 11:37:15 --> Total execution time: 0.0125
DEBUG - 2015-01-19 11:37:23 --> Config Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:37:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:37:23 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:37:23 --> URI Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Router Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Output Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Security Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Input Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:37:23 --> Language Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Loader Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:37:23 --> Controller Class Initialized
DEBUG - 2015-01-19 11:37:23 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:37:23 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:37:23 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:37:23 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Config Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:37:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:37:34 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:37:34 --> URI Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Router Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Output Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Security Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Input Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:37:34 --> Language Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Loader Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:37:34 --> Controller Class Initialized
DEBUG - 2015-01-19 11:37:34 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:37:34 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:37:34 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:37:34 --> Final output sent to browser
DEBUG - 2015-01-19 11:37:34 --> Total execution time: 0.0115
DEBUG - 2015-01-19 11:37:43 --> Config Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:37:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:37:43 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:37:43 --> URI Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Router Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Output Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Security Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Input Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:37:43 --> Language Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Loader Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:37:43 --> Controller Class Initialized
DEBUG - 2015-01-19 11:37:43 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:37:43 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:37:43 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:37:43 --> Final output sent to browser
DEBUG - 2015-01-19 11:37:43 --> Total execution time: 0.0598
DEBUG - 2015-01-19 11:43:32 --> Config Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:43:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:43:32 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:43:32 --> URI Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Router Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Output Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Security Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Input Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:43:32 --> Language Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Loader Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:43:32 --> Controller Class Initialized
DEBUG - 2015-01-19 11:43:32 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:43:32 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-19 11:43:32 --> Final output sent to browser
DEBUG - 2015-01-19 11:43:32 --> Total execution time: 0.0033
DEBUG - 2015-01-19 11:43:34 --> Config Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:43:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:43:34 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:43:34 --> URI Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Router Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Output Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Security Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Input Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:43:34 --> Language Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Loader Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:43:34 --> Controller Class Initialized
DEBUG - 2015-01-19 11:43:34 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:43:34 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:43:34 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:43:34 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Config Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:43:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:43:51 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:43:51 --> URI Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Router Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Output Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Security Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Input Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:43:51 --> Language Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Loader Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:43:51 --> Controller Class Initialized
DEBUG - 2015-01-19 11:43:51 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:43:51 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:43:51 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:43:51 --> Final output sent to browser
DEBUG - 2015-01-19 11:43:51 --> Total execution time: 0.0148
DEBUG - 2015-01-19 11:43:54 --> Config Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:43:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:43:54 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:43:54 --> URI Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Router Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Output Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Security Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Input Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:43:54 --> Language Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Loader Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:43:54 --> Controller Class Initialized
DEBUG - 2015-01-19 11:43:54 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:43:54 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:43:54 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:43:54 --> Final output sent to browser
DEBUG - 2015-01-19 11:43:54 --> Total execution time: 0.0157
DEBUG - 2015-01-19 11:46:35 --> Config Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:46:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:46:35 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:46:35 --> URI Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Router Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Output Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Security Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Input Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:46:35 --> Language Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Loader Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:46:35 --> Controller Class Initialized
DEBUG - 2015-01-19 11:46:35 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:46:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-19 11:46:35 --> Final output sent to browser
DEBUG - 2015-01-19 11:46:35 --> Total execution time: 0.0171
DEBUG - 2015-01-19 11:46:37 --> Config Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:46:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:46:37 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:46:37 --> URI Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Router Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Output Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Security Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Input Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:46:37 --> Language Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Loader Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:46:37 --> Controller Class Initialized
DEBUG - 2015-01-19 11:46:37 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:46:37 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:46:37 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:46:37 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Config Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:46:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:46:56 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:46:56 --> URI Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Router Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Output Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Security Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Input Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:46:56 --> Language Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Loader Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:46:56 --> Controller Class Initialized
DEBUG - 2015-01-19 11:46:56 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:46:56 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:46:56 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:46:56 --> Final output sent to browser
DEBUG - 2015-01-19 11:46:56 --> Total execution time: 0.0132
DEBUG - 2015-01-19 11:46:58 --> Config Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:46:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:46:58 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:46:58 --> URI Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Router Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Output Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Security Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Input Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:46:58 --> Language Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Loader Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:46:58 --> Controller Class Initialized
DEBUG - 2015-01-19 11:46:58 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:46:58 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:46:58 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:46:58 --> Final output sent to browser
DEBUG - 2015-01-19 11:46:58 --> Total execution time: 0.0074
DEBUG - 2015-01-19 11:47:01 --> Config Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:47:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:47:01 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:47:01 --> URI Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Router Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Output Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Security Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Input Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:47:01 --> Language Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Loader Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:47:01 --> Controller Class Initialized
DEBUG - 2015-01-19 11:47:01 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:47:01 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:47:01 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:47:01 --> Final output sent to browser
DEBUG - 2015-01-19 11:47:01 --> Total execution time: 0.0059
DEBUG - 2015-01-19 11:47:05 --> Config Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:47:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:47:05 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:47:05 --> URI Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Router Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Output Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Security Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Input Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:47:05 --> Language Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Loader Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:47:05 --> Controller Class Initialized
DEBUG - 2015-01-19 11:47:05 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:47:05 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:47:05 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:47:05 --> Final output sent to browser
DEBUG - 2015-01-19 11:47:05 --> Total execution time: 0.0145
DEBUG - 2015-01-19 11:52:04 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:04 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:04 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:04 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:04 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:04 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:04 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-19 11:52:04 --> Final output sent to browser
DEBUG - 2015-01-19 11:52:04 --> Total execution time: 0.0040
DEBUG - 2015-01-19 11:52:06 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:06 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:06 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:06 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:06 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:06 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:06 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:52:06 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:52:06 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:11 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:11 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:11 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:11 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:11 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:11 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:52:11 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:52:11 --> Final output sent to browser
DEBUG - 2015-01-19 11:52:11 --> Total execution time: 0.0114
DEBUG - 2015-01-19 11:52:13 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:13 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:13 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:13 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:13 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:13 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:13 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:52:13 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:52:13 --> Final output sent to browser
DEBUG - 2015-01-19 11:52:13 --> Total execution time: 0.0150
DEBUG - 2015-01-19 11:52:37 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:37 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:37 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:37 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:37 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:37 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:37 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-19 11:52:37 --> Final output sent to browser
DEBUG - 2015-01-19 11:52:37 --> Total execution time: 0.0152
DEBUG - 2015-01-19 11:52:39 --> Config Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:52:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:52:39 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:52:39 --> URI Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Router Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Output Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Security Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Input Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:52:39 --> Language Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Loader Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:52:39 --> Controller Class Initialized
DEBUG - 2015-01-19 11:52:39 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:52:39 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:52:39 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:52:39 --> User Agent Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Config Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:53:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:53:17 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:53:17 --> URI Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Router Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Output Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Security Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Input Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:53:17 --> Language Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Loader Class Initialized
DEBUG - 2015-01-19 11:53:17 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:53:17 --> Controller Class Initialized
DEBUG - 2015-01-19 11:53:18 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:53:18 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:53:18 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:53:18 --> Final output sent to browser
DEBUG - 2015-01-19 11:53:18 --> Total execution time: 0.0165
DEBUG - 2015-01-19 11:53:20 --> Config Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:53:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:53:20 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:53:20 --> URI Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Router Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Output Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Security Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Input Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:53:20 --> Language Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Loader Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:53:20 --> Controller Class Initialized
DEBUG - 2015-01-19 11:53:20 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:53:20 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:53:20 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:53:20 --> Final output sent to browser
DEBUG - 2015-01-19 11:53:20 --> Total execution time: 0.0102
DEBUG - 2015-01-19 11:54:22 --> Config Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Hooks Class Initialized
DEBUG - 2015-01-19 11:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 11:54:22 --> Utf8 Class Initialized
DEBUG - 2015-01-19 11:54:22 --> URI Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Router Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Output Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Security Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Input Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 11:54:22 --> Language Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Loader Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Helper loaded: url_helper
DEBUG - 2015-01-19 11:54:22 --> Controller Class Initialized
DEBUG - 2015-01-19 11:54:22 --> Database Driver Class Initialized
DEBUG - 2015-01-19 11:54:22 --> CI_Session Class Initialized
DEBUG - 2015-01-19 11:54:22 --> CI_Session routines successfully run
DEBUG - 2015-01-19 11:54:22 --> Final output sent to browser
DEBUG - 2015-01-19 11:54:22 --> Total execution time: 0.0112
DEBUG - 2015-01-19 12:08:00 --> Config Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:08:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:08:00 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:08:00 --> URI Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Router Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Output Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Security Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Input Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:08:00 --> Language Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Loader Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:08:00 --> Controller Class Initialized
DEBUG - 2015-01-19 12:08:00 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:08:00 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:08:00 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:08:00 --> Final output sent to browser
DEBUG - 2015-01-19 12:08:00 --> Total execution time: 0.0117
DEBUG - 2015-01-19 12:08:03 --> Config Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:08:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:08:03 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:08:03 --> URI Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Router Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Output Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Security Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Input Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:08:03 --> Language Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Loader Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:08:03 --> Controller Class Initialized
DEBUG - 2015-01-19 12:08:03 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:08:03 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:08:03 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:08:03 --> Final output sent to browser
DEBUG - 2015-01-19 12:08:03 --> Total execution time: 0.0115
DEBUG - 2015-01-19 12:10:12 --> Config Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:10:12 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:10:12 --> URI Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Router Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Output Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Security Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Input Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:10:12 --> Language Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Loader Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:10:12 --> Controller Class Initialized
DEBUG - 2015-01-19 12:10:12 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:10:12 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:10:12 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:10:12 --> Final output sent to browser
DEBUG - 2015-01-19 12:10:12 --> Total execution time: 0.0151
DEBUG - 2015-01-19 12:10:14 --> Config Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:10:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:10:14 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:10:14 --> URI Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Router Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Output Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Security Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Input Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:10:14 --> Language Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Loader Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:10:14 --> Controller Class Initialized
DEBUG - 2015-01-19 12:10:14 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:10:14 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:10:14 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:10:14 --> Final output sent to browser
DEBUG - 2015-01-19 12:10:14 --> Total execution time: 0.0110
DEBUG - 2015-01-19 12:10:48 --> Config Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:10:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:10:48 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:10:48 --> URI Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Router Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Output Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Security Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Input Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:10:48 --> Language Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Loader Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:10:48 --> Controller Class Initialized
DEBUG - 2015-01-19 12:10:48 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:10:48 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:10:48 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:10:48 --> Final output sent to browser
DEBUG - 2015-01-19 12:10:48 --> Total execution time: 0.0159
DEBUG - 2015-01-19 12:11:58 --> Config Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:11:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:11:58 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:11:58 --> URI Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Router Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Output Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Security Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Input Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:11:58 --> Language Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Loader Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:11:58 --> Controller Class Initialized
DEBUG - 2015-01-19 12:11:58 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:11:58 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:11:58 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:11:58 --> Final output sent to browser
DEBUG - 2015-01-19 12:11:58 --> Total execution time: 0.0110
DEBUG - 2015-01-19 12:12:59 --> Config Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:12:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:12:59 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:12:59 --> URI Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Router Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Output Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Security Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Input Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:12:59 --> Language Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Loader Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:12:59 --> Controller Class Initialized
DEBUG - 2015-01-19 12:12:59 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:12:59 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:12:59 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:12:59 --> Final output sent to browser
DEBUG - 2015-01-19 12:12:59 --> Total execution time: 0.0164
DEBUG - 2015-01-19 12:13:00 --> Config Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:13:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:13:00 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:13:00 --> URI Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Router Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Output Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Security Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Input Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:13:00 --> Language Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Loader Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:13:00 --> Controller Class Initialized
DEBUG - 2015-01-19 12:13:00 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:13:00 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:13:00 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:13:00 --> Final output sent to browser
DEBUG - 2015-01-19 12:13:00 --> Total execution time: 0.0096
DEBUG - 2015-01-19 12:13:34 --> Config Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:13:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:13:34 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:13:34 --> URI Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Router Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Output Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Security Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Input Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:13:34 --> Language Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Loader Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:13:34 --> Controller Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:13:34 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:13:34 --> Session: Regenerate ID
DEBUG - 2015-01-19 12:13:34 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:13:34 --> Final output sent to browser
DEBUG - 2015-01-19 12:13:34 --> Total execution time: 0.0098
DEBUG - 2015-01-19 12:16:05 --> Config Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:16:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:16:05 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:16:05 --> URI Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Router Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Output Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Security Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Input Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:16:05 --> Language Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Loader Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:16:05 --> Controller Class Initialized
DEBUG - 2015-01-19 12:16:05 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:16:05 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:16:05 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:16:05 --> Final output sent to browser
DEBUG - 2015-01-19 12:16:05 --> Total execution time: 0.0125
DEBUG - 2015-01-19 12:16:52 --> Config Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Hooks Class Initialized
DEBUG - 2015-01-19 12:16:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-19 12:16:52 --> Utf8 Class Initialized
DEBUG - 2015-01-19 12:16:52 --> URI Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Router Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Output Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Security Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Input Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-19 12:16:52 --> Language Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Loader Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Helper loaded: url_helper
DEBUG - 2015-01-19 12:16:52 --> Controller Class Initialized
DEBUG - 2015-01-19 12:16:52 --> Database Driver Class Initialized
DEBUG - 2015-01-19 12:16:52 --> CI_Session Class Initialized
DEBUG - 2015-01-19 12:16:52 --> CI_Session routines successfully run
DEBUG - 2015-01-19 12:16:52 --> Final output sent to browser
DEBUG - 2015-01-19 12:16:52 --> Total execution time: 0.0079
