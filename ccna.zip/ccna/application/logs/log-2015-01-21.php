<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-21 13:00:32 --> Config Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Hooks Class Initialized
DEBUG - 2015-01-21 13:00:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-21 13:00:32 --> Utf8 Class Initialized
DEBUG - 2015-01-21 13:00:32 --> URI Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Router Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Output Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Security Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Input Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-21 13:00:32 --> Language Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Loader Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Helper loaded: url_helper
DEBUG - 2015-01-21 13:00:32 --> Controller Class Initialized
DEBUG - 2015-01-21 13:00:32 --> Database Driver Class Initialized
DEBUG - 2015-01-21 13:00:32 --> CI_Session Class Initialized
DEBUG - 2015-01-21 13:00:32 --> A session cookie was not found.
DEBUG - 2015-01-21 13:00:32 --> Session: Creating new session (cde6042753b9b33577ed0d259597d1bf)
DEBUG - 2015-01-21 13:00:32 --> CI_Session routines successfully run
DEBUG - 2015-01-21 13:00:32 --> Final output sent to browser
DEBUG - 2015-01-21 13:00:32 --> Total execution time: 0.3197
