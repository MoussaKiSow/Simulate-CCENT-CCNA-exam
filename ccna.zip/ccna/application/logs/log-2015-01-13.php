<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-13 17:08:50 --> Config Class Initialized
DEBUG - 2015-01-13 17:08:50 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:08:50 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:08:50 --> URI Class Initialized
DEBUG - 2015-01-13 17:08:51 --> Router Class Initialized
DEBUG - 2015-01-13 17:08:51 --> Output Class Initialized
DEBUG - 2015-01-13 17:08:51 --> Security Class Initialized
DEBUG - 2015-01-13 17:08:51 --> Input Class Initialized
DEBUG - 2015-01-13 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:08:51 --> Language Class Initialized
ERROR - 2015-01-13 17:08:51 --> 404 Page Not Found: /index
DEBUG - 2015-01-13 17:09:01 --> Config Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:09:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:09:01 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:09:01 --> URI Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Router Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Output Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Security Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Input Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:09:01 --> Language Class Initialized
DEBUG - 2015-01-13 17:09:01 --> Loader Class Initialized
DEBUG - 2015-01-13 17:09:02 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:09:02 --> Controller Class Initialized
DEBUG - 2015-01-13 17:09:02 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:09:02 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:09:02 --> Final output sent to browser
DEBUG - 2015-01-13 17:09:02 --> Total execution time: 0.2222
DEBUG - 2015-01-13 17:09:06 --> Config Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:09:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:09:06 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:09:06 --> URI Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Router Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Output Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Security Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Input Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:09:06 --> Language Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Loader Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:09:06 --> Controller Class Initialized
DEBUG - 2015-01-13 17:09:06 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:09:06 --> CI_Session Class Initialized
DEBUG - 2015-01-13 17:09:06 --> A session cookie was not found.
DEBUG - 2015-01-13 17:09:06 --> Session: Creating new session (fc2358ef7237246e714d482d7dda0354)
DEBUG - 2015-01-13 17:09:06 --> CI_Session routines successfully run
DEBUG - 2015-01-13 17:09:56 --> Config Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:09:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:09:56 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:09:56 --> URI Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Router Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Output Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Security Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Input Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:09:56 --> Language Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Loader Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:09:56 --> Controller Class Initialized
DEBUG - 2015-01-13 17:09:56 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:09:56 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:09:56 --> Final output sent to browser
DEBUG - 2015-01-13 17:09:56 --> Total execution time: 0.0152
DEBUG - 2015-01-13 17:13:37 --> Config Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:13:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:13:37 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:13:37 --> URI Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Router Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Output Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Security Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Input Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:13:37 --> Language Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Loader Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:13:37 --> Controller Class Initialized
DEBUG - 2015-01-13 17:13:37 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:13:37 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:13:37 --> Final output sent to browser
DEBUG - 2015-01-13 17:13:37 --> Total execution time: 0.0180
DEBUG - 2015-01-13 17:31:42 --> Config Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:31:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:31:42 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:31:42 --> URI Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Router Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Output Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Security Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Input Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:31:42 --> Language Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Loader Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:31:42 --> Controller Class Initialized
DEBUG - 2015-01-13 17:31:42 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:31:42 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:31:42 --> Final output sent to browser
DEBUG - 2015-01-13 17:31:42 --> Total execution time: 0.0120
DEBUG - 2015-01-13 17:33:39 --> Config Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:33:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:33:39 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:33:39 --> URI Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Router Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Output Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Security Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Input Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:33:39 --> Language Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Loader Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:33:39 --> Controller Class Initialized
DEBUG - 2015-01-13 17:33:39 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:33:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:33:39 --> Final output sent to browser
DEBUG - 2015-01-13 17:33:39 --> Total execution time: 0.0100
DEBUG - 2015-01-13 17:33:41 --> Config Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:33:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:33:41 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:33:41 --> URI Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Router Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Output Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Security Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Input Class Initialized
DEBUG - 2015-01-13 17:33:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:33:41 --> Language Class Initialized
ERROR - 2015-01-13 17:33:41 --> 404 Page Not Found: Sendanemail/index
DEBUG - 2015-01-13 17:34:10 --> Config Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:34:10 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:34:10 --> URI Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Router Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Output Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Security Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Input Class Initialized
DEBUG - 2015-01-13 17:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:34:10 --> Language Class Initialized
ERROR - 2015-01-13 17:34:10 --> 404 Page Not Found: Sendanemail/index
DEBUG - 2015-01-13 17:35:29 --> Config Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:35:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:35:29 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:35:29 --> URI Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Router Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Output Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Security Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Input Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:35:29 --> Language Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Loader Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:35:29 --> Controller Class Initialized
DEBUG - 2015-01-13 17:35:29 --> Final output sent to browser
DEBUG - 2015-01-13 17:35:29 --> Total execution time: 0.0089
DEBUG - 2015-01-13 17:35:38 --> Config Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:35:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:35:38 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:35:38 --> URI Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Router Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Output Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Security Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Input Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:35:38 --> Language Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Loader Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:35:38 --> Controller Class Initialized
DEBUG - 2015-01-13 17:35:38 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:35:38 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:35:38 --> Final output sent to browser
DEBUG - 2015-01-13 17:35:38 --> Total execution time: 0.0048
DEBUG - 2015-01-13 17:35:52 --> Config Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:35:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:35:52 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:35:52 --> URI Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Router Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Output Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Security Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Input Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:35:52 --> Language Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Loader Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:35:52 --> Controller Class Initialized
DEBUG - 2015-01-13 17:35:52 --> Final output sent to browser
DEBUG - 2015-01-13 17:35:52 --> Total execution time: 0.0086
DEBUG - 2015-01-13 17:36:29 --> Config Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:36:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:36:29 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:36:29 --> URI Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Router Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Output Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Security Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Input Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:36:29 --> Language Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Loader Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:36:29 --> Controller Class Initialized
DEBUG - 2015-01-13 17:36:29 --> Final output sent to browser
DEBUG - 2015-01-13 17:36:29 --> Total execution time: 0.0084
DEBUG - 2015-01-13 17:36:51 --> Config Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:36:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:36:51 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:36:51 --> URI Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Router Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Output Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Security Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Input Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:36:51 --> Language Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Loader Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:36:51 --> Controller Class Initialized
DEBUG - 2015-01-13 17:36:51 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:36:51 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:36:51 --> Final output sent to browser
DEBUG - 2015-01-13 17:36:51 --> Total execution time: 0.0046
DEBUG - 2015-01-13 17:37:00 --> Config Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:37:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:37:00 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:37:00 --> URI Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Router Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Output Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Security Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Input Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:37:00 --> Language Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Loader Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:37:00 --> Controller Class Initialized
DEBUG - 2015-01-13 17:37:00 --> Final output sent to browser
DEBUG - 2015-01-13 17:37:00 --> Total execution time: 0.0017
DEBUG - 2015-01-13 17:37:54 --> Config Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:37:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:37:54 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:37:54 --> URI Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Router Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Output Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Security Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Input Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:37:54 --> Language Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Loader Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:37:54 --> Controller Class Initialized
DEBUG - 2015-01-13 17:37:54 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:37:54 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:37:54 --> Final output sent to browser
DEBUG - 2015-01-13 17:37:54 --> Total execution time: 0.0061
DEBUG - 2015-01-13 17:38:02 --> Config Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:38:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:38:02 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:38:02 --> URI Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Router Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Output Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Security Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Input Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:38:02 --> Language Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Loader Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:38:02 --> Controller Class Initialized
DEBUG - 2015-01-13 17:38:02 --> Final output sent to browser
DEBUG - 2015-01-13 17:38:02 --> Total execution time: 0.0032
DEBUG - 2015-01-13 17:39:14 --> Config Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:39:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:39:14 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:39:14 --> URI Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Router Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Output Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Security Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Input Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:39:14 --> Language Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Loader Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:39:14 --> Controller Class Initialized
DEBUG - 2015-01-13 17:39:14 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:39:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:39:14 --> Final output sent to browser
DEBUG - 2015-01-13 17:39:14 --> Total execution time: 0.0081
DEBUG - 2015-01-13 17:39:18 --> Config Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:39:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:39:18 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:39:18 --> URI Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Router Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Output Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Security Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Input Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:39:18 --> Language Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Loader Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:39:18 --> Controller Class Initialized
DEBUG - 2015-01-13 17:39:18 --> Final output sent to browser
DEBUG - 2015-01-13 17:39:18 --> Total execution time: 0.0025
DEBUG - 2015-01-13 17:48:24 --> Config Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:48:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:48:24 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:48:24 --> URI Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Router Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Output Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Security Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Input Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:48:24 --> Language Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Loader Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:48:24 --> Controller Class Initialized
DEBUG - 2015-01-13 17:48:24 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:48:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:48:24 --> Final output sent to browser
DEBUG - 2015-01-13 17:48:24 --> Total execution time: 0.0108
DEBUG - 2015-01-13 17:48:29 --> Config Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:48:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:48:29 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:48:29 --> URI Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Router Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Output Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Security Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Input Class Initialized
DEBUG - 2015-01-13 17:48:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:48:29 --> Language Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Config Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:48:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:48:54 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:48:54 --> URI Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Router Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Output Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Security Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Input Class Initialized
DEBUG - 2015-01-13 17:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:48:54 --> Language Class Initialized
ERROR - 2015-01-13 17:48:54 --> 404 Page Not Found: Sendenamaio/index
DEBUG - 2015-01-13 17:48:57 --> Config Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:48:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:48:57 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:48:57 --> URI Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Router Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Output Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Security Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Input Class Initialized
DEBUG - 2015-01-13 17:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:48:57 --> Language Class Initialized
ERROR - 2015-01-13 17:48:57 --> 404 Page Not Found: Sendenamail/index
DEBUG - 2015-01-13 17:49:05 --> Config Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:49:05 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:49:05 --> URI Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Router Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Output Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Security Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Input Class Initialized
DEBUG - 2015-01-13 17:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:49:05 --> Language Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Config Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:49:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:49:36 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:49:36 --> URI Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Router Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Output Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Security Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Input Class Initialized
DEBUG - 2015-01-13 17:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:49:36 --> Language Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Config Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:50:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:50:07 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:50:07 --> URI Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Router Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Output Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Security Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Input Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:50:07 --> Language Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Loader Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:50:07 --> Controller Class Initialized
DEBUG - 2015-01-13 17:50:07 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:50:07 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:50:07 --> Final output sent to browser
DEBUG - 2015-01-13 17:50:07 --> Total execution time: 0.0042
DEBUG - 2015-01-13 17:50:13 --> Config Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:50:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:50:13 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:50:13 --> URI Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Router Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Output Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Security Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Input Class Initialized
DEBUG - 2015-01-13 17:50:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:50:13 --> Language Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Config Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:50:48 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:50:48 --> URI Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Router Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Output Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Security Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Input Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:50:48 --> Language Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Loader Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:50:48 --> Controller Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Email Class Initialized
DEBUG - 2015-01-13 17:50:48 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 17:50:48 --> Final output sent to browser
DEBUG - 2015-01-13 17:50:48 --> Total execution time: 0.0656
DEBUG - 2015-01-13 17:50:55 --> Config Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:50:55 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:50:55 --> URI Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Router Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Output Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Security Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Input Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:50:55 --> Language Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Loader Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:50:55 --> Controller Class Initialized
DEBUG - 2015-01-13 17:50:55 --> Database Driver Class Initialized
DEBUG - 2015-01-13 17:50:55 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 17:50:55 --> Final output sent to browser
DEBUG - 2015-01-13 17:50:55 --> Total execution time: 0.0052
DEBUG - 2015-01-13 17:51:02 --> Config Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Hooks Class Initialized
DEBUG - 2015-01-13 17:51:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 17:51:02 --> Utf8 Class Initialized
DEBUG - 2015-01-13 17:51:02 --> URI Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Router Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Output Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Security Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Input Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 17:51:02 --> Language Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Loader Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Helper loaded: url_helper
DEBUG - 2015-01-13 17:51:02 --> Controller Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Email Class Initialized
DEBUG - 2015-01-13 17:51:02 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 17:51:02 --> Final output sent to browser
DEBUG - 2015-01-13 17:51:02 --> Total execution time: 0.0087
DEBUG - 2015-01-13 19:34:10 --> Config Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Hooks Class Initialized
DEBUG - 2015-01-13 19:34:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 19:34:10 --> Utf8 Class Initialized
DEBUG - 2015-01-13 19:34:10 --> URI Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Router Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Output Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Security Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Input Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 19:34:10 --> Language Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Loader Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Helper loaded: url_helper
DEBUG - 2015-01-13 19:34:10 --> Controller Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Email Class Initialized
DEBUG - 2015-01-13 19:34:10 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 19:34:10 --> Final output sent to browser
DEBUG - 2015-01-13 19:34:10 --> Total execution time: 0.7834
DEBUG - 2015-01-13 19:34:40 --> Config Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Hooks Class Initialized
DEBUG - 2015-01-13 19:34:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 19:34:40 --> Utf8 Class Initialized
DEBUG - 2015-01-13 19:34:40 --> URI Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Router Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Output Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Security Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Input Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 19:34:40 --> Language Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Loader Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Helper loaded: url_helper
DEBUG - 2015-01-13 19:34:40 --> Controller Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Email Class Initialized
DEBUG - 2015-01-13 19:34:40 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 19:34:40 --> Final output sent to browser
DEBUG - 2015-01-13 19:34:40 --> Total execution time: 0.0106
DEBUG - 2015-01-13 19:51:04 --> Config Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Hooks Class Initialized
DEBUG - 2015-01-13 19:51:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 19:51:04 --> Utf8 Class Initialized
DEBUG - 2015-01-13 19:51:04 --> URI Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Router Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Output Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Security Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Input Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 19:51:04 --> Language Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Loader Class Initialized
DEBUG - 2015-01-13 19:51:04 --> Helper loaded: url_helper
DEBUG - 2015-01-13 19:51:04 --> Controller Class Initialized
DEBUG - 2015-01-13 19:51:05 --> Database Driver Class Initialized
DEBUG - 2015-01-13 19:51:05 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 19:51:05 --> Final output sent to browser
DEBUG - 2015-01-13 19:51:05 --> Total execution time: 0.2115
DEBUG - 2015-01-13 19:51:12 --> Config Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Hooks Class Initialized
DEBUG - 2015-01-13 19:51:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 19:51:12 --> Utf8 Class Initialized
DEBUG - 2015-01-13 19:51:12 --> URI Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Router Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Output Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Security Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Input Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 19:51:12 --> Language Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Loader Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Helper loaded: url_helper
DEBUG - 2015-01-13 19:51:12 --> Controller Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Email Class Initialized
DEBUG - 2015-01-13 19:51:12 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 19:51:12 --> Final output sent to browser
DEBUG - 2015-01-13 19:51:12 --> Total execution time: 0.0085
DEBUG - 2015-01-13 20:28:12 --> Config Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:28:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:28:12 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:28:12 --> URI Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Router Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Output Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Security Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Input Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:28:12 --> Language Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Loader Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:28:12 --> Controller Class Initialized
DEBUG - 2015-01-13 20:28:12 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:28:12 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:28:12 --> Final output sent to browser
DEBUG - 2015-01-13 20:28:12 --> Total execution time: 0.0117
DEBUG - 2015-01-13 20:28:17 --> Config Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:28:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:28:17 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:28:17 --> URI Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Router Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Output Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Security Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Input Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:28:17 --> Language Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Loader Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:28:17 --> Controller Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Email Class Initialized
DEBUG - 2015-01-13 20:28:17 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 20:28:19 --> Final output sent to browser
DEBUG - 2015-01-13 20:28:19 --> Total execution time: 2.1579
DEBUG - 2015-01-13 20:28:41 --> Config Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:28:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:28:41 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:28:41 --> URI Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Router Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Output Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Security Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Input Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:28:41 --> Language Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Loader Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:28:41 --> Controller Class Initialized
DEBUG - 2015-01-13 20:28:41 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:28:41 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:28:41 --> Final output sent to browser
DEBUG - 2015-01-13 20:28:41 --> Total execution time: 0.0118
DEBUG - 2015-01-13 20:28:45 --> Config Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:28:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:28:45 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:28:45 --> URI Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Router Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Output Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Security Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Input Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:28:45 --> Language Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Loader Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:28:45 --> Controller Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Email Class Initialized
DEBUG - 2015-01-13 20:28:45 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 20:28:45 --> Final output sent to browser
DEBUG - 2015-01-13 20:28:45 --> Total execution time: 0.3756
DEBUG - 2015-01-13 20:29:02 --> Config Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:29:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:29:02 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:29:02 --> URI Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Router Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Output Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Security Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Input Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:29:02 --> Language Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Loader Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:29:02 --> Controller Class Initialized
DEBUG - 2015-01-13 20:29:02 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:29:02 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:29:02 --> A session cookie was not found.
DEBUG - 2015-01-13 20:29:02 --> Session: Creating new session (e2c7a0705b7f5641bb7ffe0939ba21ab)
DEBUG - 2015-01-13 20:29:02 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:29:13 --> Config Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:29:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:29:13 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:29:13 --> URI Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Router Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Output Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Security Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Input Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:29:13 --> Language Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Loader Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:29:13 --> Controller Class Initialized
DEBUG - 2015-01-13 20:29:13 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:29:13 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:29:13 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:29:13 --> Final output sent to browser
DEBUG - 2015-01-13 20:29:13 --> Total execution time: 0.0208
DEBUG - 2015-01-13 20:32:47 --> Config Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:32:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:32:47 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:32:47 --> URI Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Router Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Output Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Security Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Input Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:32:47 --> Language Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Loader Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:32:47 --> Controller Class Initialized
DEBUG - 2015-01-13 20:32:47 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:32:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:32:47 --> Final output sent to browser
DEBUG - 2015-01-13 20:32:47 --> Total execution time: 0.0092
DEBUG - 2015-01-13 20:32:50 --> Config Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:32:50 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Config Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:32:50 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:32:50 --> URI Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Router Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Output Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Security Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Input Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:32:50 --> Language Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Loader Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:32:50 --> Controller Class Initialized
DEBUG - 2015-01-13 20:32:50 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:32:50 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:32:50 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:32:53 --> Config Class Initialized
DEBUG - 2015-01-13 20:32:53 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:32:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:32:53 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:32:53 --> Config Class Initialized
DEBUG - 2015-01-13 20:32:53 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:32:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:32:53 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:04 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:04 --> URI Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Router Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Output Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Security Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Input Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:33:04 --> Language Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Loader Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:33:04 --> Controller Class Initialized
DEBUG - 2015-01-13 20:33:04 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:33:04 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:33:04 --> Final output sent to browser
DEBUG - 2015-01-13 20:33:04 --> Total execution time: 0.0043
DEBUG - 2015-01-13 20:33:07 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:07 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:07 --> URI Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Router Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Output Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Security Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Input Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:33:07 --> Language Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Loader Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:33:07 --> Controller Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:07 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:07 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:33:07 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:33:07 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:33:13 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:13 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:13 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:13 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:13 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:13 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:33:20 --> Config Class Initialized
DEBUG - 2015-01-13 20:33:20 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:33:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:33:20 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Config Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:35:14 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:35:14 --> URI Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Router Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Output Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Security Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Input Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:35:14 --> Language Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Loader Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:35:14 --> Controller Class Initialized
DEBUG - 2015-01-13 20:35:14 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:35:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:35:14 --> Final output sent to browser
DEBUG - 2015-01-13 20:35:14 --> Total execution time: 0.0109
DEBUG - 2015-01-13 20:35:17 --> Config Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:35:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:35:17 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:35:17 --> URI Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Router Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Output Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Security Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Input Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:35:17 --> Language Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Loader Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:35:17 --> Controller Class Initialized
DEBUG - 2015-01-13 20:35:17 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:35:17 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:35:17 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:35:20 --> Config Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:35:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:35:20 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:35:20 --> URI Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Router Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Output Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Security Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Input Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:35:20 --> Language Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Loader Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:35:20 --> Controller Class Initialized
DEBUG - 2015-01-13 20:35:20 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:35:20 --> CI_Session Class Initialized
DEBUG - 2015-01-13 20:35:20 --> CI_Session routines successfully run
DEBUG - 2015-01-13 20:35:20 --> Final output sent to browser
DEBUG - 2015-01-13 20:35:20 --> Total execution time: 0.0132
DEBUG - 2015-01-13 20:35:26 --> Config Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:35:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:35:26 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:35:26 --> URI Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Router Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Output Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Security Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Input Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:35:26 --> Language Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Loader Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:35:26 --> Controller Class Initialized
DEBUG - 2015-01-13 20:35:26 --> Email Class Initialized
DEBUG - 2015-01-13 20:35:27 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 20:35:27 --> Final output sent to browser
DEBUG - 2015-01-13 20:35:27 --> Total execution time: 0.3957
DEBUG - 2015-01-13 20:53:21 --> Config Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:53:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:53:21 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:53:21 --> URI Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Router Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Output Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Security Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Input Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:53:21 --> Language Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Loader Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:53:21 --> Controller Class Initialized
DEBUG - 2015-01-13 20:53:21 --> Database Driver Class Initialized
DEBUG - 2015-01-13 20:53:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-13 20:53:21 --> Final output sent to browser
DEBUG - 2015-01-13 20:53:21 --> Total execution time: 0.0180
DEBUG - 2015-01-13 20:53:25 --> Config Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Hooks Class Initialized
DEBUG - 2015-01-13 20:53:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-13 20:53:25 --> Utf8 Class Initialized
DEBUG - 2015-01-13 20:53:25 --> URI Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Router Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Output Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Security Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Input Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-13 20:53:25 --> Language Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Loader Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Helper loaded: url_helper
DEBUG - 2015-01-13 20:53:25 --> Controller Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Email Class Initialized
DEBUG - 2015-01-13 20:53:25 --> Language file loaded: language/english/email_lang.php
DEBUG - 2015-01-13 20:53:25 --> Final output sent to browser
DEBUG - 2015-01-13 20:53:25 --> Total execution time: 0.3827
