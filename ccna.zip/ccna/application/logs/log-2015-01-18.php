<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-18 00:07:39 --> Config Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Hooks Class Initialized
DEBUG - 2015-01-18 00:07:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-18 00:07:39 --> Utf8 Class Initialized
DEBUG - 2015-01-18 00:07:39 --> URI Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Router Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Output Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Security Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Input Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-18 00:07:39 --> Language Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Loader Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Helper loaded: url_helper
DEBUG - 2015-01-18 00:07:39 --> Controller Class Initialized
DEBUG - 2015-01-18 00:07:39 --> Database Driver Class Initialized
DEBUG - 2015-01-18 00:07:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-18 00:07:39 --> Final output sent to browser
DEBUG - 2015-01-18 00:07:39 --> Total execution time: 0.0110
DEBUG - 2015-01-18 00:07:42 --> Config Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Hooks Class Initialized
DEBUG - 2015-01-18 00:07:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-18 00:07:42 --> Utf8 Class Initialized
DEBUG - 2015-01-18 00:07:42 --> URI Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Router Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Output Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Security Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Input Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-18 00:07:42 --> Language Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Loader Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Helper loaded: url_helper
DEBUG - 2015-01-18 00:07:42 --> Controller Class Initialized
DEBUG - 2015-01-18 00:07:42 --> Database Driver Class Initialized
DEBUG - 2015-01-18 00:07:42 --> CI_Session Class Initialized
DEBUG - 2015-01-18 00:07:42 --> CI_Session routines successfully run
DEBUG - 2015-01-18 00:07:42 --> User Agent Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Config Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Hooks Class Initialized
DEBUG - 2015-01-18 00:07:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-18 00:07:48 --> Utf8 Class Initialized
DEBUG - 2015-01-18 00:07:48 --> URI Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Router Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Output Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Security Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Input Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-18 00:07:48 --> Language Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Loader Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Helper loaded: url_helper
DEBUG - 2015-01-18 00:07:48 --> Controller Class Initialized
DEBUG - 2015-01-18 00:07:48 --> Database Driver Class Initialized
DEBUG - 2015-01-18 00:07:48 --> CI_Session Class Initialized
DEBUG - 2015-01-18 00:07:48 --> CI_Session routines successfully run
DEBUG - 2015-01-18 00:07:48 --> Final output sent to browser
DEBUG - 2015-01-18 00:07:48 --> Total execution time: 0.0131
DEBUG - 2015-01-18 00:07:52 --> Config Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Hooks Class Initialized
DEBUG - 2015-01-18 00:07:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-18 00:07:52 --> Utf8 Class Initialized
DEBUG - 2015-01-18 00:07:52 --> URI Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Router Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Output Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Security Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Input Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-18 00:07:52 --> Language Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Loader Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Helper loaded: url_helper
DEBUG - 2015-01-18 00:07:52 --> Controller Class Initialized
DEBUG - 2015-01-18 00:07:52 --> Database Driver Class Initialized
DEBUG - 2015-01-18 00:07:52 --> CI_Session Class Initialized
DEBUG - 2015-01-18 00:07:52 --> CI_Session routines successfully run
DEBUG - 2015-01-18 00:07:52 --> Final output sent to browser
DEBUG - 2015-01-18 00:07:52 --> Total execution time: 0.0125
