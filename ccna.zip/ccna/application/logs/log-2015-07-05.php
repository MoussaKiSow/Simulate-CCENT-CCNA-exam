<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-07-05 13:51:49 --> Config Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Hooks Class Initialized
DEBUG - 2015-07-05 13:51:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-05 13:51:49 --> Utf8 Class Initialized
DEBUG - 2015-07-05 13:51:49 --> URI Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Router Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Output Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Security Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Input Class Initialized
DEBUG - 2015-07-05 13:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-05 13:51:49 --> Language Class Initialized
ERROR - 2015-07-05 13:51:49 --> 404 Page Not Found: /index
DEBUG - 2015-07-05 13:51:54 --> Config Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Hooks Class Initialized
DEBUG - 2015-07-05 13:51:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-05 13:51:54 --> Utf8 Class Initialized
DEBUG - 2015-07-05 13:51:54 --> URI Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Router Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Output Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Security Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Input Class Initialized
DEBUG - 2015-07-05 13:51:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-05 13:51:54 --> Language Class Initialized
ERROR - 2015-07-05 13:51:54 --> 404 Page Not Found: /index
