<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-15 11:01:24 --> Config Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:01:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:01:24 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:01:24 --> URI Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Router Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Output Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Security Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Input Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:01:24 --> Language Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Loader Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:01:24 --> Controller Class Initialized
DEBUG - 2015-01-15 11:01:24 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:01:24 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:01:24 --> A session cookie was not found.
DEBUG - 2015-01-15 11:01:24 --> Session: Creating new session (bf3e5941b861c1b80e2fc5b2419a75c9)
DEBUG - 2015-01-15 11:01:24 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:01:24 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Config Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:02:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:02:47 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:02:47 --> URI Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Router Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Output Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Security Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Input Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:02:47 --> Language Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Loader Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:02:47 --> Controller Class Initialized
DEBUG - 2015-01-15 11:02:47 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:02:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:02:47 --> Final output sent to browser
DEBUG - 2015-01-15 11:02:47 --> Total execution time: 0.0321
DEBUG - 2015-01-15 11:02:50 --> Config Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:02:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:02:50 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:02:50 --> URI Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Router Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Output Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Security Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Input Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:02:50 --> Language Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Loader Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:02:50 --> Controller Class Initialized
DEBUG - 2015-01-15 11:02:50 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:02:50 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:02:50 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:02:50 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Config Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:02:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:02:56 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:02:56 --> URI Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Router Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Output Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Security Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Input Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:02:56 --> Language Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Loader Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:02:56 --> Controller Class Initialized
DEBUG - 2015-01-15 11:02:56 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:02:56 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:02:56 --> Final output sent to browser
DEBUG - 2015-01-15 11:02:56 --> Total execution time: 0.0061
DEBUG - 2015-01-15 11:02:59 --> Config Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:02:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:02:59 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:02:59 --> URI Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Router Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Output Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Security Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Input Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:02:59 --> Language Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Loader Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:02:59 --> Controller Class Initialized
DEBUG - 2015-01-15 11:02:59 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:02:59 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:02:59 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:02:59 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Config Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:03:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:03:15 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:03:15 --> URI Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Router Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Output Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Security Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Input Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:03:15 --> Language Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Loader Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:03:15 --> Controller Class Initialized
DEBUG - 2015-01-15 11:03:15 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:03:15 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:03:15 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:03:15 --> Final output sent to browser
DEBUG - 2015-01-15 11:03:15 --> Total execution time: 0.0163
DEBUG - 2015-01-15 11:03:18 --> Config Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:03:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:03:18 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:03:18 --> URI Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Router Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Output Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Security Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Input Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:03:18 --> Language Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Loader Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:03:18 --> Controller Class Initialized
DEBUG - 2015-01-15 11:03:18 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:03:18 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:03:18 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:03:18 --> Final output sent to browser
DEBUG - 2015-01-15 11:03:18 --> Total execution time: 0.0061
DEBUG - 2015-01-15 11:37:24 --> Config Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:37:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:37:24 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:37:24 --> URI Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Router Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Output Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Security Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Input Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:37:24 --> Language Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Loader Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:37:24 --> Controller Class Initialized
DEBUG - 2015-01-15 11:37:24 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:37:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:37:24 --> Final output sent to browser
DEBUG - 2015-01-15 11:37:24 --> Total execution time: 0.0067
DEBUG - 2015-01-15 11:37:27 --> Config Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:37:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:37:27 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:37:27 --> URI Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Router Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Output Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Security Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Input Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:37:27 --> Language Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Loader Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:37:27 --> Controller Class Initialized
DEBUG - 2015-01-15 11:37:27 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:37:27 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:37:27 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:37:27 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Config Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:37:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:37:57 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:37:57 --> URI Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Router Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Output Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Security Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Input Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:37:57 --> Language Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Loader Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:37:57 --> Controller Class Initialized
DEBUG - 2015-01-15 11:37:57 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:37:57 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:37:57 --> Final output sent to browser
DEBUG - 2015-01-15 11:37:57 --> Total execution time: 0.0044
DEBUG - 2015-01-15 11:38:05 --> Config Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:38:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:38:05 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:38:05 --> URI Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Router Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Output Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Security Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Input Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:38:05 --> Language Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Loader Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:38:05 --> Controller Class Initialized
DEBUG - 2015-01-15 11:38:05 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:38:05 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:38:05 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:38:05 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:09 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:09 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:09 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:09 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:09 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:09 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:39:09 --> Final output sent to browser
DEBUG - 2015-01-15 11:39:09 --> Total execution time: 0.0039
DEBUG - 2015-01-15 11:39:11 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:11 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:11 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:11 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:11 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:11 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:11 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:39:11 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:39:11 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:29 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:29 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:29 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:29 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:29 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:39:29 --> Final output sent to browser
DEBUG - 2015-01-15 11:39:29 --> Total execution time: 0.0132
DEBUG - 2015-01-15 11:39:31 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:31 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:31 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:31 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:31 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:31 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:31 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:39:31 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:39:31 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:42 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:42 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:42 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:42 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:42 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:42 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:39:42 --> Final output sent to browser
DEBUG - 2015-01-15 11:39:42 --> Total execution time: 0.0051
DEBUG - 2015-01-15 11:39:43 --> Config Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:39:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:39:43 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:39:43 --> URI Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Router Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Output Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Security Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Input Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:39:43 --> Language Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Loader Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:39:43 --> Controller Class Initialized
DEBUG - 2015-01-15 11:39:43 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:39:43 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:39:43 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:39:43 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Config Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:41:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:41:29 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:41:29 --> URI Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Router Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Output Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Security Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Input Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:41:29 --> Language Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Loader Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:41:29 --> Controller Class Initialized
DEBUG - 2015-01-15 11:41:29 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:41:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:41:29 --> Final output sent to browser
DEBUG - 2015-01-15 11:41:29 --> Total execution time: 0.0034
DEBUG - 2015-01-15 11:41:32 --> Config Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:41:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:41:32 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:41:32 --> URI Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Router Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Output Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Security Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Input Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:41:32 --> Language Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Loader Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:41:32 --> Controller Class Initialized
DEBUG - 2015-01-15 11:41:32 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:41:32 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:41:32 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:41:32 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Config Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:43:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:43:41 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:43:41 --> URI Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Router Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Output Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Security Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Input Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:43:41 --> Language Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Loader Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:43:41 --> Controller Class Initialized
DEBUG - 2015-01-15 11:43:41 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:43:41 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:43:41 --> Final output sent to browser
DEBUG - 2015-01-15 11:43:41 --> Total execution time: 0.0112
DEBUG - 2015-01-15 11:43:43 --> Config Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:43:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:43:43 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:43:43 --> URI Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Router Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Output Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Security Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Input Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:43:43 --> Language Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Loader Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:43:43 --> Controller Class Initialized
DEBUG - 2015-01-15 11:43:43 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:43:43 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:43:43 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:43:43 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Config Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:45:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:45:45 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:45:45 --> URI Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Router Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Output Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Security Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Input Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:45:45 --> Language Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Loader Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:45:45 --> Controller Class Initialized
DEBUG - 2015-01-15 11:45:45 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:45:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:45:45 --> Final output sent to browser
DEBUG - 2015-01-15 11:45:45 --> Total execution time: 0.0047
DEBUG - 2015-01-15 11:45:48 --> Config Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:45:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:45:48 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:45:48 --> URI Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Router Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Output Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Security Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Input Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:45:48 --> Language Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Loader Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:45:48 --> Controller Class Initialized
DEBUG - 2015-01-15 11:45:48 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:45:48 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:45:48 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:45:48 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Config Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:46:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:46:12 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:46:12 --> URI Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Router Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Output Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Security Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Input Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:46:12 --> Language Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Loader Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:46:12 --> Controller Class Initialized
DEBUG - 2015-01-15 11:46:12 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:46:12 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:46:12 --> Final output sent to browser
DEBUG - 2015-01-15 11:46:12 --> Total execution time: 0.0041
DEBUG - 2015-01-15 11:46:14 --> Config Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:46:14 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:46:14 --> URI Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Router Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Output Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Security Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Input Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:46:14 --> Language Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Loader Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:46:14 --> Controller Class Initialized
DEBUG - 2015-01-15 11:46:14 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:46:14 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:46:14 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:46:14 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Config Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:46:43 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:46:43 --> URI Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Router Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Output Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Security Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Input Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:46:43 --> Language Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Loader Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:46:43 --> Controller Class Initialized
DEBUG - 2015-01-15 11:46:43 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:46:43 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:46:43 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:46:43 --> Final output sent to browser
DEBUG - 2015-01-15 11:46:43 --> Total execution time: 0.0088
DEBUG - 2015-01-15 11:47:12 --> Config Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:47:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:47:12 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:47:12 --> URI Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Router Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Output Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Security Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Input Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:47:12 --> Language Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Loader Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:47:12 --> Controller Class Initialized
DEBUG - 2015-01-15 11:47:12 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:47:12 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:47:12 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:47:12 --> Final output sent to browser
DEBUG - 2015-01-15 11:47:12 --> Total execution time: 0.0080
DEBUG - 2015-01-15 11:47:13 --> Config Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:47:13 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:47:13 --> URI Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Router Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Output Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Security Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Input Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:47:13 --> Language Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Loader Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:47:13 --> Controller Class Initialized
DEBUG - 2015-01-15 11:47:13 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:47:13 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:47:13 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:47:13 --> Final output sent to browser
DEBUG - 2015-01-15 11:47:13 --> Total execution time: 0.0076
DEBUG - 2015-01-15 11:47:20 --> Config Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:47:20 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:47:20 --> URI Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Router Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Output Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Security Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Input Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:47:20 --> Language Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Loader Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:47:20 --> Controller Class Initialized
DEBUG - 2015-01-15 11:47:20 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:47:20 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:47:20 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:47:20 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Config Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:47:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:47:44 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:47:44 --> URI Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Router Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Output Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Security Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Input Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:47:44 --> Language Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Loader Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:47:44 --> Controller Class Initialized
DEBUG - 2015-01-15 11:47:44 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:47:44 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:47:44 --> Final output sent to browser
DEBUG - 2015-01-15 11:47:44 --> Total execution time: 0.0094
DEBUG - 2015-01-15 11:47:47 --> Config Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:47:47 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:47:47 --> URI Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Router Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Output Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Security Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Input Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:47:47 --> Language Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Loader Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:47:47 --> Controller Class Initialized
DEBUG - 2015-01-15 11:47:47 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:47:47 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:47:47 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:47:47 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Config Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:49:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:49:24 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:49:24 --> URI Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Router Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Output Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Security Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Input Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:49:24 --> Language Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Loader Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:49:24 --> Controller Class Initialized
DEBUG - 2015-01-15 11:49:24 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:49:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:49:24 --> Final output sent to browser
DEBUG - 2015-01-15 11:49:24 --> Total execution time: 0.0040
DEBUG - 2015-01-15 11:52:34 --> Config Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:52:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:52:34 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:52:34 --> URI Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Router Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Output Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Security Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Input Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:52:34 --> Language Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Loader Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:52:34 --> Controller Class Initialized
DEBUG - 2015-01-15 11:52:34 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:52:34 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:52:34 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:52:34 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Config Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:52:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:52:49 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:52:49 --> URI Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Router Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Output Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Security Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Input Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:52:49 --> Language Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Loader Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:52:49 --> Controller Class Initialized
DEBUG - 2015-01-15 11:52:49 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:52:49 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:52:49 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:52:49 --> Final output sent to browser
DEBUG - 2015-01-15 11:52:49 --> Total execution time: 0.0095
DEBUG - 2015-01-15 11:53:46 --> Config Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:53:46 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:53:46 --> URI Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Router Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Output Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Security Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Input Class Initialized
DEBUG - 2015-01-15 11:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:53:46 --> Language Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Config Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:54:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:54:45 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:54:45 --> URI Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Router Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Output Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Security Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Input Class Initialized
DEBUG - 2015-01-15 11:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:54:45 --> Language Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Config Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:55:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:55:22 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:55:22 --> URI Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Router Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Output Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Security Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Input Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:55:22 --> Language Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Loader Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:55:22 --> Controller Class Initialized
DEBUG - 2015-01-15 11:55:22 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:55:22 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:55:22 --> Final output sent to browser
DEBUG - 2015-01-15 11:55:22 --> Total execution time: 0.0061
DEBUG - 2015-01-15 11:55:25 --> Config Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:55:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:55:25 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:55:25 --> URI Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Router Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Output Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Security Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Input Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:55:25 --> Language Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Loader Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:55:25 --> Controller Class Initialized
DEBUG - 2015-01-15 11:55:25 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:55:25 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:55:25 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:55:25 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:10 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:10 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:10 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:10 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:10 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:10 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:58:10 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:10 --> Total execution time: 0.0191
DEBUG - 2015-01-15 11:58:13 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:13 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:13 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:13 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:13 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:13 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:13 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:13 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:13 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:17 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:17 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:17 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:17 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:17 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:17 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:17 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:17 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:17 --> Total execution time: 0.0122
DEBUG - 2015-01-15 11:58:19 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:19 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:19 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:19 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:19 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:19 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:19 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:19 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:19 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:19 --> Total execution time: 0.0100
DEBUG - 2015-01-15 11:58:20 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:20 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:20 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:20 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:20 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:20 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:20 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:20 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:20 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:20 --> Total execution time: 0.0060
DEBUG - 2015-01-15 11:58:21 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:21 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:21 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:21 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:21 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:21 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:21 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:21 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:21 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:21 --> Total execution time: 0.0071
DEBUG - 2015-01-15 11:58:40 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:40 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:40 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:40 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:40 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:40 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:40 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:40 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:40 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:40 --> Total execution time: 0.0087
DEBUG - 2015-01-15 11:58:45 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:45 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:45 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:45 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:45 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:45 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:45 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:58:45 --> Final output sent to browser
DEBUG - 2015-01-15 11:58:45 --> Total execution time: 0.0071
DEBUG - 2015-01-15 11:58:47 --> Config Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:58:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:58:47 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:58:47 --> URI Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Router Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Output Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Security Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Input Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:58:47 --> Language Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Loader Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:58:47 --> Controller Class Initialized
DEBUG - 2015-01-15 11:58:47 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:58:47 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:58:47 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:58:47 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Config Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:59:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:59:06 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:59:06 --> URI Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Router Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Output Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Security Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Input Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:59:06 --> Language Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Loader Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:59:06 --> Controller Class Initialized
DEBUG - 2015-01-15 11:59:06 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:59:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:59:06 --> Final output sent to browser
DEBUG - 2015-01-15 11:59:06 --> Total execution time: 0.0068
DEBUG - 2015-01-15 11:59:09 --> Config Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:59:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:59:09 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:59:09 --> URI Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Router Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Output Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Security Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Input Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:59:09 --> Language Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Loader Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:59:09 --> Controller Class Initialized
DEBUG - 2015-01-15 11:59:09 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:59:09 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:59:09 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:59:09 --> User Agent Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Config Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:59:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:59:52 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:59:52 --> URI Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Router Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Output Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Security Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Input Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:59:52 --> Language Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Loader Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:59:52 --> Controller Class Initialized
DEBUG - 2015-01-15 11:59:52 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:59:52 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 11:59:52 --> Final output sent to browser
DEBUG - 2015-01-15 11:59:52 --> Total execution time: 0.0115
DEBUG - 2015-01-15 11:59:54 --> Config Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Hooks Class Initialized
DEBUG - 2015-01-15 11:59:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 11:59:54 --> Utf8 Class Initialized
DEBUG - 2015-01-15 11:59:54 --> URI Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Router Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Output Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Security Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Input Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 11:59:54 --> Language Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Loader Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Helper loaded: url_helper
DEBUG - 2015-01-15 11:59:54 --> Controller Class Initialized
DEBUG - 2015-01-15 11:59:54 --> Database Driver Class Initialized
DEBUG - 2015-01-15 11:59:54 --> CI_Session Class Initialized
DEBUG - 2015-01-15 11:59:54 --> CI_Session routines successfully run
DEBUG - 2015-01-15 11:59:54 --> User Agent Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Config Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:00:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:00:14 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:00:14 --> URI Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Router Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Output Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Security Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Input Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:00:14 --> Language Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Loader Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:00:14 --> Controller Class Initialized
DEBUG - 2015-01-15 12:00:14 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:00:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 12:00:14 --> Final output sent to browser
DEBUG - 2015-01-15 12:00:14 --> Total execution time: 0.0051
DEBUG - 2015-01-15 12:00:17 --> Config Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:00:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:00:17 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:00:17 --> URI Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Router Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Output Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Security Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Input Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:00:17 --> Language Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Loader Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:00:17 --> Controller Class Initialized
DEBUG - 2015-01-15 12:00:17 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:00:17 --> CI_Session Class Initialized
DEBUG - 2015-01-15 12:00:17 --> CI_Session routines successfully run
DEBUG - 2015-01-15 12:00:17 --> User Agent Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Config Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:00:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:00:28 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:00:28 --> URI Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Router Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Output Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Security Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Input Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:00:28 --> Language Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Loader Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:00:28 --> Controller Class Initialized
DEBUG - 2015-01-15 12:00:28 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:00:28 --> CI_Session Class Initialized
DEBUG - 2015-01-15 12:00:28 --> CI_Session routines successfully run
DEBUG - 2015-01-15 12:00:28 --> Final output sent to browser
DEBUG - 2015-01-15 12:00:28 --> Total execution time: 0.0068
DEBUG - 2015-01-15 12:00:33 --> Config Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:00:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:00:33 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:00:33 --> URI Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Router Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Output Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Security Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Input Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:00:33 --> Language Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Loader Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:00:33 --> Controller Class Initialized
DEBUG - 2015-01-15 12:00:33 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:00:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 12:00:33 --> Final output sent to browser
DEBUG - 2015-01-15 12:00:33 --> Total execution time: 0.0196
DEBUG - 2015-01-15 12:00:36 --> Config Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:00:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:00:36 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:00:36 --> URI Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Router Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Output Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Security Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Input Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:00:36 --> Language Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Loader Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:00:36 --> Controller Class Initialized
DEBUG - 2015-01-15 12:00:36 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:00:36 --> CI_Session Class Initialized
DEBUG - 2015-01-15 12:00:36 --> CI_Session routines successfully run
DEBUG - 2015-01-15 12:00:36 --> User Agent Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Config Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Hooks Class Initialized
DEBUG - 2015-01-15 12:14:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-15 12:14:39 --> Utf8 Class Initialized
DEBUG - 2015-01-15 12:14:39 --> URI Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Router Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Output Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Security Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Input Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-15 12:14:39 --> Language Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Loader Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Helper loaded: url_helper
DEBUG - 2015-01-15 12:14:39 --> Controller Class Initialized
DEBUG - 2015-01-15 12:14:39 --> Database Driver Class Initialized
DEBUG - 2015-01-15 12:14:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-15 12:14:39 --> Final output sent to browser
DEBUG - 2015-01-15 12:14:39 --> Total execution time: 0.0143
