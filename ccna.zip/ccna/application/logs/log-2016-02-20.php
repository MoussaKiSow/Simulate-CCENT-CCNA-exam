<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-20 11:02:55 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:02:55 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:02:55 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:02:58 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:03:07 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:03:07 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:03:07 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:03:09 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:03:09 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:03:09 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:07:12 --> 404 Page Not Found: Praticecomptianetworkn1006ajax/index
ERROR - 2016-02-20 11:07:48 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:07:48 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:07:48 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:07:50 --> 404 Page Not Found: Praticecomptianetworkn1006ajax/index
ERROR - 2016-02-20 11:07:57 --> 404 Page Not Found: Praticecomptia220801ajax/index
ERROR - 2016-02-20 11:08:23 --> 404 Page Not Found: Praticecomptianetworkn1006ajax/index
ERROR - 2016-02-20 11:08:28 --> 404 Page Not Found: Praticecomptianetworkn1006ajax/index
ERROR - 2016-02-20 11:08:32 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:08:32 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:08:32 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:10:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:10:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:10:05 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:10:30 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:10:30 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:10:30 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:13:43 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:14:39 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:14:40 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:17:47 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 2
ERROR - 2016-02-20 11:20:33 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:21:36 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:21:37 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:22:07 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:22:08 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:22:32 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:22:33 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:24:00 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 1
ERROR - 2016-02-20 11:24:25 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:24:26 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:25:48 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT COUNT(*) AS `numrows`
FROM `QuestionsNetplus`
WHERE `status_mobile` LIKE '%01%' ESCAPE '!'
ERROR - 2016-02-20 11:27:41 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 77
ERROR - 2016-02-20 11:27:42 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 77
ERROR - 2016-02-20 11:29:12 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:29:14 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 2
ERROR - 2016-02-20 11:30:25 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 1
ERROR - 2016-02-20 11:30:56 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 2
ERROR - 2016-02-20 11:33:36 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 1
ERROR - 2016-02-20 11:37:25 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 2
ERROR - 2016-02-20 11:38:24 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsComptia3`
WHERE `Code` = 1
ERROR - 2016-02-20 11:42:57 --> Query error: Table 'esmartso_01102010.QuestionsNetplus' doesn't exist - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-20 11:44:01 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:44:01 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:44:01 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:44:07 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:44:07 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:44:07 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:45:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:45:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:45:05 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:45:28 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:45:28 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:45:28 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 11:45:30 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 11:45:30 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 11:45:30 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 12:15:32 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 12:15:32 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 12:15:32 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 13:06:43 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 13:06:43 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 13:06:43 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 22:22:14 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 22:22:14 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 22:22:14 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-20 23:42:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-20 23:42:05 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-20 23:42:05 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
