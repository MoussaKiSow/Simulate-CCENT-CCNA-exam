<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2016-02-17 22:26:01 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:26:04 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:26:05 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:27:15 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:27:16 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:27:18 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:37:11 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:40:17 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:40:21 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:40:55 --> 404 Page Not Found: /index
ERROR - 2016-02-17 22:42:10 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 22:42:10 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 22:42:10 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 22:42:14 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 22:42:14 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 22:42:14 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 22:42:17 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 22:42:17 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 22:42:17 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 22:48:00 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 22:48:00 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 22:48:00 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 22:51:00 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 22:51:00 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 22:51:00 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 22:54:27 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:01:52 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 23:01:52 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 23:01:52 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 23:01:57 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:02:10 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:02:41 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:03:17 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:03:25 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 23:03:25 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 23:03:25 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 23:03:40 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:05:03 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:05:10 --> 404 Page Not Found: Ppraticecomptianetworkn1006ajax/index
ERROR - 2016-02-17 23:05:16 --> 404 Page Not Found: Ppraticecomptianetworkn1006/index
ERROR - 2016-02-17 23:05:22 --> 404 Page Not Found: Ppraticecomptianetworkn1006/index
ERROR - 2016-02-17 23:05:27 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 23:05:27 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 23:05:27 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 23:05:35 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 23:05:35 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 23:05:35 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
ERROR - 2016-02-17 23:05:36 --> Query error: Unknown column 'Type' in 'field list' - Invalid query: SELECT `Code`, `Description`, `Type`
FROM `QuestionsNetplus`
WHERE `Code` = 1
ERROR - 2016-02-17 23:05:37 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 183
ERROR - 2016-02-17 23:05:37 --> Severity: Warning --> date() [<a href='function.date'>function.date</a>]: It is not safe to rely on the system's timezone settings. You are *required* to use the date.timezone setting or the date_default_timezone_set() function. In case you used any of those methods and you are still getting this warning, you most likely misspelled the timezone identifier. We selected 'UTC' for 'GMT/0.0/no DST' instead /home/esmartso/public_html/comptianetworkn10006/system/core/Log.php 201
ERROR - 2016-02-17 23:05:37 --> Severity: Core Warning --> Module 'mysql' already loaded Unknown 0
