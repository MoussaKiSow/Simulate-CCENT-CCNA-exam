<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-27 11:48:22 --> Config Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Hooks Class Initialized
DEBUG - 2015-01-27 11:48:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-27 11:48:22 --> Utf8 Class Initialized
DEBUG - 2015-01-27 11:48:22 --> URI Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Router Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Output Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Security Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Input Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-27 11:48:22 --> Language Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Loader Class Initialized
DEBUG - 2015-01-27 11:48:22 --> Helper loaded: url_helper
DEBUG - 2015-01-27 11:48:22 --> Controller Class Initialized
DEBUG - 2015-01-27 11:48:22 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-27 11:48:22 --> Final output sent to browser
DEBUG - 2015-01-27 11:48:22 --> Total execution time: 0.1710
DEBUG - 2015-01-27 11:48:26 --> Config Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Hooks Class Initialized
DEBUG - 2015-01-27 11:48:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-27 11:48:26 --> Utf8 Class Initialized
DEBUG - 2015-01-27 11:48:26 --> URI Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Router Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Output Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Security Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Input Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-27 11:48:26 --> Language Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Loader Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Helper loaded: url_helper
DEBUG - 2015-01-27 11:48:26 --> Controller Class Initialized
DEBUG - 2015-01-27 11:48:26 --> Database Driver Class Initialized
DEBUG - 2015-01-27 11:48:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-27 11:48:26 --> Final output sent to browser
DEBUG - 2015-01-27 11:48:26 --> Total execution time: 0.1702
DEBUG - 2015-01-27 12:20:38 --> Config Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Hooks Class Initialized
DEBUG - 2015-01-27 12:20:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-27 12:20:38 --> Utf8 Class Initialized
DEBUG - 2015-01-27 12:20:38 --> URI Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Router Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Output Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Security Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Input Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-27 12:20:38 --> Language Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Loader Class Initialized
DEBUG - 2015-01-27 12:20:38 --> Helper loaded: url_helper
DEBUG - 2015-01-27 12:20:38 --> Controller Class Initialized
DEBUG - 2015-01-27 12:20:38 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/about.php
DEBUG - 2015-01-27 12:20:38 --> Final output sent to browser
DEBUG - 2015-01-27 12:20:38 --> Total execution time: 0.0055
