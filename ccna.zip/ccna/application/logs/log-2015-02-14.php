<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-02-14 20:43:51 --> Config Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:43:51 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:43:51 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:43:51 --> URI Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Router Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Output Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Security Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Input Class Initialized
DEBUG - 2015-02-14 20:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:43:51 --> Language Class Initialized
ERROR - 2015-02-14 20:43:51 --> 404 Page Not Found: /index
DEBUG - 2015-02-14 20:43:58 --> Config Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:43:58 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:43:58 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:43:58 --> URI Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Router Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Output Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Security Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Input Class Initialized
DEBUG - 2015-02-14 20:43:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:43:58 --> Language Class Initialized
ERROR - 2015-02-14 20:43:58 --> 404 Page Not Found: /index
DEBUG - 2015-02-14 20:44:03 --> Config Class Initialized
DEBUG - 2015-02-14 20:44:03 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:44:03 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:44:03 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Config Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:44:06 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:44:06 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:44:06 --> URI Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Router Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Output Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Security Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Input Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:44:06 --> Language Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Loader Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:44:06 --> Controller Class Initialized
DEBUG - 2015-02-14 20:44:06 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:44:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-02-14 20:44:06 --> Final output sent to browser
DEBUG - 2015-02-14 20:44:06 --> Total execution time: 0.1354
DEBUG - 2015-02-14 20:44:16 --> Config Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Hooks Class Initialized
DEBUG - 2015-02-14 20:44:16 --> UTF-8 Support Enabled
DEBUG - 2015-02-14 20:44:16 --> Utf8 Class Initialized
DEBUG - 2015-02-14 20:44:16 --> URI Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Router Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Output Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Security Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Input Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-02-14 20:44:16 --> Language Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Loader Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Helper loaded: url_helper
DEBUG - 2015-02-14 20:44:16 --> Controller Class Initialized
DEBUG - 2015-02-14 20:44:16 --> Database Driver Class Initialized
DEBUG - 2015-02-14 20:44:16 --> CI_Session Class Initialized
DEBUG - 2015-02-14 20:44:16 --> CI_Session routines successfully run
DEBUG - 2015-02-14 20:44:16 --> User Agent Class Initialized
ERROR - 2015-02-14 20:44:17 --> Query error: Unknown column 'user_data' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `user_data`, `username`, `prize`) VALUES ('8fbb8da189d086c72df3baad74bd8188', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:35.0) Gecko/20100101 Firefox/35.0', 1423946588, '', 'Guest', 0)
