<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-07-21 17:41:41 --> Config Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Hooks Class Initialized
DEBUG - 2015-07-21 17:41:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 17:41:41 --> Utf8 Class Initialized
DEBUG - 2015-07-21 17:41:41 --> URI Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Router Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Output Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Security Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Input Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 17:41:41 --> Language Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Loader Class Initialized
DEBUG - 2015-07-21 17:41:41 --> Helper loaded: url_helper
DEBUG - 2015-07-21 17:41:41 --> Controller Class Initialized
DEBUG - 2015-07-21 17:41:41 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 17:41:41 --> Final output sent to browser
DEBUG - 2015-07-21 17:41:41 --> Total execution time: 0.0037
DEBUG - 2015-07-21 17:41:49 --> Config Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Hooks Class Initialized
DEBUG - 2015-07-21 17:41:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 17:41:49 --> Utf8 Class Initialized
DEBUG - 2015-07-21 17:41:49 --> URI Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Router Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Output Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Security Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Input Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 17:41:49 --> Language Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Loader Class Initialized
DEBUG - 2015-07-21 17:41:49 --> Helper loaded: url_helper
DEBUG - 2015-07-21 17:41:49 --> Controller Class Initialized
DEBUG - 2015-07-21 17:41:49 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 17:41:49 --> Final output sent to browser
DEBUG - 2015-07-21 17:41:49 --> Total execution time: 0.0019
DEBUG - 2015-07-21 17:41:52 --> Config Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Hooks Class Initialized
DEBUG - 2015-07-21 17:41:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 17:41:52 --> Utf8 Class Initialized
DEBUG - 2015-07-21 17:41:52 --> URI Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Router Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Output Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Security Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Input Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 17:41:52 --> Language Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Loader Class Initialized
DEBUG - 2015-07-21 17:41:52 --> Helper loaded: url_helper
DEBUG - 2015-07-21 17:41:52 --> Controller Class Initialized
DEBUG - 2015-07-21 17:41:52 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 17:41:52 --> Final output sent to browser
DEBUG - 2015-07-21 17:41:52 --> Total execution time: 0.0018
DEBUG - 2015-07-21 17:41:53 --> Config Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Hooks Class Initialized
DEBUG - 2015-07-21 17:41:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 17:41:53 --> Utf8 Class Initialized
DEBUG - 2015-07-21 17:41:53 --> URI Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Router Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Output Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Security Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Input Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 17:41:53 --> Language Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Loader Class Initialized
DEBUG - 2015-07-21 17:41:53 --> Helper loaded: url_helper
DEBUG - 2015-07-21 17:41:53 --> Controller Class Initialized
DEBUG - 2015-07-21 17:41:53 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 17:41:53 --> Final output sent to browser
DEBUG - 2015-07-21 17:41:53 --> Total execution time: 0.0017
DEBUG - 2015-07-21 17:42:58 --> Config Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Hooks Class Initialized
DEBUG - 2015-07-21 17:42:58 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 17:42:58 --> Utf8 Class Initialized
DEBUG - 2015-07-21 17:42:58 --> URI Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Router Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Output Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Security Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Input Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 17:42:58 --> Language Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Loader Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Helper loaded: url_helper
DEBUG - 2015-07-21 17:42:58 --> Controller Class Initialized
DEBUG - 2015-07-21 17:42:58 --> Database Driver Class Initialized
ERROR - 2015-07-21 17:42:58 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:01:00 --> Config Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:01:00 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:01:00 --> URI Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Router Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Output Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Security Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Input Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:01:00 --> Language Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Loader Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:01:00 --> Controller Class Initialized
DEBUG - 2015-07-21 18:01:00 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:01:00 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:01:01 --> Config Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:01:01 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:01:01 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:01:01 --> URI Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Router Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Output Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Security Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Input Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:01:01 --> Language Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Loader Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:01:01 --> Controller Class Initialized
DEBUG - 2015-07-21 18:01:01 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:01:01 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:07:04 --> Config Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:07:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:07:04 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:07:04 --> URI Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Router Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Output Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Security Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Input Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:07:04 --> Language Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Loader Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:07:04 --> Controller Class Initialized
DEBUG - 2015-07-21 18:07:04 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:07:04 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:07:33 --> Config Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:07:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:07:33 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:07:33 --> URI Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Router Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Output Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Security Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Input Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:07:33 --> Language Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Loader Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:07:33 --> Controller Class Initialized
DEBUG - 2015-07-21 18:07:33 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:07:33 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:08:04 --> Config Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:08:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:08:04 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:08:04 --> URI Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Router Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Output Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Security Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Input Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:08:04 --> Language Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Loader Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:08:04 --> Controller Class Initialized
DEBUG - 2015-07-21 18:08:04 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:08:04 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:08:21 --> Config Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:08:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:08:21 --> URI Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Router Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Output Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Security Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Input Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:08:21 --> Language Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Loader Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:08:21 --> Controller Class Initialized
DEBUG - 2015-07-21 18:08:21 --> Database Driver Class Initialized
ERROR - 2015-07-21 18:08:21 --> Query error: Table 'AdwordsExamenes.jos_content' doesn't exist - Invalid query: SELECT `alias`
FROM `jos_content`
WHERE `idQuestion` = 1
DEBUG - 2015-07-21 18:09:05 --> Config Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:09:05 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:09:05 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:09:05 --> URI Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Router Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Output Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Security Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Input Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:09:05 --> Language Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Loader Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:09:05 --> Controller Class Initialized
DEBUG - 2015-07-21 18:09:05 --> Database Driver Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Config Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:42:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:42:11 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:42:11 --> URI Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Router Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Output Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Security Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Input Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:42:11 --> Language Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Loader Class Initialized
DEBUG - 2015-07-21 18:42:11 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:42:11 --> Controller Class Initialized
DEBUG - 2015-07-21 18:42:11 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 18:42:11 --> Final output sent to browser
DEBUG - 2015-07-21 18:42:11 --> Total execution time: 0.0061
DEBUG - 2015-07-21 18:42:14 --> Config Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:42:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:42:14 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:42:14 --> URI Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Router Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Output Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Security Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Input Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:42:14 --> Language Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Loader Class Initialized
DEBUG - 2015-07-21 18:42:14 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:42:14 --> Controller Class Initialized
DEBUG - 2015-07-21 18:42:14 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 18:42:14 --> Final output sent to browser
DEBUG - 2015-07-21 18:42:14 --> Total execution time: 0.0018
DEBUG - 2015-07-21 18:42:15 --> Config Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Hooks Class Initialized
DEBUG - 2015-07-21 18:42:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 18:42:15 --> Utf8 Class Initialized
DEBUG - 2015-07-21 18:42:15 --> URI Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Router Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Output Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Security Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Input Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 18:42:15 --> Language Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Loader Class Initialized
DEBUG - 2015-07-21 18:42:15 --> Helper loaded: url_helper
DEBUG - 2015-07-21 18:42:15 --> Controller Class Initialized
DEBUG - 2015-07-21 18:42:15 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 18:42:15 --> Final output sent to browser
DEBUG - 2015-07-21 18:42:15 --> Total execution time: 0.0024
DEBUG - 2015-07-21 19:09:54 --> Config Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:09:54 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:09:54 --> URI Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Router Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Output Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Security Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Input Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:09:54 --> Language Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Loader Class Initialized
DEBUG - 2015-07-21 19:09:54 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:09:54 --> Controller Class Initialized
DEBUG - 2015-07-21 19:09:54 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:09:54 --> Final output sent to browser
DEBUG - 2015-07-21 19:09:54 --> Total execution time: 0.0827
DEBUG - 2015-07-21 19:15:13 --> Config Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:15:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:15:13 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:15:13 --> URI Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Router Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Output Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Security Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Input Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:15:13 --> Language Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Loader Class Initialized
DEBUG - 2015-07-21 19:15:13 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:15:13 --> Controller Class Initialized
DEBUG - 2015-07-21 19:15:13 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:15:13 --> Final output sent to browser
DEBUG - 2015-07-21 19:15:13 --> Total execution time: 0.0020
DEBUG - 2015-07-21 19:15:17 --> Config Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:15:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:15:17 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:15:17 --> URI Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Router Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Output Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Security Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Input Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:15:17 --> Language Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Loader Class Initialized
DEBUG - 2015-07-21 19:15:17 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:15:17 --> Controller Class Initialized
DEBUG - 2015-07-21 19:15:17 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:15:17 --> Final output sent to browser
DEBUG - 2015-07-21 19:15:17 --> Total execution time: 0.0020
DEBUG - 2015-07-21 19:15:18 --> Config Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:15:18 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:15:18 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:15:18 --> URI Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Router Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Output Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Security Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Input Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:15:18 --> Language Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Loader Class Initialized
DEBUG - 2015-07-21 19:15:18 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:15:18 --> Controller Class Initialized
DEBUG - 2015-07-21 19:15:18 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:15:18 --> Final output sent to browser
DEBUG - 2015-07-21 19:15:18 --> Total execution time: 0.0023
DEBUG - 2015-07-21 19:15:19 --> Config Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:15:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:15:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:15:19 --> URI Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Router Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Output Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Security Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Input Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:15:19 --> Language Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Loader Class Initialized
DEBUG - 2015-07-21 19:15:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:15:19 --> Controller Class Initialized
DEBUG - 2015-07-21 19:15:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:15:19 --> Final output sent to browser
DEBUG - 2015-07-21 19:15:19 --> Total execution time: 0.0029
DEBUG - 2015-07-21 19:16:06 --> Config Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:16:06 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:16:06 --> URI Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Router Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Output Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Security Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Input Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:16:06 --> Language Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Loader Class Initialized
DEBUG - 2015-07-21 19:16:06 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:16:06 --> Controller Class Initialized
DEBUG - 2015-07-21 19:16:06 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:16:06 --> Final output sent to browser
DEBUG - 2015-07-21 19:16:06 --> Total execution time: 0.0022
DEBUG - 2015-07-21 19:16:07 --> Config Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:16:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:16:07 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:16:07 --> URI Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Router Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Output Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Security Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Input Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:16:07 --> Language Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Loader Class Initialized
DEBUG - 2015-07-21 19:16:07 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:16:07 --> Controller Class Initialized
DEBUG - 2015-07-21 19:16:07 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:16:07 --> Final output sent to browser
DEBUG - 2015-07-21 19:16:07 --> Total execution time: 0.0029
DEBUG - 2015-07-21 19:17:08 --> Config Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:17:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:17:08 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:17:08 --> URI Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Router Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Output Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Security Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Input Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:17:08 --> Language Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Loader Class Initialized
DEBUG - 2015-07-21 19:17:08 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:17:08 --> Controller Class Initialized
DEBUG - 2015-07-21 19:17:08 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:17:08 --> Final output sent to browser
DEBUG - 2015-07-21 19:17:08 --> Total execution time: 0.2193
DEBUG - 2015-07-21 19:17:17 --> Config Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:17:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:17:17 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:17:17 --> URI Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Router Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Output Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Security Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Input Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:17:17 --> Language Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Loader Class Initialized
DEBUG - 2015-07-21 19:17:17 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:17:17 --> Controller Class Initialized
DEBUG - 2015-07-21 19:17:17 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:17:17 --> Final output sent to browser
DEBUG - 2015-07-21 19:17:17 --> Total execution time: 0.0019
DEBUG - 2015-07-21 19:18:31 --> Config Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:18:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:18:31 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:18:31 --> URI Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Router Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Output Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Security Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Input Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:18:31 --> Language Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Loader Class Initialized
DEBUG - 2015-07-21 19:18:31 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:18:31 --> Controller Class Initialized
DEBUG - 2015-07-21 19:18:31 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:18:31 --> Final output sent to browser
DEBUG - 2015-07-21 19:18:31 --> Total execution time: 0.0031
DEBUG - 2015-07-21 19:18:33 --> Config Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:18:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:18:33 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:18:33 --> URI Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Router Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Output Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Security Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Input Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:18:33 --> Language Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Loader Class Initialized
DEBUG - 2015-07-21 19:18:33 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:18:33 --> Controller Class Initialized
DEBUG - 2015-07-21 19:18:33 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:18:33 --> Final output sent to browser
DEBUG - 2015-07-21 19:18:33 --> Total execution time: 0.0018
DEBUG - 2015-07-21 19:18:48 --> Config Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:18:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:18:48 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:18:48 --> URI Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Router Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Output Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Security Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Input Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:18:48 --> Language Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Loader Class Initialized
DEBUG - 2015-07-21 19:18:48 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:18:48 --> Controller Class Initialized
DEBUG - 2015-07-21 19:18:48 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:18:48 --> Final output sent to browser
DEBUG - 2015-07-21 19:18:48 --> Total execution time: 0.0036
DEBUG - 2015-07-21 19:18:52 --> Config Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:18:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:18:52 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:18:52 --> URI Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Router Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Output Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Security Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Input Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:18:52 --> Language Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Loader Class Initialized
DEBUG - 2015-07-21 19:18:52 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:18:52 --> Controller Class Initialized
DEBUG - 2015-07-21 19:18:52 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:18:52 --> Final output sent to browser
DEBUG - 2015-07-21 19:18:52 --> Total execution time: 0.0032
DEBUG - 2015-07-21 19:19:23 --> Config Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:19:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:19:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:19:23 --> URI Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Router Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Output Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Security Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Input Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:19:23 --> Language Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Loader Class Initialized
DEBUG - 2015-07-21 19:19:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:19:23 --> Controller Class Initialized
DEBUG - 2015-07-21 19:19:23 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:19:23 --> Final output sent to browser
DEBUG - 2015-07-21 19:19:23 --> Total execution time: 0.0032
DEBUG - 2015-07-21 19:19:27 --> Config Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:19:27 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:19:27 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:19:27 --> URI Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Router Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Output Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Security Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Input Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:19:27 --> Language Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Loader Class Initialized
DEBUG - 2015-07-21 19:19:27 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:19:27 --> Controller Class Initialized
DEBUG - 2015-07-21 19:19:27 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:19:27 --> Final output sent to browser
DEBUG - 2015-07-21 19:19:27 --> Total execution time: 0.0019
DEBUG - 2015-07-21 19:19:33 --> Config Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:19:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:19:33 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:19:33 --> URI Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Router Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Output Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Security Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Input Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:19:33 --> Language Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Loader Class Initialized
DEBUG - 2015-07-21 19:19:33 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:19:33 --> Controller Class Initialized
DEBUG - 2015-07-21 19:19:33 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:19:33 --> Final output sent to browser
DEBUG - 2015-07-21 19:19:33 --> Total execution time: 0.0025
DEBUG - 2015-07-21 19:19:37 --> Config Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:19:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:19:37 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:19:37 --> URI Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Router Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Output Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Security Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Input Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:19:37 --> Language Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Loader Class Initialized
DEBUG - 2015-07-21 19:19:37 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:19:37 --> Controller Class Initialized
DEBUG - 2015-07-21 19:19:37 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:19:37 --> Final output sent to browser
DEBUG - 2015-07-21 19:19:37 --> Total execution time: 0.0019
DEBUG - 2015-07-21 19:19:43 --> Config Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:19:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:19:43 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:19:43 --> URI Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Router Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Output Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Security Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Input Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:19:43 --> Language Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Loader Class Initialized
DEBUG - 2015-07-21 19:19:43 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:19:43 --> Controller Class Initialized
DEBUG - 2015-07-21 19:19:43 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:19:43 --> Final output sent to browser
DEBUG - 2015-07-21 19:19:43 --> Total execution time: 0.0030
DEBUG - 2015-07-21 19:20:24 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:24 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:24 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:24 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:24 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:24 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:24 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:24 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:24 --> Total execution time: 0.0034
DEBUG - 2015-07-21 19:20:29 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:29 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:29 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:29 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:29 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:29 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:29 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:29 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:29 --> Total execution time: 0.0020
DEBUG - 2015-07-21 19:20:30 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:30 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:30 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:30 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:30 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:30 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:30 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:30 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:30 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:30 --> Total execution time: 0.0027
DEBUG - 2015-07-21 19:20:31 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:31 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:31 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:31 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:31 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:31 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:31 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:31 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:31 --> Total execution time: 0.0020
DEBUG - 2015-07-21 19:20:32 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:32 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:32 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:32 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:32 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:32 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:32 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:32 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:32 --> Total execution time: 0.0021
DEBUG - 2015-07-21 19:20:33 --> Config Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:20:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:20:33 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:20:33 --> URI Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Router Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Output Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Security Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Input Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:20:33 --> Language Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Loader Class Initialized
DEBUG - 2015-07-21 19:20:33 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:20:33 --> Controller Class Initialized
DEBUG - 2015-07-21 19:20:33 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:20:33 --> Final output sent to browser
DEBUG - 2015-07-21 19:20:33 --> Total execution time: 0.0020
DEBUG - 2015-07-21 19:35:10 --> Config Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:35:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:35:10 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:35:10 --> URI Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Router Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Output Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Security Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Input Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:35:10 --> Language Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Loader Class Initialized
DEBUG - 2015-07-21 19:35:10 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:35:10 --> Controller Class Initialized
DEBUG - 2015-07-21 19:35:10 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:35:10 --> Final output sent to browser
DEBUG - 2015-07-21 19:35:10 --> Total execution time: 0.0039
DEBUG - 2015-07-21 19:35:12 --> Config Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:35:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:35:12 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:35:12 --> URI Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Router Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Output Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Security Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Input Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:35:12 --> Language Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Loader Class Initialized
DEBUG - 2015-07-21 19:35:12 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:35:12 --> Controller Class Initialized
DEBUG - 2015-07-21 19:35:12 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:35:12 --> Final output sent to browser
DEBUG - 2015-07-21 19:35:12 --> Total execution time: 0.0022
DEBUG - 2015-07-21 19:35:13 --> Config Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:35:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:35:13 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:35:13 --> URI Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Router Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Output Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Security Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Input Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:35:13 --> Language Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Loader Class Initialized
DEBUG - 2015-07-21 19:35:13 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:35:13 --> Controller Class Initialized
DEBUG - 2015-07-21 19:35:13 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:35:13 --> Final output sent to browser
DEBUG - 2015-07-21 19:35:13 --> Total execution time: 0.0019
DEBUG - 2015-07-21 19:35:14 --> Config Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:35:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:35:14 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:35:14 --> URI Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Router Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Output Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Security Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Input Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:35:14 --> Language Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Loader Class Initialized
DEBUG - 2015-07-21 19:35:14 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:35:14 --> Controller Class Initialized
DEBUG - 2015-07-21 19:35:14 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:35:14 --> Final output sent to browser
DEBUG - 2015-07-21 19:35:14 --> Total execution time: 0.0022
DEBUG - 2015-07-21 19:36:27 --> Config Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:36:27 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:36:27 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:36:27 --> URI Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Router Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Output Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Security Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Input Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:36:27 --> Language Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Loader Class Initialized
DEBUG - 2015-07-21 19:36:27 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:36:27 --> Controller Class Initialized
DEBUG - 2015-07-21 19:36:27 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:36:27 --> Final output sent to browser
DEBUG - 2015-07-21 19:36:27 --> Total execution time: 0.0035
DEBUG - 2015-07-21 19:36:28 --> Config Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:36:28 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:36:28 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:36:28 --> URI Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Router Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Output Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Security Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Input Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:36:28 --> Language Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Loader Class Initialized
DEBUG - 2015-07-21 19:36:28 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:36:28 --> Controller Class Initialized
DEBUG - 2015-07-21 19:36:28 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:36:28 --> Final output sent to browser
DEBUG - 2015-07-21 19:36:28 --> Total execution time: 0.0026
DEBUG - 2015-07-21 19:36:48 --> Config Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:36:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:36:48 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:36:48 --> URI Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Router Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Output Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Security Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Input Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:36:48 --> Language Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Loader Class Initialized
DEBUG - 2015-07-21 19:36:48 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:36:48 --> Controller Class Initialized
DEBUG - 2015-07-21 19:36:48 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:36:48 --> Final output sent to browser
DEBUG - 2015-07-21 19:36:48 --> Total execution time: 0.0021
DEBUG - 2015-07-21 19:38:19 --> Config Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:38:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:38:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:38:19 --> URI Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Router Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Output Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Security Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Input Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:38:19 --> Language Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Loader Class Initialized
DEBUG - 2015-07-21 19:38:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:38:19 --> Controller Class Initialized
DEBUG - 2015-07-21 19:38:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:38:19 --> Final output sent to browser
DEBUG - 2015-07-21 19:38:19 --> Total execution time: 0.0023
DEBUG - 2015-07-21 19:38:22 --> Config Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:38:22 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:38:22 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:38:22 --> URI Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Router Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Output Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Security Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Input Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:38:22 --> Language Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Loader Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:38:22 --> Controller Class Initialized
DEBUG - 2015-07-21 19:38:22 --> Database Driver Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Config Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:40:51 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:40:51 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:40:51 --> URI Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Router Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Output Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Security Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Input Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:40:51 --> Language Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Loader Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:40:51 --> Controller Class Initialized
DEBUG - 2015-07-21 19:40:51 --> Database Driver Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Config Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:40:56 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:40:56 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:40:56 --> URI Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Router Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Output Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Security Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Input Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:40:56 --> Language Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Loader Class Initialized
DEBUG - 2015-07-21 19:40:56 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:40:56 --> Controller Class Initialized
DEBUG - 2015-07-21 19:40:56 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:40:56 --> Final output sent to browser
DEBUG - 2015-07-21 19:40:56 --> Total execution time: 0.0032
DEBUG - 2015-07-21 19:41:34 --> Config Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:41:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:41:34 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:41:34 --> URI Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Router Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Output Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Security Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Input Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:41:34 --> Language Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Loader Class Initialized
DEBUG - 2015-07-21 19:41:34 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:41:34 --> Controller Class Initialized
DEBUG - 2015-07-21 19:41:34 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:41:34 --> Final output sent to browser
DEBUG - 2015-07-21 19:41:34 --> Total execution time: 0.0036
DEBUG - 2015-07-21 19:42:29 --> Config Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:42:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:42:29 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:42:29 --> URI Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Router Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Output Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Security Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Input Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:42:29 --> Language Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Loader Class Initialized
DEBUG - 2015-07-21 19:42:29 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:42:29 --> Controller Class Initialized
DEBUG - 2015-07-21 19:42:29 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:42:29 --> Final output sent to browser
DEBUG - 2015-07-21 19:42:29 --> Total execution time: 0.0032
DEBUG - 2015-07-21 19:44:02 --> Config Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:44:02 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:44:02 --> URI Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Router Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Output Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Security Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Input Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:44:02 --> Language Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Loader Class Initialized
DEBUG - 2015-07-21 19:44:02 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:44:02 --> Controller Class Initialized
DEBUG - 2015-07-21 19:44:02 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:44:02 --> Final output sent to browser
DEBUG - 2015-07-21 19:44:02 --> Total execution time: 0.0038
DEBUG - 2015-07-21 19:45:13 --> Config Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:45:13 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:45:13 --> URI Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Router Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Output Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Security Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Input Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:45:13 --> Language Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Loader Class Initialized
DEBUG - 2015-07-21 19:45:13 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:45:13 --> Controller Class Initialized
DEBUG - 2015-07-21 19:45:13 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:45:13 --> Final output sent to browser
DEBUG - 2015-07-21 19:45:13 --> Total execution time: 0.0035
DEBUG - 2015-07-21 19:45:55 --> Config Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:45:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:45:55 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:45:55 --> URI Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Router Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Output Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Security Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Input Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:45:55 --> Language Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Loader Class Initialized
DEBUG - 2015-07-21 19:45:55 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:45:55 --> Controller Class Initialized
DEBUG - 2015-07-21 19:45:55 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:45:55 --> Final output sent to browser
DEBUG - 2015-07-21 19:45:55 --> Total execution time: 0.0031
DEBUG - 2015-07-21 19:46:25 --> Config Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:46:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:46:25 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:46:25 --> URI Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Router Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Output Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Security Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Input Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:46:25 --> Language Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Loader Class Initialized
DEBUG - 2015-07-21 19:46:25 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:46:25 --> Controller Class Initialized
DEBUG - 2015-07-21 19:46:25 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:46:25 --> Final output sent to browser
DEBUG - 2015-07-21 19:46:25 --> Total execution time: 0.0019
DEBUG - 2015-07-21 19:47:29 --> Config Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:47:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:47:29 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:47:29 --> URI Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Router Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Output Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Security Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Input Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:47:29 --> Language Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Loader Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:47:29 --> Controller Class Initialized
DEBUG - 2015-07-21 19:47:29 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:47:29 --> Final output sent to browser
DEBUG - 2015-07-21 19:47:29 --> Total execution time: 0.0031
DEBUG - 2015-07-21 19:47:29 --> Config Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:47:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:47:29 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:47:29 --> URI Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Router Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Output Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Security Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Input Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:47:29 --> Language Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Loader Class Initialized
DEBUG - 2015-07-21 19:47:29 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:47:29 --> Controller Class Initialized
DEBUG - 2015-07-21 19:47:29 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:47:29 --> Final output sent to browser
DEBUG - 2015-07-21 19:47:29 --> Total execution time: 0.0028
DEBUG - 2015-07-21 19:48:46 --> Config Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:48:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:48:46 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:48:46 --> URI Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Router Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Output Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Security Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Input Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:48:46 --> Language Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Loader Class Initialized
DEBUG - 2015-07-21 19:48:46 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:48:46 --> Controller Class Initialized
DEBUG - 2015-07-21 19:48:46 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:48:46 --> Final output sent to browser
DEBUG - 2015-07-21 19:48:46 --> Total execution time: 0.0119
DEBUG - 2015-07-21 19:48:47 --> Config Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:48:47 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:48:47 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:48:47 --> URI Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Router Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Output Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Security Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Input Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:48:47 --> Language Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Loader Class Initialized
DEBUG - 2015-07-21 19:48:47 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:48:47 --> Controller Class Initialized
DEBUG - 2015-07-21 19:48:47 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:48:47 --> Final output sent to browser
DEBUG - 2015-07-21 19:48:47 --> Total execution time: 0.0036
DEBUG - 2015-07-21 19:49:20 --> Config Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:49:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:49:20 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:49:20 --> URI Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Router Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Output Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Security Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Input Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:49:20 --> Language Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Loader Class Initialized
DEBUG - 2015-07-21 19:49:20 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:49:20 --> Controller Class Initialized
DEBUG - 2015-07-21 19:49:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:49:20 --> Final output sent to browser
DEBUG - 2015-07-21 19:49:20 --> Total execution time: 0.0032
DEBUG - 2015-07-21 19:49:21 --> Config Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:49:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:49:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:49:21 --> URI Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Router Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Output Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Security Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Input Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:49:21 --> Language Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Loader Class Initialized
DEBUG - 2015-07-21 19:49:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:49:21 --> Controller Class Initialized
DEBUG - 2015-07-21 19:49:21 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:49:21 --> Final output sent to browser
DEBUG - 2015-07-21 19:49:21 --> Total execution time: 0.0060
DEBUG - 2015-07-21 19:49:23 --> Config Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:49:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:49:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:49:23 --> URI Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Router Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Output Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Security Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Input Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:49:23 --> Language Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Loader Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:49:23 --> Controller Class Initialized
DEBUG - 2015-07-21 19:49:23 --> Database Driver Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Config Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:52:20 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:52:20 --> URI Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Router Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Output Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Security Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Input Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:52:20 --> Language Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Loader Class Initialized
DEBUG - 2015-07-21 19:52:20 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:52:20 --> Controller Class Initialized
DEBUG - 2015-07-21 19:52:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:52:20 --> Final output sent to browser
DEBUG - 2015-07-21 19:52:20 --> Total execution time: 0.0039
DEBUG - 2015-07-21 19:52:21 --> Config Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:52:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:52:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:52:21 --> URI Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Router Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Output Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Security Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Input Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:52:21 --> Language Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Loader Class Initialized
DEBUG - 2015-07-21 19:52:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:52:21 --> Controller Class Initialized
DEBUG - 2015-07-21 19:52:21 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 19:52:21 --> Final output sent to browser
DEBUG - 2015-07-21 19:52:21 --> Total execution time: 0.0039
DEBUG - 2015-07-21 19:52:25 --> Config Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Hooks Class Initialized
DEBUG - 2015-07-21 19:52:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 19:52:25 --> Utf8 Class Initialized
DEBUG - 2015-07-21 19:52:25 --> URI Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Router Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Output Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Security Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Input Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 19:52:25 --> Language Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Loader Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Helper loaded: url_helper
DEBUG - 2015-07-21 19:52:25 --> Controller Class Initialized
DEBUG - 2015-07-21 19:52:25 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Config Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:09:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:09:19 --> URI Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Router Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Output Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Security Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Input Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:09:19 --> Language Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Loader Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:09:19 --> Controller Class Initialized
DEBUG - 2015-07-21 20:09:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:09:19 --> Final output sent to browser
DEBUG - 2015-07-21 20:09:19 --> Total execution time: 0.0031
DEBUG - 2015-07-21 20:09:19 --> Config Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:09:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:09:19 --> URI Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Router Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Output Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Security Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Input Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:09:19 --> Language Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Loader Class Initialized
DEBUG - 2015-07-21 20:09:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:09:19 --> Controller Class Initialized
DEBUG - 2015-07-21 20:09:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:09:19 --> Final output sent to browser
DEBUG - 2015-07-21 20:09:19 --> Total execution time: 0.0042
DEBUG - 2015-07-21 20:09:23 --> Config Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:09:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:09:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:09:23 --> URI Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Router Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Output Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Security Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Input Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:09:23 --> Language Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Loader Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:09:23 --> Controller Class Initialized
DEBUG - 2015-07-21 20:09:23 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Config Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:10:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:10:45 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:10:45 --> URI Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Router Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Output Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Security Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Input Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:10:45 --> Language Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Loader Class Initialized
DEBUG - 2015-07-21 20:10:45 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:10:45 --> Controller Class Initialized
DEBUG - 2015-07-21 20:10:45 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:10:45 --> Final output sent to browser
DEBUG - 2015-07-21 20:10:45 --> Total execution time: 0.0020
DEBUG - 2015-07-21 20:10:46 --> Config Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:10:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:10:46 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:10:46 --> URI Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Router Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Output Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Security Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Input Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:10:46 --> Language Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Loader Class Initialized
DEBUG - 2015-07-21 20:10:46 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:10:46 --> Controller Class Initialized
DEBUG - 2015-07-21 20:10:46 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:10:46 --> Final output sent to browser
DEBUG - 2015-07-21 20:10:46 --> Total execution time: 0.0037
DEBUG - 2015-07-21 20:10:53 --> Config Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:10:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:10:53 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:10:53 --> URI Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Router Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Output Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Security Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Input Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:10:53 --> Language Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Loader Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:10:53 --> Controller Class Initialized
DEBUG - 2015-07-21 20:10:53 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Config Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:11:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:11:38 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:11:38 --> URI Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Router Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Output Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Security Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Input Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:11:38 --> Language Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Loader Class Initialized
DEBUG - 2015-07-21 20:11:38 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:11:38 --> Controller Class Initialized
DEBUG - 2015-07-21 20:11:38 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:11:38 --> Final output sent to browser
DEBUG - 2015-07-21 20:11:38 --> Total execution time: 0.0030
DEBUG - 2015-07-21 20:11:39 --> Config Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:11:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:11:39 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:11:39 --> URI Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Router Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Output Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Security Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Input Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:11:39 --> Language Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Loader Class Initialized
DEBUG - 2015-07-21 20:11:39 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:11:39 --> Controller Class Initialized
DEBUG - 2015-07-21 20:11:39 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:11:39 --> Final output sent to browser
DEBUG - 2015-07-21 20:11:39 --> Total execution time: 0.0036
DEBUG - 2015-07-21 20:11:43 --> Config Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:11:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:11:43 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:11:43 --> URI Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Router Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Output Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Security Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Input Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:11:43 --> Language Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Loader Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:11:43 --> Controller Class Initialized
DEBUG - 2015-07-21 20:11:43 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Config Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:40:52 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:40:52 --> URI Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Router Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Output Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Security Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Input Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:40:52 --> Language Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Loader Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:40:52 --> Controller Class Initialized
DEBUG - 2015-07-21 20:40:52 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:40:52 --> Final output sent to browser
DEBUG - 2015-07-21 20:40:52 --> Total execution time: 0.0019
DEBUG - 2015-07-21 20:40:52 --> Config Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:40:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:40:52 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:40:52 --> URI Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Router Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Output Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Security Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Input Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:40:52 --> Language Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Loader Class Initialized
DEBUG - 2015-07-21 20:40:52 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:40:52 --> Controller Class Initialized
DEBUG - 2015-07-21 20:40:52 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:40:52 --> Final output sent to browser
DEBUG - 2015-07-21 20:40:52 --> Total execution time: 0.0026
DEBUG - 2015-07-21 20:40:54 --> Config Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:40:54 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:40:54 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:40:54 --> URI Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Router Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Output Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Security Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Input Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:40:54 --> Language Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Loader Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:40:54 --> Controller Class Initialized
DEBUG - 2015-07-21 20:40:54 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:12 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:12 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:12 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:12 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:12 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:44:12 --> Final output sent to browser
DEBUG - 2015-07-21 20:44:12 --> Total execution time: 0.0019
DEBUG - 2015-07-21 20:44:12 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:12 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:12 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:12 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:12 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:12 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:12 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:44:12 --> Final output sent to browser
DEBUG - 2015-07-21 20:44:12 --> Total execution time: 0.0035
DEBUG - 2015-07-21 20:44:15 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:15 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:15 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:15 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:15 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:15 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:44:15 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:44:15 --> A session cookie was not found.
DEBUG - 2015-07-21 20:44:15 --> Session: Creating new session (575c67f0c7e33b76b3ecb188f2849592)
DEBUG - 2015-07-21 20:44:15 --> CI_Session routines successfully run
ERROR - 2015-07-21 20:44:15 --> Query error: Table 'AdwordsExamenes.users_session' doesn't exist - Invalid query: SELECT `session_id`
FROM `users_session`
WHERE `session_id` = '575c67f0c7e33b76b3ecb188f2849592'
DEBUG - 2015-07-21 20:44:41 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:41 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:41 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:41 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:41 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:41 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:41 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:44:41 --> Final output sent to browser
DEBUG - 2015-07-21 20:44:41 --> Total execution time: 0.0033
DEBUG - 2015-07-21 20:44:42 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:42 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:42 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:42 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:42 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:42 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:42 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:42 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:44:42 --> Final output sent to browser
DEBUG - 2015-07-21 20:44:42 --> Total execution time: 0.0031
DEBUG - 2015-07-21 20:44:43 --> Config Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:44:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:44:43 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:44:43 --> URI Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Router Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Output Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Security Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Input Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:44:43 --> Language Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Loader Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:44:43 --> Controller Class Initialized
DEBUG - 2015-07-21 20:44:43 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:44:43 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:44:43 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:45:20 --> Config Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:45:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:45:20 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:45:20 --> URI Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Router Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Output Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Security Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Input Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:45:20 --> Language Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Loader Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:45:20 --> Controller Class Initialized
DEBUG - 2015-07-21 20:45:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:45:20 --> Final output sent to browser
DEBUG - 2015-07-21 20:45:20 --> Total execution time: 0.0032
DEBUG - 2015-07-21 20:45:20 --> Config Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:45:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:45:20 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:45:20 --> URI Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Router Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Output Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Security Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Input Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:45:20 --> Language Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Loader Class Initialized
DEBUG - 2015-07-21 20:45:20 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:45:20 --> Controller Class Initialized
DEBUG - 2015-07-21 20:45:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:45:20 --> Final output sent to browser
DEBUG - 2015-07-21 20:45:20 --> Total execution time: 0.0054
DEBUG - 2015-07-21 20:45:22 --> Config Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:45:22 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:45:22 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:45:22 --> URI Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Router Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Output Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Security Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Input Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:45:22 --> Language Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Loader Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:45:22 --> Controller Class Initialized
DEBUG - 2015-07-21 20:45:22 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:45:22 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:45:22 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:46:31 --> Config Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:46:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:46:31 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:46:31 --> URI Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Router Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Output Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Security Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Input Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:46:31 --> Language Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Loader Class Initialized
DEBUG - 2015-07-21 20:46:31 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:46:31 --> Controller Class Initialized
DEBUG - 2015-07-21 20:46:31 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:46:31 --> Final output sent to browser
DEBUG - 2015-07-21 20:46:31 --> Total execution time: 0.0031
DEBUG - 2015-07-21 20:46:32 --> Config Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:46:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:46:32 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:46:32 --> URI Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Router Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Output Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Security Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Input Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:46:32 --> Language Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Loader Class Initialized
DEBUG - 2015-07-21 20:46:32 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:46:32 --> Controller Class Initialized
DEBUG - 2015-07-21 20:46:32 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:46:32 --> Final output sent to browser
DEBUG - 2015-07-21 20:46:32 --> Total execution time: 0.0043
DEBUG - 2015-07-21 20:46:34 --> Config Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:46:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:46:34 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:46:34 --> URI Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Router Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Output Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Security Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Input Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:46:34 --> Language Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Loader Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:46:34 --> Controller Class Initialized
DEBUG - 2015-07-21 20:46:34 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:46:34 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:46:34 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:50:25 --> Config Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:50:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:50:25 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:50:25 --> URI Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Router Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Output Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Security Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Input Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:50:25 --> Language Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Loader Class Initialized
DEBUG - 2015-07-21 20:50:25 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:50:25 --> Controller Class Initialized
DEBUG - 2015-07-21 20:50:25 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:50:25 --> Final output sent to browser
DEBUG - 2015-07-21 20:50:25 --> Total execution time: 0.0034
DEBUG - 2015-07-21 20:50:26 --> Config Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:50:26 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:50:26 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:50:26 --> URI Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Router Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Output Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Security Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Input Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:50:26 --> Language Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Loader Class Initialized
DEBUG - 2015-07-21 20:50:26 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:50:26 --> Controller Class Initialized
DEBUG - 2015-07-21 20:50:26 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:50:26 --> Final output sent to browser
DEBUG - 2015-07-21 20:50:26 --> Total execution time: 0.0042
DEBUG - 2015-07-21 20:51:23 --> Config Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:51:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:51:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:51:23 --> URI Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Router Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Output Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Security Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Input Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:51:23 --> Language Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Loader Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:51:23 --> Controller Class Initialized
DEBUG - 2015-07-21 20:51:23 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:51:23 --> Final output sent to browser
DEBUG - 2015-07-21 20:51:23 --> Total execution time: 0.0037
DEBUG - 2015-07-21 20:51:23 --> Config Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:51:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:51:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:51:23 --> URI Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Router Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Output Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Security Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Input Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:51:23 --> Language Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Loader Class Initialized
DEBUG - 2015-07-21 20:51:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:51:23 --> Controller Class Initialized
DEBUG - 2015-07-21 20:51:23 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:51:23 --> Final output sent to browser
DEBUG - 2015-07-21 20:51:23 --> Total execution time: 0.0049
DEBUG - 2015-07-21 20:51:24 --> Config Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:51:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:51:24 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:51:24 --> URI Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Router Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Output Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Security Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Input Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:51:24 --> Language Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Loader Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:51:24 --> Controller Class Initialized
DEBUG - 2015-07-21 20:51:24 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:51:24 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:51:24 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:51:35 --> Config Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:51:35 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:51:35 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:51:35 --> URI Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Router Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Output Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Security Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Input Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:51:35 --> Language Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Loader Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:51:35 --> Controller Class Initialized
DEBUG - 2015-07-21 20:51:35 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:51:35 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:51:35 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:51:37 --> Config Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:51:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:51:37 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:51:37 --> URI Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Router Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Output Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Security Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Input Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:51:37 --> Language Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Loader Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:51:37 --> Controller Class Initialized
DEBUG - 2015-07-21 20:51:37 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:51:37 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:51:37 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:54:21 --> Config Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:54:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:54:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:54:21 --> URI Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Router Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Output Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Security Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Input Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:54:21 --> Language Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Loader Class Initialized
DEBUG - 2015-07-21 20:54:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:54:21 --> Controller Class Initialized
DEBUG - 2015-07-21 20:54:21 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:54:21 --> Final output sent to browser
DEBUG - 2015-07-21 20:54:21 --> Total execution time: 0.0031
DEBUG - 2015-07-21 20:54:22 --> Config Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:54:22 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:54:22 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:54:22 --> URI Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Router Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Output Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Security Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Input Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:54:22 --> Language Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Loader Class Initialized
DEBUG - 2015-07-21 20:54:22 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:54:22 --> Controller Class Initialized
DEBUG - 2015-07-21 20:54:22 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:54:22 --> Final output sent to browser
DEBUG - 2015-07-21 20:54:22 --> Total execution time: 0.0029
DEBUG - 2015-07-21 20:54:23 --> Config Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:54:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:54:23 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:54:23 --> URI Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Router Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Output Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Security Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Input Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:54:23 --> Language Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Loader Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:54:23 --> Controller Class Initialized
DEBUG - 2015-07-21 20:54:23 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:54:23 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:54:23 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:55:19 --> Config Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:55:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:55:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:55:19 --> URI Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Router Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Output Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Security Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Input Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:55:19 --> Language Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Loader Class Initialized
DEBUG - 2015-07-21 20:55:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:55:19 --> Controller Class Initialized
DEBUG - 2015-07-21 20:55:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:55:19 --> Final output sent to browser
DEBUG - 2015-07-21 20:55:19 --> Total execution time: 0.0273
DEBUG - 2015-07-21 20:55:20 --> Config Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:55:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:55:20 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:55:20 --> URI Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Router Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Output Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Security Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Input Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:55:20 --> Language Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Loader Class Initialized
DEBUG - 2015-07-21 20:55:20 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:55:20 --> Controller Class Initialized
DEBUG - 2015-07-21 20:55:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:55:20 --> Final output sent to browser
DEBUG - 2015-07-21 20:55:20 --> Total execution time: 0.0054
DEBUG - 2015-07-21 20:55:21 --> Config Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:55:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:55:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:55:21 --> URI Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Router Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Output Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Security Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Input Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:55:21 --> Language Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Loader Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:55:21 --> Controller Class Initialized
DEBUG - 2015-07-21 20:55:21 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:55:22 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:55:22 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:55:49 --> Config Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:55:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:55:49 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:55:49 --> URI Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Router Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Output Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Security Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Input Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:55:49 --> Language Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Loader Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:55:49 --> Controller Class Initialized
DEBUG - 2015-07-21 20:55:49 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:55:49 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:55:49 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:57:33 --> Config Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:57:33 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:57:33 --> URI Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Router Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Output Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Security Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Input Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:57:33 --> Language Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Loader Class Initialized
DEBUG - 2015-07-21 20:57:33 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:57:33 --> Controller Class Initialized
DEBUG - 2015-07-21 20:57:33 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:57:33 --> Final output sent to browser
DEBUG - 2015-07-21 20:57:33 --> Total execution time: 0.0035
DEBUG - 2015-07-21 20:57:34 --> Config Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:57:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:57:34 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:57:34 --> URI Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Router Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Output Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Security Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Input Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:57:34 --> Language Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Loader Class Initialized
DEBUG - 2015-07-21 20:57:34 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:57:34 --> Controller Class Initialized
DEBUG - 2015-07-21 20:57:34 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 20:57:34 --> Final output sent to browser
DEBUG - 2015-07-21 20:57:34 --> Total execution time: 0.0032
DEBUG - 2015-07-21 20:57:41 --> Config Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:57:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:57:41 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:57:41 --> URI Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Router Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Output Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Security Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Input Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:57:41 --> Language Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Loader Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:57:41 --> Controller Class Initialized
DEBUG - 2015-07-21 20:57:41 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:57:41 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:57:41 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:58:01 --> Config Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:58:01 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:58:01 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:58:01 --> URI Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Router Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Output Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Security Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Input Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:58:01 --> Language Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Loader Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:58:01 --> Controller Class Initialized
DEBUG - 2015-07-21 20:58:01 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:58:01 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:58:01 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:58:07 --> Config Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:58:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:58:07 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:58:07 --> URI Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Router Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Output Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Security Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Input Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:58:07 --> Language Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Loader Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:58:07 --> Controller Class Initialized
DEBUG - 2015-07-21 20:58:07 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:58:07 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:58:07 --> CI_Session routines successfully run
DEBUG - 2015-07-21 20:58:09 --> Config Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Hooks Class Initialized
DEBUG - 2015-07-21 20:58:09 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 20:58:09 --> Utf8 Class Initialized
DEBUG - 2015-07-21 20:58:09 --> URI Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Router Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Output Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Security Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Input Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 20:58:09 --> Language Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Loader Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Helper loaded: url_helper
DEBUG - 2015-07-21 20:58:09 --> Controller Class Initialized
DEBUG - 2015-07-21 20:58:09 --> Database Driver Class Initialized
DEBUG - 2015-07-21 20:58:09 --> CI_Session Class Initialized
DEBUG - 2015-07-21 20:58:09 --> CI_Session routines successfully run
DEBUG - 2015-07-21 21:04:01 --> Config Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:04:01 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:04:01 --> URI Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Router Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Output Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Security Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Input Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:04:01 --> Language Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Loader Class Initialized
DEBUG - 2015-07-21 21:04:01 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:04:01 --> Controller Class Initialized
DEBUG - 2015-07-21 21:04:01 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 21:04:01 --> Final output sent to browser
DEBUG - 2015-07-21 21:04:01 --> Total execution time: 0.0023
DEBUG - 2015-07-21 21:04:02 --> Config Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:04:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:04:02 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:04:02 --> URI Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Router Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Output Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Security Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Input Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:04:02 --> Language Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Loader Class Initialized
DEBUG - 2015-07-21 21:04:02 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:04:02 --> Controller Class Initialized
DEBUG - 2015-07-21 21:04:02 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 21:04:02 --> Final output sent to browser
DEBUG - 2015-07-21 21:04:02 --> Total execution time: 0.0025
DEBUG - 2015-07-21 21:04:07 --> Config Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:04:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:04:07 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:04:07 --> URI Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Router Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Output Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Security Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Input Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:04:07 --> Language Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Loader Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:04:07 --> Controller Class Initialized
DEBUG - 2015-07-21 21:04:07 --> Database Driver Class Initialized
DEBUG - 2015-07-21 21:04:07 --> CI_Session Class Initialized
DEBUG - 2015-07-21 21:04:07 --> CI_Session routines successfully run
DEBUG - 2015-07-21 21:04:12 --> Config Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:04:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:04:12 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:04:12 --> URI Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Router Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Output Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Security Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Input Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:04:12 --> Language Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Loader Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:04:12 --> Controller Class Initialized
DEBUG - 2015-07-21 21:04:12 --> Database Driver Class Initialized
DEBUG - 2015-07-21 21:04:12 --> CI_Session Class Initialized
DEBUG - 2015-07-21 21:04:12 --> CI_Session routines successfully run
DEBUG - 2015-07-21 21:06:25 --> Config Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:06:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:06:25 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:06:25 --> URI Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Router Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Output Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Security Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Input Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:06:25 --> Language Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Loader Class Initialized
DEBUG - 2015-07-21 21:06:25 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:06:25 --> Controller Class Initialized
DEBUG - 2015-07-21 21:06:25 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 21:06:25 --> Final output sent to browser
DEBUG - 2015-07-21 21:06:25 --> Total execution time: 0.0036
DEBUG - 2015-07-21 21:08:19 --> Config Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:08:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:08:19 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:08:19 --> URI Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Router Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Output Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Security Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Input Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:08:19 --> Language Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Loader Class Initialized
DEBUG - 2015-07-21 21:08:19 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:08:19 --> Controller Class Initialized
DEBUG - 2015-07-21 21:08:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-21 21:08:19 --> Final output sent to browser
DEBUG - 2015-07-21 21:08:19 --> Total execution time: 0.0035
DEBUG - 2015-07-21 21:08:21 --> Config Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Hooks Class Initialized
DEBUG - 2015-07-21 21:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-21 21:08:21 --> Utf8 Class Initialized
DEBUG - 2015-07-21 21:08:21 --> URI Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Router Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Output Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Security Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Input Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-21 21:08:21 --> Language Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Loader Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Helper loaded: url_helper
DEBUG - 2015-07-21 21:08:21 --> Controller Class Initialized
DEBUG - 2015-07-21 21:08:21 --> Database Driver Class Initialized
DEBUG - 2015-07-21 21:08:21 --> CI_Session Class Initialized
DEBUG - 2015-07-21 21:08:21 --> CI_Session routines successfully run
