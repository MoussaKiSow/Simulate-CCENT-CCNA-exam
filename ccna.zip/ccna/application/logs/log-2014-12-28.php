<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2014-12-28 21:58:25 --> Config Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Hooks Class Initialized
DEBUG - 2014-12-28 21:58:25 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 21:58:25 --> Utf8 Class Initialized
DEBUG - 2014-12-28 21:58:25 --> URI Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Router Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Output Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Security Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Input Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 21:58:25 --> Language Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Loader Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Helper loaded: url_helper
DEBUG - 2014-12-28 21:58:25 --> Controller Class Initialized
DEBUG - 2014-12-28 21:58:25 --> Database Driver Class Initialized
DEBUG - 2014-12-28 21:58:25 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 21:58:25 --> Final output sent to browser
DEBUG - 2014-12-28 21:58:25 --> Total execution time: 0.0065
DEBUG - 2014-12-28 21:58:31 --> Config Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Hooks Class Initialized
DEBUG - 2014-12-28 21:58:31 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 21:58:31 --> Utf8 Class Initialized
DEBUG - 2014-12-28 21:58:31 --> URI Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Router Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Output Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Security Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Input Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 21:58:31 --> Language Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Loader Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Helper loaded: url_helper
DEBUG - 2014-12-28 21:58:31 --> Controller Class Initialized
DEBUG - 2014-12-28 21:58:31 --> Database Driver Class Initialized
DEBUG - 2014-12-28 21:58:31 --> CI_Session Class Initialized
DEBUG - 2014-12-28 21:58:31 --> CI_Session routines successfully run
DEBUG - 2014-12-28 21:58:56 --> Config Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Hooks Class Initialized
DEBUG - 2014-12-28 21:58:56 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 21:58:56 --> Utf8 Class Initialized
DEBUG - 2014-12-28 21:58:56 --> URI Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Router Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Output Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Security Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Input Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 21:58:56 --> Language Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Loader Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Helper loaded: url_helper
DEBUG - 2014-12-28 21:58:56 --> Controller Class Initialized
DEBUG - 2014-12-28 21:58:56 --> Database Driver Class Initialized
DEBUG - 2014-12-28 21:58:56 --> CI_Session Class Initialized
DEBUG - 2014-12-28 21:58:56 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:15:11 --> Config Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:15:11 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:15:11 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:15:11 --> URI Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Router Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Output Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Security Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Input Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:15:11 --> Language Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Loader Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:15:11 --> Controller Class Initialized
DEBUG - 2014-12-28 22:15:11 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:15:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:15:11 --> Final output sent to browser
DEBUG - 2014-12-28 22:15:11 --> Total execution time: 0.0106
DEBUG - 2014-12-28 22:15:26 --> Config Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:15:26 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:15:26 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:15:26 --> URI Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Router Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Output Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Security Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Input Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:15:26 --> Language Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Loader Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:15:26 --> Controller Class Initialized
DEBUG - 2014-12-28 22:15:26 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:15:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:15:26 --> Final output sent to browser
DEBUG - 2014-12-28 22:15:26 --> Total execution time: 0.0105
DEBUG - 2014-12-28 22:15:58 --> Config Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:15:58 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:15:58 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:15:58 --> URI Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Router Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Output Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Security Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Input Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:15:58 --> Language Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Loader Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:15:58 --> Controller Class Initialized
DEBUG - 2014-12-28 22:15:58 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:15:58 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:15:58 --> Final output sent to browser
DEBUG - 2014-12-28 22:15:58 --> Total execution time: 0.0152
DEBUG - 2014-12-28 22:16:34 --> Config Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:16:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:16:34 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:16:34 --> URI Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Router Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Output Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Security Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Input Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:16:34 --> Language Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Loader Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:16:34 --> Controller Class Initialized
DEBUG - 2014-12-28 22:16:34 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:16:34 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:16:34 --> Final output sent to browser
DEBUG - 2014-12-28 22:16:34 --> Total execution time: 0.0138
DEBUG - 2014-12-28 22:16:40 --> Config Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:16:40 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:16:40 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:16:40 --> URI Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Router Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Output Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Security Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Input Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:16:40 --> Language Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Loader Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:16:40 --> Controller Class Initialized
DEBUG - 2014-12-28 22:16:40 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:16:40 --> CI_Session Class Initialized
DEBUG - 2014-12-28 22:16:40 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:17:29 --> Config Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:17:29 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:17:29 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:17:29 --> URI Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Router Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Output Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Security Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Input Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:17:29 --> Language Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Loader Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:17:29 --> Controller Class Initialized
DEBUG - 2014-12-28 22:17:29 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:17:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:17:29 --> Final output sent to browser
DEBUG - 2014-12-28 22:17:29 --> Total execution time: 0.0097
DEBUG - 2014-12-28 22:17:34 --> Config Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:17:34 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:17:34 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:17:34 --> URI Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Router Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Output Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Security Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Input Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:17:34 --> Language Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Loader Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:17:34 --> Controller Class Initialized
DEBUG - 2014-12-28 22:17:34 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:17:34 --> CI_Session Class Initialized
DEBUG - 2014-12-28 22:17:34 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:39:11 --> Config Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:39:11 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:39:11 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:39:11 --> URI Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Router Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Output Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Security Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Input Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:39:11 --> Language Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Loader Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:39:11 --> Controller Class Initialized
DEBUG - 2014-12-28 22:39:11 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:39:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2014-12-28 22:39:11 --> Final output sent to browser
DEBUG - 2014-12-28 22:39:11 --> Total execution time: 0.0053
DEBUG - 2014-12-28 22:39:16 --> Config Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:39:16 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:39:16 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:39:16 --> URI Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Router Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Output Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Security Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Input Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:39:16 --> Language Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Loader Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:39:16 --> Controller Class Initialized
DEBUG - 2014-12-28 22:39:16 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:39:16 --> CI_Session Class Initialized
DEBUG - 2014-12-28 22:39:16 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:39:24 --> Config Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:39:24 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:39:24 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:39:24 --> URI Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Router Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Output Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Security Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Input Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:39:24 --> Language Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Loader Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:39:24 --> Controller Class Initialized
DEBUG - 2014-12-28 22:39:24 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:39:24 --> CI_Session Class Initialized
DEBUG - 2014-12-28 22:39:24 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:59:27 --> Config Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Hooks Class Initialized
DEBUG - 2014-12-28 22:59:27 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 22:59:27 --> Utf8 Class Initialized
DEBUG - 2014-12-28 22:59:27 --> URI Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Router Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Output Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Security Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Input Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 22:59:27 --> Language Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Loader Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Helper loaded: url_helper
DEBUG - 2014-12-28 22:59:27 --> Controller Class Initialized
DEBUG - 2014-12-28 22:59:27 --> Database Driver Class Initialized
DEBUG - 2014-12-28 22:59:27 --> CI_Session Class Initialized
DEBUG - 2014-12-28 22:59:27 --> CI_Session routines successfully run
DEBUG - 2014-12-28 22:59:27 --> Final output sent to browser
DEBUG - 2014-12-28 22:59:27 --> Total execution time: 0.0178
DEBUG - 2014-12-28 23:01:33 --> Config Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Hooks Class Initialized
DEBUG - 2014-12-28 23:01:33 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 23:01:33 --> Utf8 Class Initialized
DEBUG - 2014-12-28 23:01:33 --> URI Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Router Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Output Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Security Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Input Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 23:01:33 --> Language Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Loader Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Helper loaded: url_helper
DEBUG - 2014-12-28 23:01:33 --> Controller Class Initialized
DEBUG - 2014-12-28 23:01:33 --> Database Driver Class Initialized
DEBUG - 2014-12-28 23:01:33 --> CI_Session Class Initialized
DEBUG - 2014-12-28 23:01:33 --> CI_Session routines successfully run
DEBUG - 2014-12-28 23:14:36 --> Config Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Hooks Class Initialized
DEBUG - 2014-12-28 23:14:36 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 23:14:36 --> Utf8 Class Initialized
DEBUG - 2014-12-28 23:14:36 --> URI Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Router Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Output Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Security Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Input Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 23:14:36 --> Language Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Loader Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Helper loaded: url_helper
DEBUG - 2014-12-28 23:14:36 --> Controller Class Initialized
DEBUG - 2014-12-28 23:14:36 --> Database Driver Class Initialized
DEBUG - 2014-12-28 23:14:36 --> CI_Session Class Initialized
DEBUG - 2014-12-28 23:14:36 --> CI_Session routines successfully run
DEBUG - 2014-12-28 23:14:36 --> Final output sent to browser
DEBUG - 2014-12-28 23:14:36 --> Total execution time: 0.0137
DEBUG - 2014-12-28 23:27:13 --> Config Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Hooks Class Initialized
DEBUG - 2014-12-28 23:27:13 --> UTF-8 Support Enabled
DEBUG - 2014-12-28 23:27:13 --> Utf8 Class Initialized
DEBUG - 2014-12-28 23:27:13 --> URI Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Router Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Output Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Security Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Input Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2014-12-28 23:27:13 --> Language Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Loader Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Helper loaded: url_helper
DEBUG - 2014-12-28 23:27:13 --> Controller Class Initialized
DEBUG - 2014-12-28 23:27:13 --> Database Driver Class Initialized
DEBUG - 2014-12-28 23:27:13 --> CI_Session Class Initialized
DEBUG - 2014-12-28 23:27:13 --> CI_Session routines successfully run
DEBUG - 2014-12-28 23:27:13 --> Final output sent to browser
DEBUG - 2014-12-28 23:27:13 --> Total execution time: 0.0098
