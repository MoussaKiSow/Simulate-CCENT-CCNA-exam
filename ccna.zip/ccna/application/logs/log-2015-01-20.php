<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-20 12:55:45 --> Config Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Hooks Class Initialized
DEBUG - 2015-01-20 12:55:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 12:55:45 --> Utf8 Class Initialized
DEBUG - 2015-01-20 12:55:45 --> URI Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Router Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Output Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Security Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Input Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 12:55:45 --> Language Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Loader Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Helper loaded: url_helper
DEBUG - 2015-01-20 12:55:45 --> Controller Class Initialized
DEBUG - 2015-01-20 12:55:45 --> Database Driver Class Initialized
DEBUG - 2015-01-20 12:55:45 --> CI_Session Class Initialized
DEBUG - 2015-01-20 12:55:45 --> A session cookie was not found.
DEBUG - 2015-01-20 12:55:45 --> Session: Creating new session (374f082e973489503682a200d665e3c5)
DEBUG - 2015-01-20 12:55:45 --> CI_Session routines successfully run
DEBUG - 2015-01-20 12:55:45 --> Final output sent to browser
DEBUG - 2015-01-20 12:55:45 --> Total execution time: 0.3051
DEBUG - 2015-01-20 13:24:14 --> Config Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:24:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:24:14 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:24:14 --> URI Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Router Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Output Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Security Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Input Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:24:14 --> Language Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Loader Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:24:14 --> Controller Class Initialized
DEBUG - 2015-01-20 13:24:14 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:24:14 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:24:14 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:24:14 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Config Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:24:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:24:49 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:24:49 --> URI Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Router Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Output Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Security Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Input Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:24:49 --> Language Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Loader Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:24:49 --> Controller Class Initialized
DEBUG - 2015-01-20 13:24:49 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:24:49 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:24:49 --> Final output sent to browser
DEBUG - 2015-01-20 13:24:49 --> Total execution time: 0.0162
DEBUG - 2015-01-20 13:24:51 --> Config Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:24:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:24:51 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:24:51 --> URI Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Router Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Output Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Security Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Input Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:24:51 --> Language Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Loader Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:24:51 --> Controller Class Initialized
DEBUG - 2015-01-20 13:24:51 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:24:51 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:24:51 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:24:51 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Config Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:25:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:25:14 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:25:14 --> URI Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Router Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Output Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Security Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Input Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:25:14 --> Language Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Loader Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:25:14 --> Controller Class Initialized
DEBUG - 2015-01-20 13:25:14 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:25:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:25:14 --> Final output sent to browser
DEBUG - 2015-01-20 13:25:14 --> Total execution time: 0.0125
DEBUG - 2015-01-20 13:25:16 --> Config Class Initialized
DEBUG - 2015-01-20 13:25:16 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:25:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:25:16 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:25:16 --> URI Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Router Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Output Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Security Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Input Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:25:17 --> Language Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Loader Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:25:17 --> Controller Class Initialized
DEBUG - 2015-01-20 13:25:17 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:25:17 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:25:17 --> A session cookie was not found.
DEBUG - 2015-01-20 13:25:17 --> Session: Creating new session (83ca628d6c034909599c1b1d0c2b90a3)
DEBUG - 2015-01-20 13:25:17 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:25:17 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Config Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:25:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:25:31 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:25:31 --> URI Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Router Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Output Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Security Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Input Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:25:31 --> Language Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Loader Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:25:31 --> Controller Class Initialized
DEBUG - 2015-01-20 13:25:31 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:25:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:25:31 --> Final output sent to browser
DEBUG - 2015-01-20 13:25:31 --> Total execution time: 0.0152
DEBUG - 2015-01-20 13:25:37 --> Config Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:25:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:25:37 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:25:37 --> URI Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Router Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Output Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Security Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Input Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:25:37 --> Language Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Loader Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:25:37 --> Controller Class Initialized
DEBUG - 2015-01-20 13:25:37 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:25:37 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:25:37 --> A session cookie was not found.
DEBUG - 2015-01-20 13:25:37 --> Session: Creating new session (96adddad2eeb127ffced97e4d0faea3b)
DEBUG - 2015-01-20 13:25:37 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:25:37 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Config Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:28:58 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:28:58 --> URI Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Router Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Output Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Security Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Input Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:28:58 --> Language Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Loader Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:28:58 --> Controller Class Initialized
DEBUG - 2015-01-20 13:28:58 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:28:58 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:28:58 --> Final output sent to browser
DEBUG - 2015-01-20 13:28:58 --> Total execution time: 0.0142
DEBUG - 2015-01-20 13:29:00 --> Config Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:29:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:29:00 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:29:00 --> URI Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Router Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Output Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Security Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Input Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:29:00 --> Language Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Loader Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:29:00 --> Controller Class Initialized
DEBUG - 2015-01-20 13:29:00 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:29:00 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:29:00 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:29:00 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Config Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:29:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:29:08 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:29:08 --> URI Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Router Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Output Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Security Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Input Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:29:08 --> Language Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Loader Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:29:08 --> Controller Class Initialized
DEBUG - 2015-01-20 13:29:08 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:29:08 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:29:08 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:29:08 --> Final output sent to browser
DEBUG - 2015-01-20 13:29:08 --> Total execution time: 0.0157
DEBUG - 2015-01-20 13:29:17 --> Config Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:29:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:29:17 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:29:17 --> URI Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Router Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Output Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Security Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Input Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:29:17 --> Language Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Loader Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:29:17 --> Controller Class Initialized
DEBUG - 2015-01-20 13:29:17 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:29:17 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:29:17 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:29:17 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Config Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:31:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:31:33 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:31:33 --> URI Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Router Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Output Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Security Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Input Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:31:33 --> Language Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Loader Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:31:33 --> Controller Class Initialized
DEBUG - 2015-01-20 13:31:33 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:31:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:31:33 --> Final output sent to browser
DEBUG - 2015-01-20 13:31:33 --> Total execution time: 0.0162
DEBUG - 2015-01-20 13:31:36 --> Config Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:31:36 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:31:36 --> URI Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Router Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Output Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Security Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Input Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:31:36 --> Language Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Loader Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:31:36 --> Controller Class Initialized
DEBUG - 2015-01-20 13:31:36 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:31:36 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:31:36 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:31:36 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Config Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:31:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:31:44 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:31:44 --> URI Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Router Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Output Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Security Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Input Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:31:44 --> Language Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Loader Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:31:44 --> Controller Class Initialized
DEBUG - 2015-01-20 13:31:44 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:31:44 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:31:44 --> Final output sent to browser
DEBUG - 2015-01-20 13:31:44 --> Total execution time: 0.0047
DEBUG - 2015-01-20 13:31:46 --> Config Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:31:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:31:46 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:31:46 --> URI Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Router Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Output Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Security Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Input Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:31:46 --> Language Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Loader Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:31:46 --> Controller Class Initialized
DEBUG - 2015-01-20 13:31:46 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:31:46 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:31:46 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:31:46 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Config Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:32:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:32:06 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:32:06 --> URI Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Router Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Output Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Security Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Input Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:32:06 --> Language Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Loader Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:32:06 --> Controller Class Initialized
DEBUG - 2015-01-20 13:32:06 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:32:06 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:32:06 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:32:06 --> Final output sent to browser
DEBUG - 2015-01-20 13:32:06 --> Total execution time: 0.0142
DEBUG - 2015-01-20 13:32:08 --> Config Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:32:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:32:08 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:32:08 --> URI Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Router Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Output Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Security Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Input Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:32:08 --> Language Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Loader Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:32:08 --> Controller Class Initialized
DEBUG - 2015-01-20 13:32:08 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:32:08 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:32:08 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:32:08 --> Final output sent to browser
DEBUG - 2015-01-20 13:32:08 --> Total execution time: 0.0061
DEBUG - 2015-01-20 13:32:11 --> Config Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:32:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:32:11 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:32:11 --> URI Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Router Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Output Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Security Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Input Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:32:11 --> Language Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Loader Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:32:11 --> Controller Class Initialized
DEBUG - 2015-01-20 13:32:11 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:32:11 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:32:11 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:32:11 --> Final output sent to browser
DEBUG - 2015-01-20 13:32:11 --> Total execution time: 0.0097
DEBUG - 2015-01-20 13:32:14 --> Config Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:32:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:32:14 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:32:14 --> URI Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Router Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Output Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Security Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Input Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:32:14 --> Language Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Loader Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:32:14 --> Controller Class Initialized
DEBUG - 2015-01-20 13:32:14 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:32:14 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:32:14 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:32:14 --> Final output sent to browser
DEBUG - 2015-01-20 13:32:14 --> Total execution time: 0.0069
DEBUG - 2015-01-20 13:32:20 --> Config Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:32:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:32:20 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:32:20 --> URI Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Router Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Output Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Security Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Input Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:32:20 --> Language Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Loader Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:32:20 --> Controller Class Initialized
DEBUG - 2015-01-20 13:32:20 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:32:20 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:32:20 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:32:20 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Config Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:33:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:33:26 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:33:26 --> URI Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Router Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Output Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Security Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Input Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:33:26 --> Language Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Loader Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:33:26 --> Controller Class Initialized
DEBUG - 2015-01-20 13:33:26 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:33:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:33:26 --> Final output sent to browser
DEBUG - 2015-01-20 13:33:26 --> Total execution time: 0.0078
DEBUG - 2015-01-20 13:33:28 --> Config Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:33:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:33:28 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:33:28 --> URI Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Router Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Output Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Security Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Input Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:33:28 --> Language Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Loader Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:33:28 --> Controller Class Initialized
DEBUG - 2015-01-20 13:33:28 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:33:28 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:33:28 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:33:28 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Config Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:34:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:34:27 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:34:27 --> URI Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Router Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Output Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Security Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Input Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:34:27 --> Language Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Loader Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:34:27 --> Controller Class Initialized
DEBUG - 2015-01-20 13:34:27 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:34:27 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:34:27 --> Final output sent to browser
DEBUG - 2015-01-20 13:34:27 --> Total execution time: 0.0101
DEBUG - 2015-01-20 13:34:29 --> Config Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:34:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:34:29 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:34:29 --> URI Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Router Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Output Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Security Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Input Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:34:29 --> Language Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Loader Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:34:29 --> Controller Class Initialized
DEBUG - 2015-01-20 13:34:29 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:34:29 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:34:29 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:34:29 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Config Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:34:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:34:59 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:34:59 --> URI Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Router Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Output Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Security Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Input Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:34:59 --> Language Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Loader Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:34:59 --> Controller Class Initialized
DEBUG - 2015-01-20 13:34:59 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:34:59 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:34:59 --> Final output sent to browser
DEBUG - 2015-01-20 13:34:59 --> Total execution time: 0.0157
DEBUG - 2015-01-20 13:35:01 --> Config Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:35:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:35:01 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:35:01 --> URI Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Router Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Output Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Security Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Input Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:35:01 --> Language Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Loader Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:35:01 --> Controller Class Initialized
DEBUG - 2015-01-20 13:35:01 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:35:01 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:35:01 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:35:01 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Config Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:35:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:35:21 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:35:21 --> URI Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Router Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Output Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Security Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Input Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:35:21 --> Language Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Loader Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:35:21 --> Controller Class Initialized
DEBUG - 2015-01-20 13:35:21 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:35:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:35:21 --> Final output sent to browser
DEBUG - 2015-01-20 13:35:21 --> Total execution time: 0.0135
DEBUG - 2015-01-20 13:35:23 --> Config Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:35:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:35:23 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:35:23 --> URI Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Router Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Output Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Security Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Input Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:35:23 --> Language Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Loader Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:35:23 --> Controller Class Initialized
DEBUG - 2015-01-20 13:35:23 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:35:23 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:35:23 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:35:23 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Config Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:35:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:35:47 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:35:47 --> URI Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Router Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Output Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Security Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Input Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:35:47 --> Language Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Loader Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:35:47 --> Controller Class Initialized
DEBUG - 2015-01-20 13:35:47 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:35:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:35:47 --> Final output sent to browser
DEBUG - 2015-01-20 13:35:47 --> Total execution time: 0.0060
DEBUG - 2015-01-20 13:35:49 --> Config Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:35:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:35:49 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:35:49 --> URI Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Router Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Output Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Security Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Input Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:35:49 --> Language Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Loader Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:35:49 --> Controller Class Initialized
DEBUG - 2015-01-20 13:35:49 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:35:49 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:35:49 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:35:49 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Config Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:36:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:36:17 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:36:17 --> URI Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Router Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Output Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Security Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Input Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:36:17 --> Language Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Loader Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:36:17 --> Controller Class Initialized
DEBUG - 2015-01-20 13:36:17 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:36:17 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-20 13:36:17 --> Final output sent to browser
DEBUG - 2015-01-20 13:36:17 --> Total execution time: 0.0069
DEBUG - 2015-01-20 13:36:20 --> Config Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:36:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:36:20 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:36:20 --> URI Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Router Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Output Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Security Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Input Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:36:20 --> Language Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Loader Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:36:20 --> Controller Class Initialized
DEBUG - 2015-01-20 13:36:20 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:36:20 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:36:20 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:36:20 --> User Agent Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Config Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:36:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:36:44 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:36:44 --> URI Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Router Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Output Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Security Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Input Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:36:44 --> Language Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Loader Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:36:44 --> Controller Class Initialized
DEBUG - 2015-01-20 13:36:44 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:36:44 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:36:44 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:36:44 --> Final output sent to browser
DEBUG - 2015-01-20 13:36:44 --> Total execution time: 0.0128
DEBUG - 2015-01-20 13:36:49 --> Config Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:36:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:36:49 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:36:49 --> URI Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Router Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Output Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Security Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Input Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:36:49 --> Language Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Loader Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:36:49 --> Controller Class Initialized
DEBUG - 2015-01-20 13:36:49 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:36:49 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:36:49 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:36:49 --> Final output sent to browser
DEBUG - 2015-01-20 13:36:49 --> Total execution time: 0.0099
DEBUG - 2015-01-20 13:36:52 --> Config Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Hooks Class Initialized
DEBUG - 2015-01-20 13:36:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-20 13:36:52 --> Utf8 Class Initialized
DEBUG - 2015-01-20 13:36:52 --> URI Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Router Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Output Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Security Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Input Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-20 13:36:52 --> Language Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Loader Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Helper loaded: url_helper
DEBUG - 2015-01-20 13:36:52 --> Controller Class Initialized
DEBUG - 2015-01-20 13:36:52 --> Database Driver Class Initialized
DEBUG - 2015-01-20 13:36:52 --> CI_Session Class Initialized
DEBUG - 2015-01-20 13:36:52 --> CI_Session routines successfully run
DEBUG - 2015-01-20 13:36:52 --> Final output sent to browser
DEBUG - 2015-01-20 13:36:52 --> Total execution time: 0.0088
