<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-16 19:43:51 --> Config Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:43:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:43:51 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:43:51 --> URI Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Router Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Output Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Security Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Input Class Initialized
DEBUG - 2015-01-16 19:43:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:43:51 --> Language Class Initialized
ERROR - 2015-01-16 19:43:51 --> 404 Page Not Found: /index
DEBUG - 2015-01-16 19:43:55 --> Config Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:43:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:43:55 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:43:55 --> URI Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Router Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Output Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Security Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Input Class Initialized
DEBUG - 2015-01-16 19:43:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:43:55 --> Language Class Initialized
ERROR - 2015-01-16 19:43:55 --> 404 Page Not Found: /index
DEBUG - 2015-01-16 19:44:06 --> Config Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:44:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:44:06 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:44:06 --> URI Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Router Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Output Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Security Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Input Class Initialized
DEBUG - 2015-01-16 19:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:44:06 --> Language Class Initialized
ERROR - 2015-01-16 19:44:06 --> 404 Page Not Found: /index
DEBUG - 2015-01-16 19:44:14 --> Config Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:44:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:44:14 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:44:14 --> URI Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Router Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Output Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Security Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Input Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:44:14 --> Language Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Loader Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:44:14 --> Controller Class Initialized
DEBUG - 2015-01-16 19:44:14 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:44:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 19:44:14 --> Final output sent to browser
DEBUG - 2015-01-16 19:44:14 --> Total execution time: 0.3220
DEBUG - 2015-01-16 19:44:23 --> Config Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:44:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:44:23 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:44:23 --> URI Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Router Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Output Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Security Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Input Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:44:23 --> Language Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Loader Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:44:23 --> Controller Class Initialized
DEBUG - 2015-01-16 19:44:23 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:44:23 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:44:23 --> A session cookie was not found.
DEBUG - 2015-01-16 19:44:23 --> Session: Creating new session (293ed30cc80555a9f24a1c3492c72c45)
DEBUG - 2015-01-16 19:44:23 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:44:23 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Config Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:46:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:46:11 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:46:11 --> URI Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Router Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Output Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Security Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Input Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:46:11 --> Language Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Loader Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:46:11 --> Controller Class Initialized
DEBUG - 2015-01-16 19:46:11 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:46:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 19:46:11 --> Final output sent to browser
DEBUG - 2015-01-16 19:46:11 --> Total execution time: 0.0147
DEBUG - 2015-01-16 19:46:13 --> Config Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:46:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:46:13 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:46:13 --> URI Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Router Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Output Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Security Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Input Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:46:13 --> Language Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Loader Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:46:13 --> Controller Class Initialized
DEBUG - 2015-01-16 19:46:13 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:46:13 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:46:13 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:46:13 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Config Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:46:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:46:35 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:46:35 --> URI Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Router Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Output Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Security Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Input Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:46:35 --> Language Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Loader Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:46:35 --> Controller Class Initialized
DEBUG - 2015-01-16 19:46:35 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:46:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 19:46:35 --> Final output sent to browser
DEBUG - 2015-01-16 19:46:35 --> Total execution time: 0.0048
DEBUG - 2015-01-16 19:46:37 --> Config Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:46:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:46:37 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:46:37 --> URI Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Router Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Output Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Security Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Input Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:46:37 --> Language Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Loader Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:46:37 --> Controller Class Initialized
DEBUG - 2015-01-16 19:46:37 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:46:37 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:46:37 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:46:37 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Config Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:47:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:47:30 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:47:30 --> URI Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Router Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Output Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Security Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Input Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:47:30 --> Language Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Loader Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:47:30 --> Controller Class Initialized
DEBUG - 2015-01-16 19:47:30 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:47:30 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:47:30 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:47:52 --> Config Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:47:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:47:52 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:47:52 --> URI Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Router Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Output Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Security Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Input Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:47:52 --> Language Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Loader Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:47:52 --> Controller Class Initialized
DEBUG - 2015-01-16 19:47:52 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:47:52 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 19:47:52 --> Final output sent to browser
DEBUG - 2015-01-16 19:47:52 --> Total execution time: 0.0068
DEBUG - 2015-01-16 19:47:54 --> Config Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:47:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:47:54 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:47:54 --> URI Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Router Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Output Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Security Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Input Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:47:54 --> Language Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Loader Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:47:54 --> Controller Class Initialized
DEBUG - 2015-01-16 19:47:54 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:47:54 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:47:54 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:47:54 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Config Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:47:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:47:58 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:47:58 --> URI Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Router Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Output Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Security Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Input Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:47:58 --> Language Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Loader Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:47:58 --> Controller Class Initialized
DEBUG - 2015-01-16 19:47:58 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:47:58 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:47:58 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:47:58 --> Final output sent to browser
DEBUG - 2015-01-16 19:47:58 --> Total execution time: 0.0316
DEBUG - 2015-01-16 19:51:41 --> Config Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:51:41 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:51:41 --> URI Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Router Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Output Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Security Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Input Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:51:41 --> Language Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Loader Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:51:41 --> Controller Class Initialized
DEBUG - 2015-01-16 19:51:41 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:51:41 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:51:41 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:51:41 --> Final output sent to browser
DEBUG - 2015-01-16 19:51:41 --> Total execution time: 0.0065
DEBUG - 2015-01-16 19:51:50 --> Config Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:51:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:51:50 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:51:50 --> URI Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Router Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Output Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Security Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Input Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:51:50 --> Language Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Loader Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:51:50 --> Controller Class Initialized
DEBUG - 2015-01-16 19:51:50 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:51:50 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:51:50 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:51:50 --> Final output sent to browser
DEBUG - 2015-01-16 19:51:50 --> Total execution time: 0.0068
DEBUG - 2015-01-16 19:52:09 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:09 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:09 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:09 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:09 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:09 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:09 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:09 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:09 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:25 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:25 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:25 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:25 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:25 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:25 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:25 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:25 --> Final output sent to browser
DEBUG - 2015-01-16 19:52:25 --> Total execution time: 0.0123
DEBUG - 2015-01-16 19:52:27 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:27 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:27 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:27 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:27 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:27 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:27 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:27 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:27 --> Final output sent to browser
DEBUG - 2015-01-16 19:52:27 --> Total execution time: 0.0061
DEBUG - 2015-01-16 19:52:30 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:30 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:30 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:30 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:30 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:30 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:30 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:30 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:30 --> Final output sent to browser
DEBUG - 2015-01-16 19:52:30 --> Total execution time: 0.0072
DEBUG - 2015-01-16 19:52:33 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:33 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:33 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:33 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:33 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:33 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:33 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:33 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:33 --> Final output sent to browser
DEBUG - 2015-01-16 19:52:33 --> Total execution time: 0.0078
DEBUG - 2015-01-16 19:52:37 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:37 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:37 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:37 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:37 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:37 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:37 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:37 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:37 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Config Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:52:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:52:56 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:52:56 --> URI Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Router Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Output Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Security Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Input Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:52:56 --> Language Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Loader Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:52:56 --> Controller Class Initialized
DEBUG - 2015-01-16 19:52:56 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:52:56 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:52:56 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:52:56 --> Final output sent to browser
DEBUG - 2015-01-16 19:52:56 --> Total execution time: 0.0179
DEBUG - 2015-01-16 19:54:25 --> Config Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:54:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:54:25 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:54:25 --> URI Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Router Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Output Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Security Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Input Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:54:25 --> Language Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Loader Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:54:25 --> Controller Class Initialized
DEBUG - 2015-01-16 19:54:25 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:54:25 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:54:25 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:54:25 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Config Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:54:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:54:38 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:54:38 --> URI Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Router Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Output Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Security Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Input Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:54:38 --> Language Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Loader Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:54:38 --> Controller Class Initialized
DEBUG - 2015-01-16 19:54:38 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:54:38 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:54:38 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:54:38 --> Final output sent to browser
DEBUG - 2015-01-16 19:54:38 --> Total execution time: 0.0113
DEBUG - 2015-01-16 19:54:41 --> Config Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:54:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:54:41 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:54:41 --> URI Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Router Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Output Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Security Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Input Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:54:41 --> Language Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Loader Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:54:41 --> Controller Class Initialized
DEBUG - 2015-01-16 19:54:41 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:54:41 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:54:41 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:54:41 --> Final output sent to browser
DEBUG - 2015-01-16 19:54:41 --> Total execution time: 0.0063
DEBUG - 2015-01-16 19:54:48 --> Config Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:54:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:54:48 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:54:48 --> URI Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Router Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Output Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Security Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Input Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:54:48 --> Language Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Loader Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:54:48 --> Controller Class Initialized
DEBUG - 2015-01-16 19:54:48 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:54:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 19:54:48 --> Final output sent to browser
DEBUG - 2015-01-16 19:54:48 --> Total execution time: 0.0035
DEBUG - 2015-01-16 19:54:53 --> Config Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:54:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:54:53 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:54:53 --> URI Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Router Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Output Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Security Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Input Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:54:53 --> Language Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Loader Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:54:53 --> Controller Class Initialized
DEBUG - 2015-01-16 19:54:53 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:54:53 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:54:53 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:54:53 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Config Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:55:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:55:10 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:55:10 --> URI Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Router Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Output Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Security Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Input Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:55:10 --> Language Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Loader Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:55:10 --> Controller Class Initialized
DEBUG - 2015-01-16 19:55:10 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:55:10 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:55:10 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:55:10 --> Final output sent to browser
DEBUG - 2015-01-16 19:55:10 --> Total execution time: 0.0115
DEBUG - 2015-01-16 19:57:27 --> Config Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:57:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:57:27 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:57:27 --> URI Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Router Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Output Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Security Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Input Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:57:27 --> Language Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Loader Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:57:27 --> Controller Class Initialized
DEBUG - 2015-01-16 19:57:27 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:57:27 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:57:27 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:57:27 --> User Agent Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Config Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Hooks Class Initialized
DEBUG - 2015-01-16 19:57:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 19:57:32 --> Utf8 Class Initialized
DEBUG - 2015-01-16 19:57:32 --> URI Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Router Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Output Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Security Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Input Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 19:57:32 --> Language Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Loader Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Helper loaded: url_helper
DEBUG - 2015-01-16 19:57:32 --> Controller Class Initialized
DEBUG - 2015-01-16 19:57:32 --> Database Driver Class Initialized
DEBUG - 2015-01-16 19:57:32 --> CI_Session Class Initialized
DEBUG - 2015-01-16 19:57:32 --> CI_Session routines successfully run
DEBUG - 2015-01-16 19:57:32 --> Final output sent to browser
DEBUG - 2015-01-16 19:57:32 --> Total execution time: 0.0137
DEBUG - 2015-01-16 20:30:00 --> Config Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:30:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:30:00 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:30:00 --> URI Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Router Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Output Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Security Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Input Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:30:00 --> Language Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Loader Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:30:00 --> Controller Class Initialized
DEBUG - 2015-01-16 20:30:00 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:30:00 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:30:00 --> Final output sent to browser
DEBUG - 2015-01-16 20:30:00 --> Total execution time: 0.0051
DEBUG - 2015-01-16 20:30:02 --> Config Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:30:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:30:02 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:30:02 --> URI Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Router Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Output Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Security Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Input Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:30:02 --> Language Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Loader Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:30:02 --> Controller Class Initialized
DEBUG - 2015-01-16 20:30:02 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:30:02 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:30:02 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:30:02 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Config Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:30:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:30:56 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:30:56 --> URI Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Router Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Output Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Security Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Input Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:30:56 --> Language Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Loader Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:30:56 --> Controller Class Initialized
DEBUG - 2015-01-16 20:30:56 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:30:56 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:30:56 --> Final output sent to browser
DEBUG - 2015-01-16 20:30:56 --> Total execution time: 0.0061
DEBUG - 2015-01-16 20:30:58 --> Config Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:30:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:30:58 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:30:58 --> URI Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Router Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Output Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Security Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Input Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:30:58 --> Language Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Loader Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:30:58 --> Controller Class Initialized
DEBUG - 2015-01-16 20:30:58 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:30:58 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:30:58 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:30:58 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Config Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:31:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:31:16 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:31:16 --> URI Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Router Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Output Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Security Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Input Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:31:16 --> Language Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Loader Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:31:16 --> Controller Class Initialized
DEBUG - 2015-01-16 20:31:16 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:31:16 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:31:16 --> Final output sent to browser
DEBUG - 2015-01-16 20:31:16 --> Total execution time: 0.0055
DEBUG - 2015-01-16 20:31:20 --> Config Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:31:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:31:20 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:31:20 --> URI Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Router Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Output Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Security Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Input Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:31:20 --> Language Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Loader Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:31:20 --> Controller Class Initialized
DEBUG - 2015-01-16 20:31:20 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:31:20 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:31:20 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:31:20 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Config Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:32:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:32:32 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:32:32 --> URI Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Router Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Output Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Security Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Input Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:32:32 --> Language Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Loader Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:32:32 --> Controller Class Initialized
DEBUG - 2015-01-16 20:32:32 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:32:32 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:32:32 --> Final output sent to browser
DEBUG - 2015-01-16 20:32:32 --> Total execution time: 0.0048
DEBUG - 2015-01-16 20:41:28 --> Config Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:41:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:41:28 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:41:28 --> URI Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Router Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Output Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Security Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Input Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:41:28 --> Language Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Loader Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:41:28 --> Controller Class Initialized
DEBUG - 2015-01-16 20:41:28 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:41:28 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:41:28 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:41:28 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Config Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:42:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:42:43 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:42:43 --> URI Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Router Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Output Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Security Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Input Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:42:43 --> Language Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Loader Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:42:43 --> Controller Class Initialized
DEBUG - 2015-01-16 20:42:43 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:42:43 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:42:43 --> Final output sent to browser
DEBUG - 2015-01-16 20:42:43 --> Total execution time: 0.0091
DEBUG - 2015-01-16 20:42:45 --> Config Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:42:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:42:45 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:42:45 --> URI Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Router Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Output Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Security Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Input Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:42:45 --> Language Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Loader Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:42:45 --> Controller Class Initialized
DEBUG - 2015-01-16 20:42:45 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:42:45 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:42:45 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:42:45 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Config Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:43:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:43:14 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:43:14 --> URI Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Router Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Output Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Security Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Input Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:43:14 --> Language Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Loader Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:43:14 --> Controller Class Initialized
DEBUG - 2015-01-16 20:43:14 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:43:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:43:14 --> Final output sent to browser
DEBUG - 2015-01-16 20:43:14 --> Total execution time: 0.0051
DEBUG - 2015-01-16 20:43:16 --> Config Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:43:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:43:16 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:43:16 --> URI Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Router Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Output Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Security Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Input Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:43:16 --> Language Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Loader Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:43:16 --> Controller Class Initialized
DEBUG - 2015-01-16 20:43:16 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:43:16 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:43:16 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:43:16 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Config Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:43:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:43:37 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:43:37 --> URI Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Router Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Output Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Security Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Input Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:43:37 --> Language Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Loader Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:43:37 --> Controller Class Initialized
DEBUG - 2015-01-16 20:43:37 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:43:37 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:43:37 --> Final output sent to browser
DEBUG - 2015-01-16 20:43:37 --> Total execution time: 0.0040
DEBUG - 2015-01-16 20:43:39 --> Config Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:43:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:43:39 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:43:39 --> URI Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Router Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Output Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Security Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Input Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:43:39 --> Language Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Loader Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:43:39 --> Controller Class Initialized
DEBUG - 2015-01-16 20:43:39 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:43:39 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:43:39 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:43:39 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Config Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:44:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:44:00 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:44:00 --> URI Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Router Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Output Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Security Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Input Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:44:00 --> Language Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Loader Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:44:00 --> Controller Class Initialized
DEBUG - 2015-01-16 20:44:00 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:44:00 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:44:00 --> Final output sent to browser
DEBUG - 2015-01-16 20:44:00 --> Total execution time: 0.0037
DEBUG - 2015-01-16 20:44:02 --> Config Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:44:02 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:44:02 --> URI Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Router Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Output Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Security Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Input Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:44:02 --> Language Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Loader Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:44:02 --> Controller Class Initialized
DEBUG - 2015-01-16 20:44:02 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:44:02 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:44:02 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:44:02 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Config Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:44:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:44:57 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:44:57 --> URI Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Router Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Output Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Security Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Input Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:44:57 --> Language Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Loader Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:44:57 --> Controller Class Initialized
DEBUG - 2015-01-16 20:44:57 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:44:57 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:44:57 --> Final output sent to browser
DEBUG - 2015-01-16 20:44:57 --> Total execution time: 0.0044
DEBUG - 2015-01-16 20:44:59 --> Config Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:44:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:44:59 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:44:59 --> URI Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Router Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Output Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Security Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Input Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:44:59 --> Language Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Loader Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:44:59 --> Controller Class Initialized
DEBUG - 2015-01-16 20:44:59 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:44:59 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:44:59 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:44:59 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Config Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:45:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:45:13 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:45:13 --> URI Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Router Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Output Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Security Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Input Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:45:13 --> Language Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Loader Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:45:13 --> Controller Class Initialized
DEBUG - 2015-01-16 20:45:13 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:45:13 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:45:13 --> Final output sent to browser
DEBUG - 2015-01-16 20:45:13 --> Total execution time: 0.0033
DEBUG - 2015-01-16 20:45:15 --> Config Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:45:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:45:15 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:45:15 --> URI Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Router Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Output Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Security Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Input Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:45:15 --> Language Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Loader Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:45:15 --> Controller Class Initialized
DEBUG - 2015-01-16 20:45:15 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:45:15 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:45:15 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:45:15 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Config Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:45:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:45:36 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:45:36 --> URI Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Router Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Output Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Security Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Input Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:45:36 --> Language Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Loader Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:45:36 --> Controller Class Initialized
DEBUG - 2015-01-16 20:45:36 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:45:36 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:45:36 --> Final output sent to browser
DEBUG - 2015-01-16 20:45:36 --> Total execution time: 0.0034
DEBUG - 2015-01-16 20:45:38 --> Config Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:45:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:45:38 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:45:38 --> URI Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Router Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Output Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Security Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Input Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:45:38 --> Language Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Loader Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:45:38 --> Controller Class Initialized
DEBUG - 2015-01-16 20:45:38 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:45:38 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:45:38 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:45:38 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Config Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:46:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:46:17 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:46:17 --> URI Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Router Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Output Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Security Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Input Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:46:17 --> Language Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Loader Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:46:17 --> Controller Class Initialized
DEBUG - 2015-01-16 20:46:17 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:46:17 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:46:17 --> Final output sent to browser
DEBUG - 2015-01-16 20:46:17 --> Total execution time: 0.0039
DEBUG - 2015-01-16 20:46:19 --> Config Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:46:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:46:19 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:46:19 --> URI Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Router Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Output Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Security Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Input Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:46:19 --> Language Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Loader Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:46:19 --> Controller Class Initialized
DEBUG - 2015-01-16 20:46:19 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:46:19 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:46:19 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:46:19 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Config Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:46:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:46:47 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:46:47 --> URI Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Router Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Output Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Security Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Input Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:46:47 --> Language Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Loader Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:46:47 --> Controller Class Initialized
DEBUG - 2015-01-16 20:46:47 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:46:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:46:47 --> Final output sent to browser
DEBUG - 2015-01-16 20:46:47 --> Total execution time: 0.0040
DEBUG - 2015-01-16 20:46:49 --> Config Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:46:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:46:49 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:46:49 --> URI Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Router Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Output Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Security Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Input Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:46:49 --> Language Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Loader Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:46:49 --> Controller Class Initialized
DEBUG - 2015-01-16 20:46:49 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:46:49 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:46:49 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:46:49 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Config Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:47:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:47:11 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:47:11 --> URI Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Router Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Output Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Security Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Input Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:47:11 --> Language Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Loader Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:47:11 --> Controller Class Initialized
DEBUG - 2015-01-16 20:47:11 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:47:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:47:11 --> Final output sent to browser
DEBUG - 2015-01-16 20:47:11 --> Total execution time: 0.0055
DEBUG - 2015-01-16 20:47:13 --> Config Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:47:13 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:47:13 --> URI Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Router Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Output Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Security Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Input Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:47:13 --> Language Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Loader Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:47:13 --> Controller Class Initialized
DEBUG - 2015-01-16 20:47:13 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:47:13 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:47:13 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:47:13 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Config Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:47:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:47:22 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:47:22 --> URI Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Router Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Output Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Security Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Input Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:47:22 --> Language Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Loader Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:47:22 --> Controller Class Initialized
DEBUG - 2015-01-16 20:47:22 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:47:22 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:47:22 --> Final output sent to browser
DEBUG - 2015-01-16 20:47:22 --> Total execution time: 0.0101
DEBUG - 2015-01-16 20:47:23 --> Config Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:47:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:47:23 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:47:23 --> URI Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Router Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Output Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Security Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Input Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:47:23 --> Language Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Loader Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:47:23 --> Controller Class Initialized
DEBUG - 2015-01-16 20:47:23 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:47:23 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:47:23 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:47:23 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Config Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:47:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:47:59 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:47:59 --> URI Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Router Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Output Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Security Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Input Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:47:59 --> Language Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Loader Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:47:59 --> Controller Class Initialized
DEBUG - 2015-01-16 20:47:59 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:47:59 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:47:59 --> Final output sent to browser
DEBUG - 2015-01-16 20:47:59 --> Total execution time: 0.0049
DEBUG - 2015-01-16 20:48:01 --> Config Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:48:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:48:01 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:48:01 --> URI Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Router Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Output Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Security Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Input Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:48:01 --> Language Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Loader Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:48:01 --> Controller Class Initialized
DEBUG - 2015-01-16 20:48:01 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:48:01 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:48:01 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:48:01 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Config Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:48:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:48:35 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:48:35 --> URI Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Router Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Output Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Security Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Input Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:48:35 --> Language Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Loader Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:48:35 --> Controller Class Initialized
DEBUG - 2015-01-16 20:48:35 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:48:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:48:35 --> Final output sent to browser
DEBUG - 2015-01-16 20:48:35 --> Total execution time: 0.0042
DEBUG - 2015-01-16 20:48:37 --> Config Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:48:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:48:37 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:48:37 --> URI Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Router Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Output Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Security Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Input Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:48:37 --> Language Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Loader Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:48:37 --> Controller Class Initialized
DEBUG - 2015-01-16 20:48:37 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:48:37 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:48:37 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:48:37 --> User Agent Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Config Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:50:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:50:29 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:50:29 --> URI Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Router Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Output Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Security Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Input Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:50:29 --> Language Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Loader Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:50:29 --> Controller Class Initialized
DEBUG - 2015-01-16 20:50:29 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:50:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 20:50:29 --> Final output sent to browser
DEBUG - 2015-01-16 20:50:29 --> Total execution time: 0.0141
DEBUG - 2015-01-16 20:50:57 --> Config Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Hooks Class Initialized
DEBUG - 2015-01-16 20:50:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 20:50:57 --> Utf8 Class Initialized
DEBUG - 2015-01-16 20:50:57 --> URI Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Router Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Output Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Security Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Input Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 20:50:57 --> Language Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Loader Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Helper loaded: url_helper
DEBUG - 2015-01-16 20:50:57 --> Controller Class Initialized
DEBUG - 2015-01-16 20:50:57 --> Database Driver Class Initialized
DEBUG - 2015-01-16 20:50:57 --> CI_Session Class Initialized
DEBUG - 2015-01-16 20:50:57 --> CI_Session routines successfully run
DEBUG - 2015-01-16 20:50:57 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Config Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:07:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:07:29 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:07:29 --> URI Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Router Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Output Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Security Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Input Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:07:29 --> Language Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Loader Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:07:29 --> Controller Class Initialized
DEBUG - 2015-01-16 21:07:29 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:07:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:07:29 --> Final output sent to browser
DEBUG - 2015-01-16 21:07:29 --> Total execution time: 0.0046
DEBUG - 2015-01-16 21:07:32 --> Config Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:07:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:07:32 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:07:32 --> URI Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Router Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Output Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Security Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Input Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:07:32 --> Language Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Loader Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:07:32 --> Controller Class Initialized
DEBUG - 2015-01-16 21:07:32 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:07:32 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:07:32 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:07:32 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Config Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:07:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:07:46 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:07:46 --> URI Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Router Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Output Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Security Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Input Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:07:46 --> Language Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Loader Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:07:46 --> Controller Class Initialized
DEBUG - 2015-01-16 21:07:46 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:07:46 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:07:46 --> Final output sent to browser
DEBUG - 2015-01-16 21:07:46 --> Total execution time: 0.0042
DEBUG - 2015-01-16 21:07:48 --> Config Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:07:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:07:48 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:07:48 --> URI Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Router Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Output Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Security Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Input Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:07:48 --> Language Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Loader Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:07:48 --> Controller Class Initialized
DEBUG - 2015-01-16 21:07:48 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:07:48 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:07:48 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:07:48 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Config Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:08:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:08:11 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:08:11 --> URI Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Router Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Output Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Security Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Input Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:08:11 --> Language Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Loader Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:08:11 --> Controller Class Initialized
DEBUG - 2015-01-16 21:08:11 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:08:11 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:08:11 --> Final output sent to browser
DEBUG - 2015-01-16 21:08:11 --> Total execution time: 0.0038
DEBUG - 2015-01-16 21:08:13 --> Config Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:08:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:08:13 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:08:13 --> URI Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Router Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Output Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Security Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Input Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:08:13 --> Language Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Loader Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:08:13 --> Controller Class Initialized
DEBUG - 2015-01-16 21:08:13 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:08:13 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:08:13 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:08:13 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Config Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:11:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:11:38 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:11:38 --> URI Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Router Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Output Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Security Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Input Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:11:38 --> Language Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Loader Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:11:38 --> Controller Class Initialized
DEBUG - 2015-01-16 21:11:38 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:11:38 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:11:38 --> Final output sent to browser
DEBUG - 2015-01-16 21:11:38 --> Total execution time: 0.0053
DEBUG - 2015-01-16 21:11:40 --> Config Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:11:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:11:40 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:11:40 --> URI Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Router Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Output Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Security Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Input Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:11:40 --> Language Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Loader Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:11:40 --> Controller Class Initialized
DEBUG - 2015-01-16 21:11:40 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:11:40 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:11:40 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:11:40 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Config Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:13:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:13:05 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:13:05 --> URI Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Router Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Output Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Security Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Input Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:13:05 --> Language Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Loader Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:13:05 --> Controller Class Initialized
DEBUG - 2015-01-16 21:13:05 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:13:05 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:13:05 --> Final output sent to browser
DEBUG - 2015-01-16 21:13:05 --> Total execution time: 0.0038
DEBUG - 2015-01-16 21:13:07 --> Config Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:13:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:13:07 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:13:07 --> URI Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Router Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Output Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Security Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Input Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:13:07 --> Language Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Loader Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:13:07 --> Controller Class Initialized
DEBUG - 2015-01-16 21:13:07 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:13:07 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:13:07 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:13:07 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Config Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:13:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:13:35 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:13:35 --> URI Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Router Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Output Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Security Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Input Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:13:35 --> Language Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Loader Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:13:35 --> Controller Class Initialized
DEBUG - 2015-01-16 21:13:35 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:13:35 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:13:35 --> Final output sent to browser
DEBUG - 2015-01-16 21:13:35 --> Total execution time: 0.0125
DEBUG - 2015-01-16 21:13:36 --> Config Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:13:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:13:36 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:13:36 --> URI Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Router Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Output Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Security Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Input Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:13:36 --> Language Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Loader Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:13:36 --> Controller Class Initialized
DEBUG - 2015-01-16 21:13:36 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:13:36 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:13:36 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:13:36 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Config Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:13:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:13:58 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:13:58 --> URI Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Router Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Output Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Security Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Input Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:13:58 --> Language Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Loader Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:13:58 --> Controller Class Initialized
DEBUG - 2015-01-16 21:13:58 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:13:58 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:13:58 --> Final output sent to browser
DEBUG - 2015-01-16 21:13:58 --> Total execution time: 0.0038
DEBUG - 2015-01-16 21:14:02 --> Config Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:14:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:14:02 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:14:02 --> URI Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Router Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Output Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Security Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Input Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:14:02 --> Language Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Loader Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:14:02 --> Controller Class Initialized
DEBUG - 2015-01-16 21:14:02 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:14:02 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:14:02 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:14:02 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Config Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:16:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:16:31 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:16:31 --> URI Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Router Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Output Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Security Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Input Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:16:31 --> Language Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Loader Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:16:31 --> Controller Class Initialized
DEBUG - 2015-01-16 21:16:31 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:16:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:16:31 --> Final output sent to browser
DEBUG - 2015-01-16 21:16:31 --> Total execution time: 0.0065
DEBUG - 2015-01-16 21:16:33 --> Config Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:16:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:16:33 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:16:33 --> URI Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Router Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Output Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Security Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Input Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:16:33 --> Language Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Loader Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:16:33 --> Controller Class Initialized
DEBUG - 2015-01-16 21:16:33 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:16:33 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:16:33 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:16:33 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Config Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:16:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:16:43 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:16:43 --> URI Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Router Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Output Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Security Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Input Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:16:43 --> Language Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Loader Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:16:43 --> Controller Class Initialized
DEBUG - 2015-01-16 21:16:43 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:16:43 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:16:43 --> Final output sent to browser
DEBUG - 2015-01-16 21:16:43 --> Total execution time: 0.0114
DEBUG - 2015-01-16 21:16:45 --> Config Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:16:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:16:45 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:16:45 --> URI Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Router Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Output Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Security Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Input Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:16:45 --> Language Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Loader Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:16:45 --> Controller Class Initialized
DEBUG - 2015-01-16 21:16:45 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:16:45 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:16:45 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:16:45 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Config Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:21:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:21:48 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:21:48 --> URI Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Router Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Output Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Security Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Input Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:21:48 --> Language Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Loader Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:21:48 --> Controller Class Initialized
DEBUG - 2015-01-16 21:21:48 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:21:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:21:48 --> Final output sent to browser
DEBUG - 2015-01-16 21:21:48 --> Total execution time: 0.0035
DEBUG - 2015-01-16 21:21:50 --> Config Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:21:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:21:50 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:21:50 --> URI Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Router Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Output Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Security Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Input Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:21:50 --> Language Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Loader Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:21:50 --> Controller Class Initialized
DEBUG - 2015-01-16 21:21:50 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:21:50 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:21:50 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:21:50 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Config Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:23:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:23:01 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:23:01 --> URI Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Router Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Output Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Security Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Input Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:23:01 --> Language Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Loader Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:23:01 --> Controller Class Initialized
DEBUG - 2015-01-16 21:23:01 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:23:01 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:23:01 --> Final output sent to browser
DEBUG - 2015-01-16 21:23:01 --> Total execution time: 0.0102
DEBUG - 2015-01-16 21:25:33 --> Config Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:25:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:25:33 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:25:33 --> URI Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Router Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Output Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Security Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Input Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:25:33 --> Language Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Loader Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:25:33 --> Controller Class Initialized
DEBUG - 2015-01-16 21:25:33 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:25:33 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:25:33 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:25:33 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Config Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:29:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:29:15 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:29:15 --> URI Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Router Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Output Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Security Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Input Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:29:15 --> Language Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Loader Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:29:15 --> Controller Class Initialized
DEBUG - 2015-01-16 21:29:15 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:29:15 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:29:15 --> Final output sent to browser
DEBUG - 2015-01-16 21:29:15 --> Total execution time: 0.0033
DEBUG - 2015-01-16 21:29:17 --> Config Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:29:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:29:17 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:29:17 --> URI Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Router Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Output Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Security Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Input Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:29:17 --> Language Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Loader Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:29:17 --> Controller Class Initialized
DEBUG - 2015-01-16 21:29:17 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:29:17 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:29:17 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:29:17 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Config Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:33:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:33:59 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:33:59 --> URI Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Router Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Output Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Security Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Input Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:33:59 --> Language Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Loader Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:33:59 --> Controller Class Initialized
DEBUG - 2015-01-16 21:33:59 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:33:59 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:33:59 --> Final output sent to browser
DEBUG - 2015-01-16 21:33:59 --> Total execution time: 0.0046
DEBUG - 2015-01-16 21:34:01 --> Config Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:34:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:34:01 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:34:01 --> URI Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Router Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Output Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Security Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Input Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:34:01 --> Language Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Loader Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:34:01 --> Controller Class Initialized
DEBUG - 2015-01-16 21:34:01 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:34:01 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:34:01 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:34:01 --> User Agent Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Config Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:42:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:42:53 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:42:53 --> URI Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Router Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Output Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Security Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Input Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:42:53 --> Language Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Loader Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:42:53 --> Controller Class Initialized
DEBUG - 2015-01-16 21:42:53 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:42:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-16 21:42:53 --> Final output sent to browser
DEBUG - 2015-01-16 21:42:53 --> Total execution time: 0.0038
DEBUG - 2015-01-16 21:42:55 --> Config Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Hooks Class Initialized
DEBUG - 2015-01-16 21:42:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-16 21:42:55 --> Utf8 Class Initialized
DEBUG - 2015-01-16 21:42:55 --> URI Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Router Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Output Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Security Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Input Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-16 21:42:55 --> Language Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Loader Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Helper loaded: url_helper
DEBUG - 2015-01-16 21:42:55 --> Controller Class Initialized
DEBUG - 2015-01-16 21:42:55 --> Database Driver Class Initialized
DEBUG - 2015-01-16 21:42:55 --> CI_Session Class Initialized
DEBUG - 2015-01-16 21:42:55 --> CI_Session routines successfully run
DEBUG - 2015-01-16 21:42:55 --> User Agent Class Initialized
