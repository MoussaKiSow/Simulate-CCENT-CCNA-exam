<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-14 14:42:27 --> Config Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:42:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:42:27 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:42:27 --> URI Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Router Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Output Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Security Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Input Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:42:27 --> Language Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Loader Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:42:27 --> Controller Class Initialized
DEBUG - 2015-01-14 14:42:27 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:42:27 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:42:27 --> Final output sent to browser
DEBUG - 2015-01-14 14:42:27 --> Total execution time: 0.2709
DEBUG - 2015-01-14 14:42:56 --> Config Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:42:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:42:56 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:42:56 --> URI Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Router Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Output Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Security Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Input Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:42:56 --> Language Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Loader Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:42:56 --> Controller Class Initialized
DEBUG - 2015-01-14 14:42:56 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:42:56 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:42:56 --> A session cookie was not found.
DEBUG - 2015-01-14 14:42:56 --> Session: Creating new session (b19276bc248295958a6eb9dd7329cdd7)
DEBUG - 2015-01-14 14:42:56 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:48:53 --> Config Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:48:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:48:53 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:48:53 --> URI Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Router Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Output Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Security Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Input Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:48:53 --> Language Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Loader Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:48:53 --> Controller Class Initialized
DEBUG - 2015-01-14 14:48:53 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:48:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:48:53 --> Final output sent to browser
DEBUG - 2015-01-14 14:48:53 --> Total execution time: 0.0106
DEBUG - 2015-01-14 14:48:58 --> Config Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:48:58 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:48:58 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:48:58 --> URI Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Router Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Output Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Security Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Input Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:48:58 --> Language Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Loader Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:48:58 --> Controller Class Initialized
DEBUG - 2015-01-14 14:48:58 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:48:58 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:48:58 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:48:58 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Config Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:49:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:49:34 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:49:34 --> URI Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Router Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Output Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Security Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Input Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:49:34 --> Language Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Loader Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:49:34 --> Controller Class Initialized
DEBUG - 2015-01-14 14:49:34 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:49:34 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:49:34 --> Final output sent to browser
DEBUG - 2015-01-14 14:49:34 --> Total execution time: 0.0085
DEBUG - 2015-01-14 14:49:36 --> Config Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:49:36 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:49:36 --> URI Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Router Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Output Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Security Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Input Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:49:36 --> Language Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Loader Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:49:36 --> Controller Class Initialized
DEBUG - 2015-01-14 14:49:36 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:49:36 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:49:36 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:49:36 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Config Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:50:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:50:06 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:50:06 --> URI Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Router Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Output Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Security Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Input Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:50:06 --> Language Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Loader Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:50:06 --> Controller Class Initialized
DEBUG - 2015-01-14 14:50:06 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:50:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:50:06 --> Final output sent to browser
DEBUG - 2015-01-14 14:50:06 --> Total execution time: 0.0042
DEBUG - 2015-01-14 14:50:07 --> Config Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:50:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:50:07 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:50:07 --> URI Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Router Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Output Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Security Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Input Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:50:07 --> Language Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Loader Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:50:07 --> Controller Class Initialized
DEBUG - 2015-01-14 14:50:07 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:50:07 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:50:07 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:50:07 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Config Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:52:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:52:18 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:52:18 --> URI Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Router Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Output Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Security Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Input Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:52:18 --> Language Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Loader Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:52:18 --> Controller Class Initialized
DEBUG - 2015-01-14 14:52:18 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:52:18 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:52:18 --> Final output sent to browser
DEBUG - 2015-01-14 14:52:18 --> Total execution time: 0.0100
DEBUG - 2015-01-14 14:52:20 --> Config Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:52:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:52:20 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:52:20 --> URI Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Router Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Output Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Security Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Input Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:52:20 --> Language Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Loader Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:52:20 --> Controller Class Initialized
DEBUG - 2015-01-14 14:52:20 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:52:20 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:52:20 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:52:20 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Config Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:54:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:54:42 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:54:42 --> URI Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Router Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Output Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Security Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Input Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:54:42 --> Language Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Loader Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:54:42 --> Controller Class Initialized
DEBUG - 2015-01-14 14:54:42 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:54:42 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:54:42 --> Final output sent to browser
DEBUG - 2015-01-14 14:54:42 --> Total execution time: 0.0044
DEBUG - 2015-01-14 14:54:50 --> Config Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:54:50 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:54:50 --> URI Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Router Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Output Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Security Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Input Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:54:50 --> Language Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Loader Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:54:50 --> Controller Class Initialized
DEBUG - 2015-01-14 14:54:50 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:54:50 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:54:50 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:54:50 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Config Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:55:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:55:26 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:55:26 --> URI Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Router Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Output Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Security Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Input Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:55:26 --> Language Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Loader Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:55:26 --> Controller Class Initialized
DEBUG - 2015-01-14 14:55:26 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:55:26 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:55:26 --> Final output sent to browser
DEBUG - 2015-01-14 14:55:26 --> Total execution time: 0.0043
DEBUG - 2015-01-14 14:55:28 --> Config Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:55:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:55:28 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:55:28 --> URI Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Router Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Output Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Security Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Input Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:55:28 --> Language Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Loader Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:55:28 --> Controller Class Initialized
DEBUG - 2015-01-14 14:55:28 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:55:28 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:55:28 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:55:28 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Config Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:55:51 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:55:51 --> URI Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Router Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Output Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Security Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Input Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:55:51 --> Language Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Loader Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:55:51 --> Controller Class Initialized
DEBUG - 2015-01-14 14:55:51 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:55:51 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:55:51 --> Final output sent to browser
DEBUG - 2015-01-14 14:55:51 --> Total execution time: 0.0041
DEBUG - 2015-01-14 14:55:53 --> Config Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:55:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:55:53 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:55:53 --> URI Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Router Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Output Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Security Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Input Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:55:53 --> Language Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Loader Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:55:53 --> Controller Class Initialized
DEBUG - 2015-01-14 14:55:53 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:55:53 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:55:53 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:55:53 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Config Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:56:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:56:39 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:56:39 --> URI Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Router Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Output Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Security Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Input Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:56:39 --> Language Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Loader Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:56:39 --> Controller Class Initialized
DEBUG - 2015-01-14 14:56:39 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:56:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:56:39 --> Final output sent to browser
DEBUG - 2015-01-14 14:56:39 --> Total execution time: 0.0048
DEBUG - 2015-01-14 14:56:41 --> Config Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:56:41 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:56:41 --> URI Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Router Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Output Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Security Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Input Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:56:41 --> Language Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Loader Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:56:41 --> Controller Class Initialized
DEBUG - 2015-01-14 14:56:41 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:56:41 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:56:41 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:56:41 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:00 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:00 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:00 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:00 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:00 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:00 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:57:00 --> Final output sent to browser
DEBUG - 2015-01-14 14:57:00 --> Total execution time: 0.0094
DEBUG - 2015-01-14 14:57:02 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:02 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:02 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:02 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:02 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:02 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:02 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:57:02 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:57:02 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:33 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:33 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:33 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:33 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:33 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:33 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:57:33 --> Final output sent to browser
DEBUG - 2015-01-14 14:57:33 --> Total execution time: 0.0220
DEBUG - 2015-01-14 14:57:38 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:38 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:38 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:38 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:38 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:38 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:38 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:57:38 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:57:38 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:51 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:51 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:51 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:51 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:51 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:51 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:57:51 --> Final output sent to browser
DEBUG - 2015-01-14 14:57:51 --> Total execution time: 0.0075
DEBUG - 2015-01-14 14:57:53 --> Config Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:57:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:57:53 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:57:53 --> URI Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Router Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Output Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Security Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Input Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:57:53 --> Language Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Loader Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:57:53 --> Controller Class Initialized
DEBUG - 2015-01-14 14:57:53 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:57:53 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:57:53 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:57:53 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Config Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:58:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:58:24 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:58:24 --> URI Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Router Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Output Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Security Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Input Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:58:24 --> Language Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Loader Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:58:24 --> Controller Class Initialized
DEBUG - 2015-01-14 14:58:24 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:58:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:58:24 --> Final output sent to browser
DEBUG - 2015-01-14 14:58:24 --> Total execution time: 0.0047
DEBUG - 2015-01-14 14:58:28 --> Config Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:58:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:58:28 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:58:28 --> URI Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Router Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Output Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Security Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Input Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:58:28 --> Language Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Loader Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:58:28 --> Controller Class Initialized
DEBUG - 2015-01-14 14:58:28 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:58:28 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:58:28 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:58:28 --> User Agent Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Config Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:58:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:58:48 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:58:48 --> URI Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Router Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Output Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Security Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Input Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:58:48 --> Language Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Loader Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:58:48 --> Controller Class Initialized
DEBUG - 2015-01-14 14:58:48 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:58:48 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 14:58:48 --> Final output sent to browser
DEBUG - 2015-01-14 14:58:48 --> Total execution time: 0.0119
DEBUG - 2015-01-14 14:58:50 --> Config Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Hooks Class Initialized
DEBUG - 2015-01-14 14:58:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 14:58:50 --> Utf8 Class Initialized
DEBUG - 2015-01-14 14:58:50 --> URI Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Router Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Output Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Security Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Input Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 14:58:50 --> Language Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Loader Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Helper loaded: url_helper
DEBUG - 2015-01-14 14:58:50 --> Controller Class Initialized
DEBUG - 2015-01-14 14:58:50 --> Database Driver Class Initialized
DEBUG - 2015-01-14 14:58:50 --> CI_Session Class Initialized
DEBUG - 2015-01-14 14:58:50 --> CI_Session routines successfully run
DEBUG - 2015-01-14 14:58:50 --> User Agent Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Config Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:04:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:04:55 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:04:55 --> URI Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Router Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Output Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Security Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Input Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:04:55 --> Language Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Loader Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:04:55 --> Controller Class Initialized
DEBUG - 2015-01-14 15:04:55 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:04:55 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:04:55 --> Final output sent to browser
DEBUG - 2015-01-14 15:04:55 --> Total execution time: 0.0063
DEBUG - 2015-01-14 15:04:57 --> Config Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:04:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:04:57 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:04:57 --> URI Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Router Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Output Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Security Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Input Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:04:57 --> Language Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Loader Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:04:57 --> Controller Class Initialized
DEBUG - 2015-01-14 15:04:57 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:04:57 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:04:57 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:04:57 --> User Agent Class Initialized
ERROR - 2015-01-14 15:04:57 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421247897, 'Guest', 1)
DEBUG - 2015-01-14 15:05:34 --> Config Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:05:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:05:34 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:05:34 --> URI Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Router Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Output Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Security Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Input Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:05:34 --> Language Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Loader Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:05:34 --> Controller Class Initialized
DEBUG - 2015-01-14 15:05:34 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:05:34 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:05:34 --> Final output sent to browser
DEBUG - 2015-01-14 15:05:34 --> Total execution time: 0.0048
DEBUG - 2015-01-14 15:05:36 --> Config Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:05:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:05:36 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:05:36 --> URI Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Router Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Output Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Security Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Input Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:05:36 --> Language Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Loader Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:05:36 --> Controller Class Initialized
DEBUG - 2015-01-14 15:05:36 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:05:36 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:05:36 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:05:36 --> User Agent Class Initialized
ERROR - 2015-01-14 15:05:36 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421247897, 'Guest', 1)
DEBUG - 2015-01-14 15:06:29 --> Config Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:06:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:06:29 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:06:29 --> URI Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Router Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Output Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Security Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Input Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:06:29 --> Language Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Loader Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:06:29 --> Controller Class Initialized
DEBUG - 2015-01-14 15:06:29 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:06:29 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:06:29 --> Final output sent to browser
DEBUG - 2015-01-14 15:06:29 --> Total execution time: 0.0047
DEBUG - 2015-01-14 15:06:31 --> Config Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:06:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:06:31 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:06:31 --> URI Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Router Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Output Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Security Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Input Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:06:31 --> Language Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Loader Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:06:31 --> Controller Class Initialized
DEBUG - 2015-01-14 15:06:31 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:06:31 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:06:31 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:06:31 --> User Agent Class Initialized
ERROR - 2015-01-14 15:06:31 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421247897, 'Guest', 1)
DEBUG - 2015-01-14 15:08:14 --> Config Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:08:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:08:14 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:08:14 --> URI Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Router Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Output Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Security Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Input Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:08:14 --> Language Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Loader Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:08:14 --> Controller Class Initialized
DEBUG - 2015-01-14 15:08:14 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:08:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:08:14 --> Final output sent to browser
DEBUG - 2015-01-14 15:08:14 --> Total execution time: 0.0039
DEBUG - 2015-01-14 15:08:16 --> Config Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:08:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:08:16 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:08:16 --> URI Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Router Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Output Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Security Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Input Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:08:16 --> Language Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Loader Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:08:16 --> Controller Class Initialized
DEBUG - 2015-01-14 15:08:16 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:08:16 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:08:16 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:08:16 --> User Agent Class Initialized
ERROR - 2015-01-14 15:08:16 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421247897, 'Guest', 1)
DEBUG - 2015-01-14 15:11:16 --> Config Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:11:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:11:16 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:11:16 --> URI Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Router Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Output Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Security Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Input Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:11:16 --> Language Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Loader Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:11:16 --> Controller Class Initialized
DEBUG - 2015-01-14 15:11:16 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:11:16 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:11:16 --> Final output sent to browser
DEBUG - 2015-01-14 15:11:16 --> Total execution time: 0.0086
DEBUG - 2015-01-14 15:11:20 --> Config Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:11:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:11:20 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:11:20 --> URI Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Router Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Output Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Security Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Input Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:11:20 --> Language Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Loader Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:11:20 --> Controller Class Initialized
DEBUG - 2015-01-14 15:11:20 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:11:20 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:11:20 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:11:20 --> User Agent Class Initialized
ERROR - 2015-01-14 15:11:20 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421248280, 'Guest', 1)
DEBUG - 2015-01-14 15:14:14 --> Config Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:14:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:14:14 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:14:14 --> URI Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Router Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Output Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Security Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Input Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:14:14 --> Language Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Loader Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:14:14 --> Controller Class Initialized
DEBUG - 2015-01-14 15:14:14 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:14:14 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:14:14 --> Final output sent to browser
DEBUG - 2015-01-14 15:14:14 --> Total execution time: 0.0036
DEBUG - 2015-01-14 15:14:16 --> Config Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:14:16 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:14:16 --> URI Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Router Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Output Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Security Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Input Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:14:16 --> Language Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Loader Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:14:16 --> Controller Class Initialized
DEBUG - 2015-01-14 15:14:16 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:14:16 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:14:16 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:14:16 --> User Agent Class Initialized
ERROR - 2015-01-14 15:14:16 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421248280, 'Guest', 1)
DEBUG - 2015-01-14 15:17:06 --> Config Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:17:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:17:06 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:17:06 --> URI Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Router Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Output Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Security Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Input Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:17:06 --> Language Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Loader Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:17:06 --> Controller Class Initialized
DEBUG - 2015-01-14 15:17:06 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:17:06 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:17:06 --> Final output sent to browser
DEBUG - 2015-01-14 15:17:06 --> Total execution time: 0.0049
DEBUG - 2015-01-14 15:17:08 --> Config Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:17:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:17:08 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:17:08 --> URI Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Router Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Output Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Security Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Input Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:17:08 --> Language Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Loader Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:17:08 --> Controller Class Initialized
DEBUG - 2015-01-14 15:17:08 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:17:08 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:17:08 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:17:08 --> User Agent Class Initialized
ERROR - 2015-01-14 15:17:08 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421248628, 'Guest', 1)
DEBUG - 2015-01-14 15:17:46 --> Config Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:17:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:17:46 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:17:46 --> URI Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Router Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Output Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Security Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Input Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:17:46 --> Language Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Loader Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:17:46 --> Controller Class Initialized
DEBUG - 2015-01-14 15:17:46 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:17:46 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-14 15:17:46 --> Final output sent to browser
DEBUG - 2015-01-14 15:17:46 --> Total execution time: 0.0176
DEBUG - 2015-01-14 15:17:48 --> Config Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Hooks Class Initialized
DEBUG - 2015-01-14 15:17:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-14 15:17:48 --> Utf8 Class Initialized
DEBUG - 2015-01-14 15:17:48 --> URI Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Router Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Output Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Security Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Input Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-14 15:17:48 --> Language Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Loader Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Helper loaded: url_helper
DEBUG - 2015-01-14 15:17:48 --> Controller Class Initialized
DEBUG - 2015-01-14 15:17:48 --> Database Driver Class Initialized
DEBUG - 2015-01-14 15:17:48 --> CI_Session Class Initialized
DEBUG - 2015-01-14 15:17:48 --> CI_Session routines successfully run
DEBUG - 2015-01-14 15:17:48 --> User Agent Class Initialized
ERROR - 2015-01-14 15:17:48 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('b19276bc248295958a6eb9dd7329cdd7', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421248628, 'Guest', 1)
