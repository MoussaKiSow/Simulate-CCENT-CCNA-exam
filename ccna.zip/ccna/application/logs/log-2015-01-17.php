<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-01-17 15:44:05 --> Config Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:44:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:44:05 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:44:05 --> URI Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Router Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Output Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Security Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Input Class Initialized
DEBUG - 2015-01-17 15:44:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:44:05 --> Language Class Initialized
ERROR - 2015-01-17 15:44:05 --> 404 Page Not Found: /index
DEBUG - 2015-01-17 15:44:10 --> Config Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:44:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:44:10 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:44:10 --> URI Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Router Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Output Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Security Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Input Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:44:10 --> Language Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Loader Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:44:10 --> Controller Class Initialized
DEBUG - 2015-01-17 15:44:10 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:44:10 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 15:44:10 --> Final output sent to browser
DEBUG - 2015-01-17 15:44:10 --> Total execution time: 0.1949
DEBUG - 2015-01-17 15:46:27 --> Config Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:46:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:46:27 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:46:27 --> URI Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Router Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Output Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Security Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Input Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:46:27 --> Language Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Loader Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:46:27 --> Controller Class Initialized
DEBUG - 2015-01-17 15:46:27 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:46:27 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 15:46:27 --> Final output sent to browser
DEBUG - 2015-01-17 15:46:27 --> Total execution time: 0.0130
DEBUG - 2015-01-17 15:47:55 --> Config Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:47:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:47:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:47:55 --> URI Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Router Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Output Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Security Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Input Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:47:55 --> Language Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Loader Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:47:55 --> Controller Class Initialized
DEBUG - 2015-01-17 15:47:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:47:55 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 15:47:55 --> Final output sent to browser
DEBUG - 2015-01-17 15:47:55 --> Total execution time: 0.0106
DEBUG - 2015-01-17 15:49:09 --> Config Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:49:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:49:09 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:49:09 --> URI Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Router Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Output Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Security Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Input Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:49:09 --> Language Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Loader Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:49:09 --> Controller Class Initialized
DEBUG - 2015-01-17 15:49:09 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:49:09 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 15:49:09 --> Final output sent to browser
DEBUG - 2015-01-17 15:49:09 --> Total execution time: 0.0055
DEBUG - 2015-01-17 15:49:20 --> Config Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:49:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:49:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:49:20 --> URI Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Router Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Output Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Security Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Input Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:49:20 --> Language Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Loader Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:49:20 --> Controller Class Initialized
DEBUG - 2015-01-17 15:49:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:49:20 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 15:49:20 --> Final output sent to browser
DEBUG - 2015-01-17 15:49:20 --> Total execution time: 0.0048
DEBUG - 2015-01-17 15:49:32 --> Config Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Hooks Class Initialized
DEBUG - 2015-01-17 15:49:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 15:49:32 --> Utf8 Class Initialized
DEBUG - 2015-01-17 15:49:32 --> URI Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Router Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Output Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Security Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Input Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 15:49:32 --> Language Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Loader Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Helper loaded: url_helper
DEBUG - 2015-01-17 15:49:32 --> Controller Class Initialized
DEBUG - 2015-01-17 15:49:32 --> Database Driver Class Initialized
DEBUG - 2015-01-17 15:49:32 --> CI_Session Class Initialized
DEBUG - 2015-01-17 15:49:32 --> A session cookie was not found.
DEBUG - 2015-01-17 15:49:32 --> Session: Creating new session (88963a1a79d7c6e6da2580cfd683912c)
DEBUG - 2015-01-17 15:49:32 --> CI_Session routines successfully run
DEBUG - 2015-01-17 15:49:32 --> User Agent Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Config Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:31:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:31:18 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:31:18 --> URI Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Router Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Output Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Security Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Input Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:31:18 --> Language Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Loader Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:31:18 --> Controller Class Initialized
DEBUG - 2015-01-17 18:31:18 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:31:18 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 18:31:18 --> Final output sent to browser
DEBUG - 2015-01-17 18:31:18 --> Total execution time: 0.0145
DEBUG - 2015-01-17 18:31:21 --> Config Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:31:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:31:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:31:21 --> URI Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Router Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Output Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Security Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Input Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:31:21 --> Language Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Loader Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:31:21 --> Controller Class Initialized
DEBUG - 2015-01-17 18:31:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:31:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 18:31:21 --> A session cookie was not found.
DEBUG - 2015-01-17 18:31:21 --> Session: Creating new session (8aa3b8852a112d10427c4e25af084814)
DEBUG - 2015-01-17 18:31:21 --> CI_Session routines successfully run
DEBUG - 2015-01-17 18:31:21 --> User Agent Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Config Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:32:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:32:16 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:32:16 --> URI Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Router Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Output Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Security Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Input Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:32:16 --> Language Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Loader Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:32:16 --> Controller Class Initialized
DEBUG - 2015-01-17 18:32:16 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:32:16 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 18:32:16 --> Final output sent to browser
DEBUG - 2015-01-17 18:32:16 --> Total execution time: 0.0150
DEBUG - 2015-01-17 18:36:21 --> Config Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:36:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:36:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:36:21 --> URI Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Router Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Output Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Security Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Input Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:36:21 --> Language Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Loader Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:36:21 --> Controller Class Initialized
DEBUG - 2015-01-17 18:36:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:36:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 18:36:21 --> CI_Session routines successfully run
DEBUG - 2015-01-17 18:36:21 --> User Agent Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Config Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:36:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:36:43 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:36:43 --> URI Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Router Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Output Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Security Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Input Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:36:43 --> Language Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Loader Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:36:43 --> Controller Class Initialized
DEBUG - 2015-01-17 18:36:43 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:36:43 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 18:36:43 --> Final output sent to browser
DEBUG - 2015-01-17 18:36:43 --> Total execution time: 0.0184
DEBUG - 2015-01-17 18:36:46 --> Config Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Hooks Class Initialized
DEBUG - 2015-01-17 18:36:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 18:36:46 --> Utf8 Class Initialized
DEBUG - 2015-01-17 18:36:46 --> URI Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Router Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Output Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Security Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Input Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 18:36:46 --> Language Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Loader Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Helper loaded: url_helper
DEBUG - 2015-01-17 18:36:46 --> Controller Class Initialized
DEBUG - 2015-01-17 18:36:46 --> Database Driver Class Initialized
DEBUG - 2015-01-17 18:36:46 --> CI_Session Class Initialized
DEBUG - 2015-01-17 18:36:46 --> CI_Session routines successfully run
DEBUG - 2015-01-17 18:36:46 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Config Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:03:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:03:01 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:03:01 --> URI Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Router Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Output Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Security Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Input Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:03:01 --> Language Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Loader Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:03:01 --> Controller Class Initialized
DEBUG - 2015-01-17 19:03:01 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:03:01 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:03:01 --> Final output sent to browser
DEBUG - 2015-01-17 19:03:01 --> Total execution time: 0.0040
DEBUG - 2015-01-17 19:03:03 --> Config Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:03:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:03:03 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:03:03 --> URI Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Router Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Output Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Security Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Input Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:03:03 --> Language Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Loader Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:03:03 --> Controller Class Initialized
DEBUG - 2015-01-17 19:03:03 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:03:03 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:03:03 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:03:03 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Config Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:03:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:03:44 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:03:44 --> URI Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Router Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Output Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Security Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Input Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:03:44 --> Language Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Loader Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:03:44 --> Controller Class Initialized
DEBUG - 2015-01-17 19:03:44 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:03:44 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:03:44 --> Final output sent to browser
DEBUG - 2015-01-17 19:03:44 --> Total execution time: 0.0060
DEBUG - 2015-01-17 19:05:18 --> Config Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:05:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:05:18 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:05:18 --> URI Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Router Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Output Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Security Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Input Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:05:18 --> Language Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Loader Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:05:18 --> Controller Class Initialized
DEBUG - 2015-01-17 19:05:18 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:05:18 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:05:18 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:05:18 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Config Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:08:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:08:49 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:08:49 --> URI Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Router Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Output Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Security Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Input Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:08:49 --> Language Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Loader Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:08:49 --> Controller Class Initialized
DEBUG - 2015-01-17 19:08:49 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:08:49 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:08:49 --> Final output sent to browser
DEBUG - 2015-01-17 19:08:49 --> Total execution time: 0.0094
DEBUG - 2015-01-17 19:08:51 --> Config Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:08:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:08:51 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:08:51 --> URI Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Router Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Output Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Security Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Input Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:08:51 --> Language Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Loader Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:08:51 --> Controller Class Initialized
DEBUG - 2015-01-17 19:08:51 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:08:51 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:08:51 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:08:51 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Config Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:09:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:09:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:09:21 --> URI Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Router Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Output Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Security Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Input Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:09:21 --> Language Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Loader Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:09:21 --> Controller Class Initialized
DEBUG - 2015-01-17 19:09:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:09:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:09:21 --> Final output sent to browser
DEBUG - 2015-01-17 19:09:21 --> Total execution time: 0.0056
DEBUG - 2015-01-17 19:10:30 --> Config Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:10:30 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:10:30 --> URI Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Router Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Output Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Security Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Input Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:10:30 --> Language Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Loader Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:10:30 --> Controller Class Initialized
DEBUG - 2015-01-17 19:10:30 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:10:30 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:10:30 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:10:30 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Config Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:10:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:10:43 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:10:43 --> URI Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Router Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Output Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Security Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Input Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:10:43 --> Language Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Loader Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:10:43 --> Controller Class Initialized
DEBUG - 2015-01-17 19:10:43 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:10:43 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:10:43 --> Final output sent to browser
DEBUG - 2015-01-17 19:10:43 --> Total execution time: 0.0158
DEBUG - 2015-01-17 19:10:46 --> Config Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:10:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:10:46 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:10:46 --> URI Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Router Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Output Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Security Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Input Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:10:46 --> Language Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Loader Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:10:46 --> Controller Class Initialized
DEBUG - 2015-01-17 19:10:46 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:10:46 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:10:46 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:10:46 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Config Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:11:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:11:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:11:07 --> URI Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Router Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Output Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Security Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Input Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:11:07 --> Language Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Loader Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:11:07 --> Controller Class Initialized
DEBUG - 2015-01-17 19:11:07 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:11:07 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:11:07 --> Final output sent to browser
DEBUG - 2015-01-17 19:11:07 --> Total execution time: 0.0075
DEBUG - 2015-01-17 19:11:09 --> Config Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:11:09 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:11:09 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:11:09 --> URI Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Router Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Output Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Security Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Input Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:11:09 --> Language Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Loader Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:11:09 --> Controller Class Initialized
DEBUG - 2015-01-17 19:11:09 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:11:09 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:11:09 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:11:09 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Config Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:25:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:25:39 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:25:39 --> URI Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Router Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Output Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Security Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Input Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:25:39 --> Language Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Loader Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:25:39 --> Controller Class Initialized
DEBUG - 2015-01-17 19:25:39 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:25:39 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:25:39 --> Final output sent to browser
DEBUG - 2015-01-17 19:25:39 --> Total execution time: 0.0057
DEBUG - 2015-01-17 19:25:41 --> Config Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:25:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:25:41 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:25:41 --> URI Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Router Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Output Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Security Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Input Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:25:41 --> Language Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Loader Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:25:41 --> Controller Class Initialized
DEBUG - 2015-01-17 19:25:41 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:25:41 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:25:41 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:26:02 --> Config Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:26:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:26:02 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:26:02 --> URI Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Router Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Output Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Security Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Input Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:26:02 --> Language Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Loader Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:26:02 --> Controller Class Initialized
DEBUG - 2015-01-17 19:26:02 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:26:02 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:26:02 --> Final output sent to browser
DEBUG - 2015-01-17 19:26:02 --> Total execution time: 0.0087
DEBUG - 2015-01-17 19:26:31 --> Config Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:26:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:26:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:26:31 --> URI Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Router Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Output Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Security Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Input Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:26:31 --> Language Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Loader Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:26:31 --> Controller Class Initialized
DEBUG - 2015-01-17 19:26:31 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:26:31 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:26:31 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:28:04 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:04 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:04 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:04 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:04 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:28:04 --> Final output sent to browser
DEBUG - 2015-01-17 19:28:04 --> Total execution time: 0.0061
DEBUG - 2015-01-17 19:28:06 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:06 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:06 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:06 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:06 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:06 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:06 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:28:06 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:28:19 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:19 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:19 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:19 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:19 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:19 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:19 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:28:19 --> Final output sent to browser
DEBUG - 2015-01-17 19:28:19 --> Total execution time: 0.0132
DEBUG - 2015-01-17 19:28:20 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:20 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:20 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:20 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:20 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:28:20 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:28:43 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:43 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:43 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:43 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:43 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:43 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:43 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:28:43 --> Final output sent to browser
DEBUG - 2015-01-17 19:28:43 --> Total execution time: 0.0060
DEBUG - 2015-01-17 19:28:45 --> Config Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:28:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:28:45 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:28:45 --> URI Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Router Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Output Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Security Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Input Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:28:45 --> Language Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Loader Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:28:45 --> Controller Class Initialized
DEBUG - 2015-01-17 19:28:45 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:28:45 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:28:45 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:31:24 --> Config Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:31:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:31:24 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:31:24 --> URI Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Router Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Output Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Security Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Input Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:31:24 --> Language Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Loader Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:31:24 --> Controller Class Initialized
DEBUG - 2015-01-17 19:31:24 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:31:24 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:31:24 --> Final output sent to browser
DEBUG - 2015-01-17 19:31:24 --> Total execution time: 0.0043
DEBUG - 2015-01-17 19:31:26 --> Config Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:31:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:31:26 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:31:26 --> URI Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Router Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Output Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Security Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Input Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:31:26 --> Language Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Loader Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:31:26 --> Controller Class Initialized
DEBUG - 2015-01-17 19:31:26 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:31:26 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:31:26 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:31:26 --> User Agent Class Initialized
ERROR - 2015-01-17 19:31:26 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523086, 'Moussa', 1)
DEBUG - 2015-01-17 19:32:15 --> Config Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:32:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:32:15 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:32:15 --> URI Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Router Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Output Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Security Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Input Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:32:15 --> Language Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Loader Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:32:15 --> Controller Class Initialized
DEBUG - 2015-01-17 19:32:15 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:32:15 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:32:15 --> Final output sent to browser
DEBUG - 2015-01-17 19:32:15 --> Total execution time: 0.0049
DEBUG - 2015-01-17 19:32:17 --> Config Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:32:17 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:32:17 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:32:17 --> URI Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Router Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Output Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Security Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Input Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:32:17 --> Language Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Loader Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:32:17 --> Controller Class Initialized
DEBUG - 2015-01-17 19:32:17 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:32:17 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:32:17 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:32:17 --> User Agent Class Initialized
ERROR - 2015-01-17 19:32:17 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523086, 'Moussa', 1)
DEBUG - 2015-01-17 19:32:50 --> Config Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:32:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:32:50 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:32:50 --> URI Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Router Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Output Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Security Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Input Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:32:50 --> Language Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Loader Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:32:50 --> Controller Class Initialized
DEBUG - 2015-01-17 19:32:50 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:32:50 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:32:50 --> Final output sent to browser
DEBUG - 2015-01-17 19:32:50 --> Total execution time: 0.0060
DEBUG - 2015-01-17 19:32:52 --> Config Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:32:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:32:52 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:32:52 --> URI Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Router Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Output Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Security Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Input Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:32:52 --> Language Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Loader Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:32:52 --> Controller Class Initialized
DEBUG - 2015-01-17 19:32:52 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:32:52 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:32:52 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:32:52 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Config Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:37:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:37:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:37:20 --> URI Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Router Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Output Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Security Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Input Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:37:20 --> Language Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Loader Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:37:20 --> Controller Class Initialized
DEBUG - 2015-01-17 19:37:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:37:20 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:37:20 --> Final output sent to browser
DEBUG - 2015-01-17 19:37:20 --> Total execution time: 0.0049
DEBUG - 2015-01-17 19:37:21 --> Config Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:37:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:37:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:37:21 --> URI Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Router Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Output Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Security Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Input Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:37:21 --> Language Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Loader Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:37:21 --> Controller Class Initialized
DEBUG - 2015-01-17 19:37:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:37:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:37:21 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:37:21 --> User Agent Class Initialized
ERROR - 2015-01-17 19:37:21 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523441, 'Moussa', 1)
DEBUG - 2015-01-17 19:38:24 --> Config Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:38:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:38:24 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:38:24 --> URI Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Router Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Output Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Security Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Input Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:38:24 --> Language Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Loader Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:38:24 --> Controller Class Initialized
DEBUG - 2015-01-17 19:38:24 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:38:24 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:38:24 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:38:24 --> Final output sent to browser
DEBUG - 2015-01-17 19:38:24 --> Total execution time: 0.0292
DEBUG - 2015-01-17 19:38:27 --> Config Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:38:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:38:27 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:38:27 --> URI Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Router Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Output Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Security Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Input Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:38:27 --> Language Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Loader Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:38:27 --> Controller Class Initialized
DEBUG - 2015-01-17 19:38:27 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:38:27 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:38:27 --> Final output sent to browser
DEBUG - 2015-01-17 19:38:27 --> Total execution time: 0.0072
DEBUG - 2015-01-17 19:38:29 --> Config Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:38:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:38:29 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:38:29 --> URI Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Router Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Output Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Security Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Input Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:38:29 --> Language Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Loader Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:38:29 --> Controller Class Initialized
DEBUG - 2015-01-17 19:38:29 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:38:29 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:38:29 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:38:29 --> User Agent Class Initialized
ERROR - 2015-01-17 19:38:29 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523441, 'Moussa', '1')
DEBUG - 2015-01-17 19:38:53 --> Config Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:38:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:38:53 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:38:53 --> URI Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Router Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Output Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Security Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Input Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:38:53 --> Language Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Loader Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:38:53 --> Controller Class Initialized
DEBUG - 2015-01-17 19:38:53 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:38:53 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:38:53 --> Final output sent to browser
DEBUG - 2015-01-17 19:38:53 --> Total execution time: 0.0050
DEBUG - 2015-01-17 19:38:57 --> Config Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:38:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:38:57 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:38:57 --> URI Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Router Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Output Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Security Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Input Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:38:57 --> Language Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Loader Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:38:57 --> Controller Class Initialized
DEBUG - 2015-01-17 19:38:57 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:38:57 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:38:57 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:38:57 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Config Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:41:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:41:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:41:47 --> URI Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Router Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Output Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Security Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Input Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:41:47 --> Language Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Loader Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:41:47 --> Controller Class Initialized
DEBUG - 2015-01-17 19:41:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:41:47 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:41:47 --> Final output sent to browser
DEBUG - 2015-01-17 19:41:47 --> Total execution time: 0.0059
DEBUG - 2015-01-17 19:42:19 --> Config Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:42:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:42:19 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:42:19 --> URI Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Router Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Output Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Security Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Input Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:42:19 --> Language Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Loader Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:42:19 --> Controller Class Initialized
DEBUG - 2015-01-17 19:42:19 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:42:19 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:42:19 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:42:19 --> User Agent Class Initialized
ERROR - 2015-01-17 19:42:19 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523441, 'Moussa', 0)
DEBUG - 2015-01-17 19:43:59 --> Config Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:43:59 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:43:59 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:43:59 --> URI Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Router Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Output Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Security Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Input Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:43:59 --> Language Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Loader Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:43:59 --> Controller Class Initialized
DEBUG - 2015-01-17 19:43:59 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:43:59 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:43:59 --> Final output sent to browser
DEBUG - 2015-01-17 19:43:59 --> Total execution time: 0.0127
DEBUG - 2015-01-17 19:44:00 --> Config Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:44:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:44:00 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:44:00 --> URI Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Router Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Output Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Security Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Input Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:44:00 --> Language Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Loader Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:44:00 --> Controller Class Initialized
DEBUG - 2015-01-17 19:44:00 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:44:00 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:44:00 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:44:00 --> User Agent Class Initialized
ERROR - 2015-01-17 19:44:00 --> Query error: Unknown column 'prize' in 'field list' - Invalid query: INSERT INTO `users_session` (`session_id`, `ip_address`, `user_agent`, `last_activity`, `username`, `prize`) VALUES ('8aa3b8852a112d10427c4e25af084814', '127.0.0.1', 'Mozilla/5.0 (X11; Ubuntu; Linux i686; rv:34.0) Gecko/20100101 Firefox/34.0', 1421523840, 'Moussa', 0)
DEBUG - 2015-01-17 19:44:25 --> Config Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:44:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:44:25 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:44:25 --> URI Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Router Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Output Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Security Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Input Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:44:25 --> Language Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Loader Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:44:25 --> Controller Class Initialized
DEBUG - 2015-01-17 19:44:25 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:44:25 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:44:25 --> Final output sent to browser
DEBUG - 2015-01-17 19:44:25 --> Total execution time: 0.0040
DEBUG - 2015-01-17 19:44:31 --> Config Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:44:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:44:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:44:31 --> URI Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Router Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Output Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Security Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Input Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:44:31 --> Language Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Loader Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:44:31 --> Controller Class Initialized
DEBUG - 2015-01-17 19:44:31 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:44:31 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:44:31 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:44:31 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Config Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:45:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:45:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:45:31 --> URI Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Router Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Output Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Security Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Input Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:45:31 --> Language Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Loader Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:45:31 --> Controller Class Initialized
DEBUG - 2015-01-17 19:45:31 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:45:31 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:45:31 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:45:31 --> Final output sent to browser
DEBUG - 2015-01-17 19:45:31 --> Total execution time: 0.0139
DEBUG - 2015-01-17 19:45:34 --> Config Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:45:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:45:34 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:45:34 --> URI Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Router Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Output Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Security Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Input Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:45:34 --> Language Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Loader Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:45:34 --> Controller Class Initialized
DEBUG - 2015-01-17 19:45:34 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:45:34 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:45:34 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:45:34 --> Final output sent to browser
DEBUG - 2015-01-17 19:45:34 --> Total execution time: 0.0063
DEBUG - 2015-01-17 19:45:42 --> Config Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:45:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:45:42 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:45:42 --> URI Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Router Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Output Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Security Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Input Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:45:42 --> Language Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Loader Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:45:42 --> Controller Class Initialized
DEBUG - 2015-01-17 19:45:42 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:45:42 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:45:42 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:45:42 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:13 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:13 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:13 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:13 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:13 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:13 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 19:47:13 --> Final output sent to browser
DEBUG - 2015-01-17 19:47:13 --> Total execution time: 0.0105
DEBUG - 2015-01-17 19:47:16 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:16 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:16 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:16 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:16 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:16 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:16 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:47:16 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:47:16 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:32 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:32 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:32 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:32 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:32 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:32 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:47:32 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:47:32 --> Final output sent to browser
DEBUG - 2015-01-17 19:47:32 --> Total execution time: 0.0130
DEBUG - 2015-01-17 19:47:40 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:40 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:40 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:40 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:40 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:40 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:40 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:47:40 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:47:40 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:51 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:51 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:51 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:51 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:51 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:51 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:47:51 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:47:51 --> Final output sent to browser
DEBUG - 2015-01-17 19:47:51 --> Total execution time: 0.0128
DEBUG - 2015-01-17 19:47:54 --> Config Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:47:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:47:54 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:47:54 --> URI Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Router Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Output Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Security Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Input Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:47:54 --> Language Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Loader Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:47:54 --> Controller Class Initialized
DEBUG - 2015-01-17 19:47:54 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:47:54 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:47:54 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:47:54 --> Final output sent to browser
DEBUG - 2015-01-17 19:47:54 --> Total execution time: 0.0070
DEBUG - 2015-01-17 19:49:07 --> Config Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:49:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:49:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:49:07 --> URI Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Router Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Output Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Security Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Input Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:49:07 --> Language Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Loader Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:49:07 --> Controller Class Initialized
DEBUG - 2015-01-17 19:49:07 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:49:07 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:49:07 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:49:07 --> Final output sent to browser
DEBUG - 2015-01-17 19:49:07 --> Total execution time: 0.0160
DEBUG - 2015-01-17 19:50:24 --> Config Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:50:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:50:24 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:50:24 --> URI Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Router Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Output Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Security Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Input Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:50:24 --> Language Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Loader Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:50:24 --> Controller Class Initialized
DEBUG - 2015-01-17 19:50:24 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:50:24 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:50:24 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:50:24 --> Final output sent to browser
DEBUG - 2015-01-17 19:50:24 --> Total execution time: 0.0086
DEBUG - 2015-01-17 19:50:32 --> Config Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:50:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:50:32 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:50:32 --> URI Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Router Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Output Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Security Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Input Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:50:32 --> Language Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Loader Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:50:32 --> Controller Class Initialized
DEBUG - 2015-01-17 19:50:32 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:50:32 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:50:32 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:50:32 --> Final output sent to browser
DEBUG - 2015-01-17 19:50:32 --> Total execution time: 0.0175
DEBUG - 2015-01-17 19:50:34 --> Config Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:50:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:50:34 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:50:34 --> URI Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Router Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Output Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Security Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Input Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:50:34 --> Language Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Loader Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:50:34 --> Controller Class Initialized
DEBUG - 2015-01-17 19:50:34 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:50:34 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:50:34 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:50:34 --> User Agent Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Config Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 19:50:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 19:50:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 19:50:55 --> URI Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Router Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Output Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Security Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Input Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 19:50:55 --> Language Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Loader Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 19:50:55 --> Controller Class Initialized
DEBUG - 2015-01-17 19:50:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 19:50:55 --> CI_Session Class Initialized
DEBUG - 2015-01-17 19:50:55 --> CI_Session routines successfully run
DEBUG - 2015-01-17 19:50:55 --> Final output sent to browser
DEBUG - 2015-01-17 19:50:55 --> Total execution time: 0.0119
DEBUG - 2015-01-17 20:11:53 --> Config Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:11:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:11:53 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:11:53 --> URI Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Router Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Output Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Security Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Input Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:11:53 --> Language Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Loader Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Helper loaded: url_helper
DEBUG - 2015-01-17 20:11:53 --> Controller Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Database Driver Class Initialized
DEBUG - 2015-01-17 20:11:53 --> CI_Session Class Initialized
DEBUG - 2015-01-17 20:11:53 --> Session: Regenerate ID
DEBUG - 2015-01-17 20:11:53 --> CI_Session routines successfully run
DEBUG - 2015-01-17 20:11:53 --> User Agent Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Config Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:51:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:51:05 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:51:05 --> URI Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Router Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Output Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Security Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Input Class Initialized
DEBUG - 2015-01-17 20:51:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:51:05 --> Language Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Config Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:51:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:51:56 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:51:56 --> URI Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Router Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Output Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Security Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Input Class Initialized
DEBUG - 2015-01-17 20:51:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:51:56 --> Language Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Config Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:52:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:52:49 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:52:49 --> URI Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Router Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Output Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Security Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Input Class Initialized
DEBUG - 2015-01-17 20:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:52:49 --> Language Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Config Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:54:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:54:13 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:54:13 --> URI Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Router Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Output Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Security Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Input Class Initialized
DEBUG - 2015-01-17 20:54:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:54:13 --> Language Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Config Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:57:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:57:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:57:55 --> URI Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Router Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Output Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Security Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Input Class Initialized
DEBUG - 2015-01-17 20:57:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:57:55 --> Language Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Config Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:57:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:57:56 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:57:56 --> URI Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Router Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Output Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Security Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Input Class Initialized
DEBUG - 2015-01-17 20:57:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:57:56 --> Language Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Config Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:58:56 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:58:56 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:58:56 --> URI Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Router Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Output Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Security Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Input Class Initialized
DEBUG - 2015-01-17 20:58:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:58:56 --> Language Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Config Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 20:59:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 20:59:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 20:59:07 --> URI Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Router Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Output Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Security Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Input Class Initialized
DEBUG - 2015-01-17 20:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 20:59:07 --> Language Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Config Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:00:28 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:00:28 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:00:28 --> URI Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Router Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Output Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Security Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Input Class Initialized
DEBUG - 2015-01-17 21:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:00:28 --> Language Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Config Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:00:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:00:54 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:00:54 --> URI Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Router Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Output Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Security Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Input Class Initialized
DEBUG - 2015-01-17 21:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:00:54 --> Language Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Config Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:02:30 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:02:30 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:02:30 --> URI Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Router Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Output Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Security Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Input Class Initialized
DEBUG - 2015-01-17 21:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:02:30 --> Language Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Config Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:02:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:02:31 --> URI Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Router Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Output Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Security Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Input Class Initialized
DEBUG - 2015-01-17 21:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:02:31 --> Language Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Config Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:02:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:02:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:02:55 --> URI Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Router Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Output Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Security Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Input Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:02:55 --> Language Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Loader Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:02:55 --> Controller Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:02:55 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:02:55 --> Session: Regenerate ID
DEBUG - 2015-01-17 21:02:55 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:02:55 --> Final output sent to browser
DEBUG - 2015-01-17 21:02:55 --> Total execution time: 0.0057
DEBUG - 2015-01-17 21:04:01 --> Config Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:04:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:04:01 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:04:01 --> URI Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Router Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Output Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Security Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Input Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:04:01 --> Language Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Loader Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:04:01 --> Controller Class Initialized
DEBUG - 2015-01-17 21:04:01 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:04:01 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:04:01 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:04:01 --> Final output sent to browser
DEBUG - 2015-01-17 21:04:01 --> Total execution time: 0.0085
DEBUG - 2015-01-17 21:04:12 --> Config Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:04:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:04:12 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:04:12 --> URI Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Router Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Output Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Security Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Input Class Initialized
DEBUG - 2015-01-17 21:04:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:04:12 --> Language Class Initialized
DEBUG - 2015-01-17 21:04:13 --> Loader Class Initialized
DEBUG - 2015-01-17 21:04:13 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:04:13 --> Controller Class Initialized
DEBUG - 2015-01-17 21:04:13 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:04:13 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:04:13 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:04:13 --> Final output sent to browser
DEBUG - 2015-01-17 21:04:13 --> Total execution time: 0.0042
DEBUG - 2015-01-17 21:04:26 --> Config Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:04:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:04:26 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:04:26 --> URI Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Router Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Output Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Security Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Input Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:04:26 --> Language Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Loader Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:04:26 --> Controller Class Initialized
DEBUG - 2015-01-17 21:04:26 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:04:26 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:04:26 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:04:26 --> Final output sent to browser
DEBUG - 2015-01-17 21:04:26 --> Total execution time: 0.0096
DEBUG - 2015-01-17 21:05:13 --> Config Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:05:13 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:05:13 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:05:13 --> URI Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Router Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Output Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Security Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Input Class Initialized
DEBUG - 2015-01-17 21:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:05:13 --> Language Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Config Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:05:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:05:34 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:05:34 --> URI Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Router Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Output Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Security Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Input Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:05:34 --> Language Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Loader Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:05:34 --> Controller Class Initialized
DEBUG - 2015-01-17 21:05:34 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:05:34 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:05:34 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:05:34 --> Final output sent to browser
DEBUG - 2015-01-17 21:05:34 --> Total execution time: 0.0056
DEBUG - 2015-01-17 21:15:03 --> Config Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:15:03 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:15:03 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:15:03 --> URI Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Router Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Output Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Security Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Input Class Initialized
DEBUG - 2015-01-17 21:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:15:03 --> Language Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Config Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:15:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:15:50 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:15:50 --> URI Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Router Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Output Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Security Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Input Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:15:50 --> Language Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Loader Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:15:50 --> Controller Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:15:50 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:15:50 --> Session: Regenerate ID
DEBUG - 2015-01-17 21:15:50 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:16:51 --> Config Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:16:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:16:51 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:16:51 --> URI Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Router Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Output Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Security Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Input Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:16:51 --> Language Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Loader Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:16:51 --> Controller Class Initialized
DEBUG - 2015-01-17 21:16:51 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:16:51 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:16:51 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:17:47 --> Config Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:17:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:17:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:17:47 --> URI Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Router Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Output Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Security Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Input Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:17:47 --> Language Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Loader Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:17:47 --> Controller Class Initialized
DEBUG - 2015-01-17 21:17:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:17:47 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:17:47 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:18:27 --> Config Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:18:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:18:27 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:18:27 --> URI Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Router Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Output Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Security Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Input Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:18:27 --> Language Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Loader Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:18:27 --> Controller Class Initialized
DEBUG - 2015-01-17 21:18:27 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:18:27 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:18:27 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:19:08 --> Config Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:19:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:19:08 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:19:08 --> URI Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Router Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Output Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Security Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Input Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:19:08 --> Language Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Loader Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:19:08 --> Controller Class Initialized
DEBUG - 2015-01-17 21:19:08 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:19:08 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:19:08 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:20:05 --> Config Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:20:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:20:05 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:20:05 --> URI Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Router Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Output Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Security Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Input Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:20:05 --> Language Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Loader Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:20:05 --> Controller Class Initialized
DEBUG - 2015-01-17 21:20:05 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:20:05 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:20:05 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:20:19 --> Config Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:20:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:20:19 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:20:19 --> URI Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Router Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Output Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Security Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Input Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:20:19 --> Language Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Loader Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:20:19 --> Controller Class Initialized
DEBUG - 2015-01-17 21:20:19 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:20:19 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:20:19 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:20:47 --> Config Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:20:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:20:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:20:47 --> URI Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Router Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Output Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Security Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Input Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:20:47 --> Language Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Loader Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:20:47 --> Controller Class Initialized
DEBUG - 2015-01-17 21:20:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:20:47 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:20:47 --> CI_Session routines successfully run
DEBUG - 2015-01-17 21:47:20 --> Config Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 21:47:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 21:47:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 21:47:20 --> URI Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Router Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Output Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Security Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Input Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 21:47:20 --> Language Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Loader Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 21:47:20 --> Controller Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 21:47:20 --> CI_Session Class Initialized
DEBUG - 2015-01-17 21:47:20 --> Session: Regenerate ID
DEBUG - 2015-01-17 21:47:20 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:02:23 --> Config Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:02:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:02:23 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:02:23 --> URI Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Router Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Output Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Security Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Input Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:02:23 --> Language Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Loader Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:02:23 --> Controller Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:02:23 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:02:23 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:02:23 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:04:53 --> Config Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:04:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:04:53 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:04:53 --> URI Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Router Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Output Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Security Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Input Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:04:53 --> Language Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Loader Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:04:53 --> Controller Class Initialized
DEBUG - 2015-01-17 22:04:53 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:04:53 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:04:53 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:07:47 --> Config Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:07:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:07:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:07:47 --> URI Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Router Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Output Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Security Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Input Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:07:47 --> Language Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Loader Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:07:47 --> Controller Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:07:47 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:07:47 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:07:47 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:08:01 --> Config Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:08:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:08:01 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:08:01 --> URI Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Router Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Output Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Security Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Input Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:08:01 --> Language Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Loader Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:08:01 --> Controller Class Initialized
DEBUG - 2015-01-17 22:08:01 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:08:01 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:08:01 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:08:21 --> Config Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:08:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:08:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:08:21 --> URI Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Router Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Output Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Security Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Input Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:08:21 --> Language Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Loader Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:08:21 --> Controller Class Initialized
DEBUG - 2015-01-17 22:08:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:08:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:08:21 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:08:21 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:08:41 --> Config Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:08:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:08:41 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:08:41 --> URI Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Router Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Output Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Security Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Input Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:08:41 --> Language Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Loader Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:08:41 --> Controller Class Initialized
DEBUG - 2015-01-17 22:08:41 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:08:41 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:08:41 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:08:41 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:08:50 --> Config Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:08:50 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:08:50 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:08:50 --> URI Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Router Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Output Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Security Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Input Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:08:50 --> Language Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Loader Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:08:50 --> Controller Class Initialized
DEBUG - 2015-01-17 22:08:50 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:08:50 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:08:50 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:08:50 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:09:32 --> Config Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:09:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:09:32 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:09:32 --> URI Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Router Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Output Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Security Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Input Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:09:32 --> Language Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Loader Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:09:32 --> Controller Class Initialized
DEBUG - 2015-01-17 22:09:32 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:09:32 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:09:32 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:09:32 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:10:39 --> Config Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:10:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:10:39 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:10:39 --> URI Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Router Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Output Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Security Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Input Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:10:39 --> Language Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Loader Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:10:39 --> Controller Class Initialized
DEBUG - 2015-01-17 22:10:39 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:10:39 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:10:39 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:10:39 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:11:06 --> Config Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:11:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:11:06 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:11:06 --> URI Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Router Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Output Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Security Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Input Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:11:06 --> Language Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Loader Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:11:06 --> Controller Class Initialized
DEBUG - 2015-01-17 22:11:06 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:11:06 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:11:06 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:11:06 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:11:27 --> Config Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:11:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:11:27 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:11:27 --> URI Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Router Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Output Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Security Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Input Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:11:27 --> Language Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Loader Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:11:27 --> Controller Class Initialized
DEBUG - 2015-01-17 22:11:27 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:11:27 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:11:27 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:11:27 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:12:29 --> Config Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:12:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:12:29 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:12:29 --> URI Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Router Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Output Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Security Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Input Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:12:29 --> Language Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Loader Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:12:29 --> Controller Class Initialized
DEBUG - 2015-01-17 22:12:29 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:12:29 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:12:29 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:12:29 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:13:24 --> Config Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:13:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:13:24 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:13:24 --> URI Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Router Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Output Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Security Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Input Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:13:24 --> Language Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Loader Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:13:24 --> Controller Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:13:24 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:13:24 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:13:24 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:13:24 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:42 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:42 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:42 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:42 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:42 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:42 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:42 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:42 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:42 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:42 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:42 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:42 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:42 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:42 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:42 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:42 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:42 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:44 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:44 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:44 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:44 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:44 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:44 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:44 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:44 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:44 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:44 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:45 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:45 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:45 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:45 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:45 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:45 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:45 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:45 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:45 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:46 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:46 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:46 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:46 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:46 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:46 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:46 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:46 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:46 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:54 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:54 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:54 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:54 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:54 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:54 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:54 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:54 --> A session cookie was not found.
DEBUG - 2015-01-17 22:14:54 --> Session: Creating new session (79eb5ed0d4acbce73d759b94991ca8e4)
DEBUG - 2015-01-17 22:14:54 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:54 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:14:57 --> Config Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:14:57 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:14:57 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:14:57 --> URI Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Router Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Output Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Security Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Input Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:14:57 --> Language Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Loader Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:14:57 --> Controller Class Initialized
DEBUG - 2015-01-17 22:14:57 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:14:57 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:14:57 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:14:57 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:16:02 --> Config Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:16:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:16:02 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:16:02 --> URI Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Router Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Output Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Security Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Input Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:16:02 --> Language Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Loader Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:16:02 --> Controller Class Initialized
DEBUG - 2015-01-17 22:16:02 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:16:02 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:16:02 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:16:02 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:16:39 --> Config Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:16:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:16:39 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:16:39 --> URI Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Router Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Output Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Security Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Input Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:16:39 --> Language Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Loader Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:16:39 --> Controller Class Initialized
DEBUG - 2015-01-17 22:16:39 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:16:39 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:16:39 --> CI_Session routines successfully run
ERROR - 2015-01-17 22:16:39 --> Query error: Table 'Lemilionaire.QuestiionsAnswers' doesn't exist - Invalid query: SELECT `Answer`
FROM `QuestiionsAnswers`
WHERE `id` = '467'
DEBUG - 2015-01-17 22:17:25 --> Config Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:17:25 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:17:25 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:17:25 --> URI Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Router Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Output Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Security Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Input Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:17:25 --> Language Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Loader Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:17:25 --> Controller Class Initialized
DEBUG - 2015-01-17 22:17:25 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:17:25 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:17:25 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:17:25 --> Final output sent to browser
DEBUG - 2015-01-17 22:17:25 --> Total execution time: 0.0409
DEBUG - 2015-01-17 22:23:04 --> Config Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:23:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:23:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:23:04 --> URI Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Router Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Output Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Security Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Input Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:23:04 --> Language Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Loader Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:23:04 --> Controller Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:23:04 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:23:04 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:23:04 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:23:04 --> Final output sent to browser
DEBUG - 2015-01-17 22:23:04 --> Total execution time: 0.0120
DEBUG - 2015-01-17 22:27:23 --> Config Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:27:23 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:27:23 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:27:23 --> URI Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Router Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Output Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Security Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Input Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:27:23 --> Language Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Loader Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:27:23 --> Controller Class Initialized
DEBUG - 2015-01-17 22:27:23 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:27:23 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:27:23 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:27:23 --> Final output sent to browser
DEBUG - 2015-01-17 22:27:23 --> Total execution time: 0.0086
DEBUG - 2015-01-17 22:28:21 --> Config Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:28:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:28:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:28:21 --> URI Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Router Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Output Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Security Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Input Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:28:21 --> Language Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Loader Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:28:21 --> Controller Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:28:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:28:21 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:28:21 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:28:21 --> Final output sent to browser
DEBUG - 2015-01-17 22:28:21 --> Total execution time: 0.0105
DEBUG - 2015-01-17 22:35:20 --> Config Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:35:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:35:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:35:20 --> URI Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Router Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Output Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Security Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Input Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:35:20 --> Language Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Loader Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:35:20 --> Controller Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:35:20 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:35:20 --> Session: Regenerate ID
DEBUG - 2015-01-17 22:35:20 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:35:20 --> Final output sent to browser
DEBUG - 2015-01-17 22:35:20 --> Total execution time: 0.0120
DEBUG - 2015-01-17 22:40:05 --> Config Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:40:05 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:40:05 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:40:05 --> URI Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Router Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Output Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Security Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Input Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:40:05 --> Language Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Loader Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:40:05 --> Controller Class Initialized
DEBUG - 2015-01-17 22:40:05 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:40:05 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 22:40:05 --> Final output sent to browser
DEBUG - 2015-01-17 22:40:05 --> Total execution time: 0.0043
DEBUG - 2015-01-17 22:40:12 --> Config Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:40:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:40:12 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:40:12 --> URI Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Router Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Output Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Security Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Input Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:40:12 --> Language Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Loader Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:40:12 --> Controller Class Initialized
DEBUG - 2015-01-17 22:40:12 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:40:12 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:40:12 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:40:12 --> User Agent Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Config Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:46:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:46:36 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:46:36 --> URI Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Router Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Output Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Security Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Input Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:46:36 --> Language Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Loader Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:46:36 --> Controller Class Initialized
DEBUG - 2015-01-17 22:46:36 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:46:36 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 22:46:36 --> Final output sent to browser
DEBUG - 2015-01-17 22:46:36 --> Total execution time: 0.0076
DEBUG - 2015-01-17 22:46:38 --> Config Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:46:38 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:46:38 --> URI Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Router Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Output Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Security Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Input Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:46:38 --> Language Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Loader Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:46:38 --> Controller Class Initialized
DEBUG - 2015-01-17 22:46:38 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:46:38 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:46:38 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:46:38 --> User Agent Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Config Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:53:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:53:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:53:31 --> URI Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Router Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Output Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Security Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Input Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:53:31 --> Language Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Loader Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:53:31 --> Controller Class Initialized
DEBUG - 2015-01-17 22:53:31 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:53:31 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:53:31 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:53:31 --> Final output sent to browser
DEBUG - 2015-01-17 22:53:31 --> Total execution time: 0.0084
DEBUG - 2015-01-17 22:53:34 --> Config Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Hooks Class Initialized
DEBUG - 2015-01-17 22:53:34 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 22:53:34 --> Utf8 Class Initialized
DEBUG - 2015-01-17 22:53:34 --> URI Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Router Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Output Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Security Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Input Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 22:53:34 --> Language Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Loader Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Helper loaded: url_helper
DEBUG - 2015-01-17 22:53:34 --> Controller Class Initialized
DEBUG - 2015-01-17 22:53:34 --> Database Driver Class Initialized
DEBUG - 2015-01-17 22:53:34 --> CI_Session Class Initialized
DEBUG - 2015-01-17 22:53:34 --> CI_Session routines successfully run
DEBUG - 2015-01-17 22:53:34 --> Final output sent to browser
DEBUG - 2015-01-17 22:53:34 --> Total execution time: 0.0125
DEBUG - 2015-01-17 23:02:54 --> Config Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:02:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:02:54 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:02:54 --> URI Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Router Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Output Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Security Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Input Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:02:54 --> Language Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Loader Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:02:54 --> Controller Class Initialized
DEBUG - 2015-01-17 23:02:54 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:02:54 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:02:54 --> Final output sent to browser
DEBUG - 2015-01-17 23:02:54 --> Total execution time: 0.0044
DEBUG - 2015-01-17 23:03:02 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:02 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:02 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:02 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:02 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:02 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:02 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:02 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:02 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:07 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:07 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:07 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:07 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:07 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:07 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:07 --> Final output sent to browser
DEBUG - 2015-01-17 23:03:07 --> Total execution time: 0.0231
DEBUG - 2015-01-17 23:03:11 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:11 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:11 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:11 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:11 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:11 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:11 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:11 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:11 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:11 --> Final output sent to browser
DEBUG - 2015-01-17 23:03:11 --> Total execution time: 0.0101
DEBUG - 2015-01-17 23:03:14 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:14 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:14 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:14 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:14 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:14 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:14 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:14 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:14 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:14 --> Final output sent to browser
DEBUG - 2015-01-17 23:03:14 --> Total execution time: 0.0068
DEBUG - 2015-01-17 23:03:18 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:18 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:18 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:18 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:18 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:18 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:18 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:18 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:18 --> Final output sent to browser
DEBUG - 2015-01-17 23:03:18 --> Total execution time: 0.0075
DEBUG - 2015-01-17 23:03:20 --> Config Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:03:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:03:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:03:20 --> URI Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Router Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Output Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Security Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Input Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:03:20 --> Language Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Loader Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:03:20 --> Controller Class Initialized
DEBUG - 2015-01-17 23:03:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:03:20 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:03:20 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:03:20 --> Final output sent to browser
DEBUG - 2015-01-17 23:03:20 --> Total execution time: 0.0083
DEBUG - 2015-01-17 23:06:04 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:04 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:04 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:04 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:04 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:06:04 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:04 --> Total execution time: 0.0120
DEBUG - 2015-01-17 23:06:08 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:08 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:08 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:08 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:08 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:08 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:08 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:08 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:08 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:21 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:21 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:21 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:21 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:21 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:21 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:21 --> Total execution time: 0.0087
DEBUG - 2015-01-17 23:06:24 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:24 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:24 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:24 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:24 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:24 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:24 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:24 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:24 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:24 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:24 --> Total execution time: 0.0070
DEBUG - 2015-01-17 23:06:27 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:27 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:27 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:27 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:27 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:27 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:27 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:27 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:27 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:27 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:27 --> Total execution time: 0.0067
DEBUG - 2015-01-17 23:06:29 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:29 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:29 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:29 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:29 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:29 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:29 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:29 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:30 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:30 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:30 --> Total execution time: 0.0061
DEBUG - 2015-01-17 23:06:32 --> Config Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:06:32 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:06:32 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:06:32 --> URI Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Router Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Output Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Security Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Input Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:06:32 --> Language Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Loader Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:06:32 --> Controller Class Initialized
DEBUG - 2015-01-17 23:06:32 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:06:32 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:06:32 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:06:32 --> Final output sent to browser
DEBUG - 2015-01-17 23:06:32 --> Total execution time: 0.0090
DEBUG - 2015-01-17 23:08:37 --> Config Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:08:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:08:37 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:08:37 --> URI Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Router Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Output Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Security Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Input Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:08:37 --> Language Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Loader Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:08:37 --> Controller Class Initialized
DEBUG - 2015-01-17 23:08:37 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:08:37 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:08:37 --> Final output sent to browser
DEBUG - 2015-01-17 23:08:37 --> Total execution time: 0.0037
DEBUG - 2015-01-17 23:08:39 --> Config Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:08:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:08:39 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:08:39 --> URI Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Router Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Output Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Security Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Input Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:08:39 --> Language Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Loader Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:08:39 --> Controller Class Initialized
DEBUG - 2015-01-17 23:08:39 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:08:39 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:08:39 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:08:39 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Config Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:08:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:08:45 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:08:45 --> URI Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Router Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Output Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Security Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Input Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:08:45 --> Language Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Loader Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:08:45 --> Controller Class Initialized
DEBUG - 2015-01-17 23:08:45 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:08:45 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:08:45 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:08:45 --> Final output sent to browser
DEBUG - 2015-01-17 23:08:45 --> Total execution time: 0.0125
DEBUG - 2015-01-17 23:08:47 --> Config Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:08:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:08:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:08:47 --> URI Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Router Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Output Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Security Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Input Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:08:47 --> Language Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Loader Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:08:47 --> Controller Class Initialized
DEBUG - 2015-01-17 23:08:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:08:47 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:08:47 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:08:47 --> Final output sent to browser
DEBUG - 2015-01-17 23:08:47 --> Total execution time: 0.0141
DEBUG - 2015-01-17 23:09:19 --> Config Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:09:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:09:19 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:09:19 --> URI Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Router Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Output Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Security Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Input Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:09:19 --> Language Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Loader Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:09:19 --> Controller Class Initialized
DEBUG - 2015-01-17 23:09:19 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:09:19 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:09:19 --> Final output sent to browser
DEBUG - 2015-01-17 23:09:19 --> Total execution time: 0.0064
DEBUG - 2015-01-17 23:09:22 --> Config Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:09:22 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:09:22 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:09:22 --> URI Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Router Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Output Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Security Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Input Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:09:22 --> Language Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Loader Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:09:22 --> Controller Class Initialized
DEBUG - 2015-01-17 23:09:22 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:09:22 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:09:22 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:09:22 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Config Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:09:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:09:37 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:09:37 --> URI Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Router Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Output Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Security Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Input Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:09:37 --> Language Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Loader Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:09:37 --> Controller Class Initialized
DEBUG - 2015-01-17 23:09:37 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:09:37 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:09:37 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:09:37 --> Final output sent to browser
DEBUG - 2015-01-17 23:09:37 --> Total execution time: 0.0110
DEBUG - 2015-01-17 23:09:47 --> Config Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:09:47 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:09:47 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:09:47 --> URI Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Router Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Output Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Security Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Input Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:09:47 --> Language Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Loader Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:09:47 --> Controller Class Initialized
DEBUG - 2015-01-17 23:09:47 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:09:47 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:09:47 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:09:47 --> Final output sent to browser
DEBUG - 2015-01-17 23:09:47 --> Total execution time: 0.0108
DEBUG - 2015-01-17 23:09:54 --> Config Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:09:54 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:09:54 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:09:54 --> URI Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Router Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Output Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Security Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Input Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:09:54 --> Language Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Loader Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:09:54 --> Controller Class Initialized
DEBUG - 2015-01-17 23:09:54 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:09:54 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:09:54 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:09:54 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:07 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:07 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:07 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:07 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:07 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:10:07 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:10:07 --> Final output sent to browser
DEBUG - 2015-01-17 23:10:07 --> Total execution time: 0.1051
DEBUG - 2015-01-17 23:10:12 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:12 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:12 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:12 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:12 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:12 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:12 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:12 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:10:12 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:10:12 --> Final output sent to browser
DEBUG - 2015-01-17 23:10:12 --> Total execution time: 0.0075
DEBUG - 2015-01-17 23:10:15 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:15 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:15 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:15 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:15 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:15 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:15 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:15 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:10:15 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:10:15 --> Final output sent to browser
DEBUG - 2015-01-17 23:10:15 --> Total execution time: 0.0063
DEBUG - 2015-01-17 23:10:18 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:18 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:18 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:18 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:18 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:18 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:18 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:10:18 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:10:18 --> Final output sent to browser
DEBUG - 2015-01-17 23:10:18 --> Total execution time: 0.0125
DEBUG - 2015-01-17 23:10:37 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:37 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:37 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:37 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:37 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:37 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:37 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:37 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:10:37 --> Final output sent to browser
DEBUG - 2015-01-17 23:10:37 --> Total execution time: 0.0052
DEBUG - 2015-01-17 23:10:39 --> Config Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:10:39 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:10:39 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:10:39 --> URI Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Router Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Output Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Security Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Input Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:10:39 --> Language Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Loader Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:10:39 --> Controller Class Initialized
DEBUG - 2015-01-17 23:10:39 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:10:39 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:10:39 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:10:39 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Config Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:11:43 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:11:43 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:11:43 --> URI Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Router Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Output Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Security Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Input Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:11:43 --> Language Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Loader Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:11:43 --> Controller Class Initialized
DEBUG - 2015-01-17 23:11:43 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:11:43 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:11:43 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:11:43 --> Final output sent to browser
DEBUG - 2015-01-17 23:11:43 --> Total execution time: 0.0111
DEBUG - 2015-01-17 23:11:46 --> Config Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:11:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:11:46 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:11:46 --> URI Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Router Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Output Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Security Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Input Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:11:46 --> Language Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Loader Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:11:46 --> Controller Class Initialized
DEBUG - 2015-01-17 23:11:46 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:11:46 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:11:46 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:11:46 --> Final output sent to browser
DEBUG - 2015-01-17 23:11:46 --> Total execution time: 0.0060
DEBUG - 2015-01-17 23:11:49 --> Config Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:11:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:11:49 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:11:49 --> URI Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Router Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Output Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Security Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Input Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:11:49 --> Language Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Loader Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:11:49 --> Controller Class Initialized
DEBUG - 2015-01-17 23:11:49 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:11:49 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:11:49 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:11:49 --> Final output sent to browser
DEBUG - 2015-01-17 23:11:49 --> Total execution time: 0.0072
DEBUG - 2015-01-17 23:11:53 --> Config Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:11:53 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:11:53 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:11:53 --> URI Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Router Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Output Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Security Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Input Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:11:53 --> Language Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Loader Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:11:53 --> Controller Class Initialized
DEBUG - 2015-01-17 23:11:53 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:11:53 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:11:53 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:11:53 --> Final output sent to browser
DEBUG - 2015-01-17 23:11:53 --> Total execution time: 0.0072
DEBUG - 2015-01-17 23:11:55 --> Config Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:11:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:11:55 --> URI Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Router Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Output Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Security Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Input Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:11:55 --> Language Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Loader Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:11:55 --> Controller Class Initialized
DEBUG - 2015-01-17 23:11:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:11:55 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:11:55 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:11:55 --> Final output sent to browser
DEBUG - 2015-01-17 23:11:55 --> Total execution time: 0.0129
DEBUG - 2015-01-17 23:12:31 --> Config Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:12:31 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:12:31 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:12:31 --> URI Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Router Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Output Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Security Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Input Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:12:31 --> Language Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Loader Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:12:31 --> Controller Class Initialized
DEBUG - 2015-01-17 23:12:31 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:12:31 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:12:31 --> Final output sent to browser
DEBUG - 2015-01-17 23:12:31 --> Total execution time: 0.0079
DEBUG - 2015-01-17 23:12:36 --> Config Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:12:36 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:12:36 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:12:36 --> URI Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Router Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Output Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Security Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Input Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:12:36 --> Language Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Loader Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:12:36 --> Controller Class Initialized
DEBUG - 2015-01-17 23:12:36 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:12:36 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:12:36 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:12:36 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Config Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:12:46 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:12:46 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:12:46 --> URI Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Router Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Output Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Security Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Input Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:12:46 --> Language Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Loader Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:12:46 --> Controller Class Initialized
DEBUG - 2015-01-17 23:12:46 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:12:46 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:12:46 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:12:46 --> Final output sent to browser
DEBUG - 2015-01-17 23:12:46 --> Total execution time: 0.0110
DEBUG - 2015-01-17 23:15:48 --> Config Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:15:48 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:15:48 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:15:48 --> URI Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Router Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Output Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Security Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Input Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:15:48 --> Language Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Loader Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:15:48 --> Controller Class Initialized
DEBUG - 2015-01-17 23:15:48 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:15:48 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:15:48 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:15:48 --> Final output sent to browser
DEBUG - 2015-01-17 23:15:48 --> Total execution time: 0.0114
DEBUG - 2015-01-17 23:15:51 --> Config Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:15:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:15:51 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:15:51 --> URI Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Router Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Output Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Security Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Input Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:15:51 --> Language Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Loader Class Initialized
DEBUG - 2015-01-17 23:15:51 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:15:51 --> Controller Class Initialized
DEBUG - 2015-01-17 23:15:52 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:15:52 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:15:52 --> Final output sent to browser
DEBUG - 2015-01-17 23:15:52 --> Total execution time: 0.0041
DEBUG - 2015-01-17 23:15:55 --> Config Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:15:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:15:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:15:55 --> URI Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Router Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Output Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Security Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Input Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:15:55 --> Language Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Loader Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:15:55 --> Controller Class Initialized
DEBUG - 2015-01-17 23:15:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:15:55 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:15:55 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:15:55 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Config Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:16:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:16:06 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:16:06 --> URI Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Router Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Output Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Security Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Input Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:16:06 --> Language Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Loader Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:16:06 --> Controller Class Initialized
DEBUG - 2015-01-17 23:16:06 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:16:06 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:16:06 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:16:06 --> Final output sent to browser
DEBUG - 2015-01-17 23:16:06 --> Total execution time: 0.0119
DEBUG - 2015-01-17 23:24:49 --> Config Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:24:49 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:24:49 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:24:49 --> URI Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Router Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Output Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Security Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Input Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:24:49 --> Language Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Loader Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:24:49 --> Controller Class Initialized
DEBUG - 2015-01-17 23:24:49 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:24:49 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:24:49 --> Final output sent to browser
DEBUG - 2015-01-17 23:24:49 --> Total execution time: 0.0057
DEBUG - 2015-01-17 23:24:51 --> Config Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:24:51 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:24:51 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:24:51 --> URI Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Router Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Output Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Security Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Input Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:24:51 --> Language Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Loader Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:24:51 --> Controller Class Initialized
DEBUG - 2015-01-17 23:24:51 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:24:51 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:24:51 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:24:51 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Config Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:25:01 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:25:01 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:25:01 --> URI Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Router Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Output Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Security Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Input Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:25:01 --> Language Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Loader Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:25:01 --> Controller Class Initialized
DEBUG - 2015-01-17 23:25:01 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:25:01 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:25:01 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:25:01 --> Final output sent to browser
DEBUG - 2015-01-17 23:25:01 --> Total execution time: 0.0191
DEBUG - 2015-01-17 23:25:04 --> Config Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:25:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:25:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:25:04 --> URI Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Router Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Output Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Security Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Input Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:25:04 --> Language Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Loader Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:25:04 --> Controller Class Initialized
DEBUG - 2015-01-17 23:25:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:25:04 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:25:04 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:25:04 --> Final output sent to browser
DEBUG - 2015-01-17 23:25:04 --> Total execution time: 0.0072
DEBUG - 2015-01-17 23:25:08 --> Config Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:25:08 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:25:08 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:25:08 --> URI Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Router Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Output Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Security Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Input Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:25:08 --> Language Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Loader Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:25:08 --> Controller Class Initialized
DEBUG - 2015-01-17 23:25:08 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:25:08 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:25:08 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:25:08 --> Final output sent to browser
DEBUG - 2015-01-17 23:25:08 --> Total execution time: 0.0071
DEBUG - 2015-01-17 23:25:18 --> Config Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:25:18 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:25:18 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:25:18 --> URI Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Router Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Output Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Security Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Input Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:25:18 --> Language Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Loader Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:25:18 --> Controller Class Initialized
DEBUG - 2015-01-17 23:25:18 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:25:18 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:25:18 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:25:18 --> Final output sent to browser
DEBUG - 2015-01-17 23:25:18 --> Total execution time: 0.0148
DEBUG - 2015-01-17 23:26:52 --> Config Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:26:52 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:26:52 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:26:52 --> URI Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Router Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Output Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Security Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Input Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:26:52 --> Language Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Loader Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:26:52 --> Controller Class Initialized
DEBUG - 2015-01-17 23:26:52 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:26:52 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:26:52 --> Final output sent to browser
DEBUG - 2015-01-17 23:26:52 --> Total execution time: 0.0061
DEBUG - 2015-01-17 23:26:55 --> Config Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:26:55 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:26:55 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:26:55 --> URI Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Router Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Output Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Security Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Input Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:26:55 --> Language Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Loader Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:26:55 --> Controller Class Initialized
DEBUG - 2015-01-17 23:26:55 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:26:55 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:26:55 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:26:55 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Config Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:27:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:27:10 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:27:10 --> URI Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Router Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Output Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Security Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Input Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:27:10 --> Language Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Loader Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:27:10 --> Controller Class Initialized
DEBUG - 2015-01-17 23:27:10 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:27:10 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:27:10 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:27:10 --> Final output sent to browser
DEBUG - 2015-01-17 23:27:10 --> Total execution time: 0.0133
DEBUG - 2015-01-17 23:37:41 --> Config Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:37:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:37:41 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:37:41 --> URI Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Router Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Output Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Security Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Input Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:37:41 --> Language Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Loader Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:37:41 --> Controller Class Initialized
DEBUG - 2015-01-17 23:37:41 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:37:41 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:37:41 --> Final output sent to browser
DEBUG - 2015-01-17 23:37:41 --> Total execution time: 0.0061
DEBUG - 2015-01-17 23:37:45 --> Config Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:37:45 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:37:45 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:37:45 --> URI Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Router Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Output Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Security Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Input Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:37:45 --> Language Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Loader Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:37:45 --> Controller Class Initialized
DEBUG - 2015-01-17 23:37:45 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:37:45 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:37:45 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:37:45 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Config Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:38:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:38:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:38:04 --> URI Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Router Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Output Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Security Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Input Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:38:04 --> Language Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Loader Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:38:04 --> Controller Class Initialized
DEBUG - 2015-01-17 23:38:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:38:04 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:38:04 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:38:04 --> Final output sent to browser
DEBUG - 2015-01-17 23:38:04 --> Total execution time: 0.0125
DEBUG - 2015-01-17 23:38:07 --> Config Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:38:07 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:38:07 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:38:07 --> URI Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Router Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Output Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Security Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Input Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:38:07 --> Language Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Loader Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:38:07 --> Controller Class Initialized
DEBUG - 2015-01-17 23:38:07 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:38:07 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:38:07 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:38:07 --> Final output sent to browser
DEBUG - 2015-01-17 23:38:07 --> Total execution time: 0.0074
DEBUG - 2015-01-17 23:38:10 --> Config Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:38:10 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:38:10 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:38:10 --> URI Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Router Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Output Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Security Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Input Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:38:10 --> Language Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Loader Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:38:10 --> Controller Class Initialized
DEBUG - 2015-01-17 23:38:10 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:38:10 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:38:10 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:38:10 --> Final output sent to browser
DEBUG - 2015-01-17 23:38:10 --> Total execution time: 0.0096
DEBUG - 2015-01-17 23:38:16 --> Config Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:38:16 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:38:16 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:38:16 --> URI Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Router Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Output Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Security Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Input Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:38:16 --> Language Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Loader Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:38:16 --> Controller Class Initialized
DEBUG - 2015-01-17 23:38:16 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:38:16 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:38:16 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:38:16 --> Final output sent to browser
DEBUG - 2015-01-17 23:38:16 --> Total execution time: 0.0083
DEBUG - 2015-01-17 23:39:40 --> Config Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:39:40 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:39:40 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:39:40 --> URI Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Router Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Output Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Security Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Input Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:39:40 --> Language Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Loader Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:39:40 --> Controller Class Initialized
DEBUG - 2015-01-17 23:39:40 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:39:40 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:39:40 --> Final output sent to browser
DEBUG - 2015-01-17 23:39:40 --> Total execution time: 0.0058
DEBUG - 2015-01-17 23:39:42 --> Config Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:39:42 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:39:42 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:39:42 --> URI Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Router Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Output Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Security Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Input Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:39:42 --> Language Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Loader Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:39:42 --> Controller Class Initialized
DEBUG - 2015-01-17 23:39:42 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:39:42 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:39:42 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:39:42 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Config Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:40:00 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:40:00 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:40:00 --> URI Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Router Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Output Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Security Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Input Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:40:00 --> Language Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Loader Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:40:00 --> Controller Class Initialized
DEBUG - 2015-01-17 23:40:00 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:40:00 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:40:00 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:40:00 --> Final output sent to browser
DEBUG - 2015-01-17 23:40:00 --> Total execution time: 0.0116
DEBUG - 2015-01-17 23:40:02 --> Config Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:40:02 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:40:02 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:40:02 --> URI Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Router Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Output Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Security Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Input Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:40:02 --> Language Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Loader Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:40:02 --> Controller Class Initialized
DEBUG - 2015-01-17 23:40:02 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:40:02 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:40:02 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:40:02 --> Final output sent to browser
DEBUG - 2015-01-17 23:40:02 --> Total execution time: 0.0081
DEBUG - 2015-01-17 23:44:21 --> Config Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:44:21 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:44:21 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:44:21 --> URI Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Router Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Output Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Security Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Input Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:44:21 --> Language Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Loader Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:44:21 --> Controller Class Initialized
DEBUG - 2015-01-17 23:44:21 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:44:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:44:21 --> Final output sent to browser
DEBUG - 2015-01-17 23:44:21 --> Total execution time: 0.0052
DEBUG - 2015-01-17 23:44:26 --> Config Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:44:26 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:44:26 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:44:26 --> URI Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Router Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Output Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Security Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Input Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:44:26 --> Language Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Loader Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:44:26 --> Controller Class Initialized
DEBUG - 2015-01-17 23:44:26 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:44:26 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:44:26 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:44:26 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Config Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:44:35 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:44:35 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:44:35 --> URI Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Router Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Output Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Security Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Input Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:44:35 --> Language Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Loader Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:44:35 --> Controller Class Initialized
DEBUG - 2015-01-17 23:44:35 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:44:35 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:44:35 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:44:35 --> Final output sent to browser
DEBUG - 2015-01-17 23:44:35 --> Total execution time: 0.0113
DEBUG - 2015-01-17 23:44:38 --> Config Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:44:38 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:44:38 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:44:38 --> URI Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Router Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Output Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Security Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Input Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:44:38 --> Language Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Loader Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:44:38 --> Controller Class Initialized
DEBUG - 2015-01-17 23:44:38 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:44:38 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:44:38 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:44:38 --> Final output sent to browser
DEBUG - 2015-01-17 23:44:38 --> Total execution time: 0.0068
DEBUG - 2015-01-17 23:44:41 --> Config Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:44:41 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:44:41 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:44:41 --> URI Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Router Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Output Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Security Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Input Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:44:41 --> Language Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Loader Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:44:41 --> Controller Class Initialized
DEBUG - 2015-01-17 23:44:41 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:44:41 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:44:41 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:44:41 --> Final output sent to browser
DEBUG - 2015-01-17 23:44:41 --> Total execution time: 0.0123
DEBUG - 2015-01-17 23:54:04 --> Config Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:54:04 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:54:04 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:54:04 --> URI Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Router Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Output Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Security Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Input Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:54:04 --> Language Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Loader Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:54:04 --> Controller Class Initialized
DEBUG - 2015-01-17 23:54:04 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:54:04 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-01-17 23:54:04 --> Final output sent to browser
DEBUG - 2015-01-17 23:54:04 --> Total execution time: 0.0080
DEBUG - 2015-01-17 23:54:06 --> Config Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:54:06 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:54:06 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:54:06 --> URI Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Router Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Output Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Security Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Input Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:54:06 --> Language Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Loader Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:54:06 --> Controller Class Initialized
DEBUG - 2015-01-17 23:54:06 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:54:06 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:54:06 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:54:06 --> User Agent Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Config Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:54:20 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:54:20 --> URI Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Router Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Output Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Security Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Input Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:54:20 --> Language Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Loader Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:54:20 --> Controller Class Initialized
DEBUG - 2015-01-17 23:54:20 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:54:20 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:54:20 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:54:20 --> Final output sent to browser
DEBUG - 2015-01-17 23:54:20 --> Total execution time: 0.0123
DEBUG - 2015-01-17 23:54:33 --> Config Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:54:33 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:54:33 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:54:33 --> URI Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Router Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Output Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Security Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Input Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:54:33 --> Language Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Loader Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:54:33 --> Controller Class Initialized
DEBUG - 2015-01-17 23:54:33 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:54:33 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:54:33 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:54:33 --> Final output sent to browser
DEBUG - 2015-01-17 23:54:33 --> Total execution time: 0.0149
DEBUG - 2015-01-17 23:56:19 --> Config Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Hooks Class Initialized
DEBUG - 2015-01-17 23:56:19 --> UTF-8 Support Enabled
DEBUG - 2015-01-17 23:56:19 --> Utf8 Class Initialized
DEBUG - 2015-01-17 23:56:19 --> URI Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Router Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Output Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Security Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Input Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-01-17 23:56:19 --> Language Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Loader Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Helper loaded: url_helper
DEBUG - 2015-01-17 23:56:19 --> Controller Class Initialized
DEBUG - 2015-01-17 23:56:19 --> Database Driver Class Initialized
DEBUG - 2015-01-17 23:56:19 --> CI_Session Class Initialized
DEBUG - 2015-01-17 23:56:19 --> CI_Session routines successfully run
DEBUG - 2015-01-17 23:56:19 --> Final output sent to browser
DEBUG - 2015-01-17 23:56:19 --> Total execution time: 0.0138
