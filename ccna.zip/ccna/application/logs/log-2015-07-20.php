<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-07-20 18:42:55 --> Config Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:42:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:42:55 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:42:55 --> URI Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Router Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Output Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Security Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Input Class Initialized
DEBUG - 2015-07-20 18:42:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:42:55 --> Language Class Initialized
ERROR - 2015-07-20 18:42:55 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:43:07 --> Config Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:43:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:43:07 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:43:07 --> URI Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Router Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Output Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Security Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Input Class Initialized
DEBUG - 2015-07-20 18:43:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:43:07 --> Language Class Initialized
ERROR - 2015-07-20 18:43:07 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:43:57 --> Config Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:43:57 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:43:57 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:43:57 --> URI Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Router Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Output Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Security Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Input Class Initialized
DEBUG - 2015-07-20 18:43:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:43:57 --> Language Class Initialized
ERROR - 2015-07-20 18:43:57 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:44:02 --> Config Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:44:02 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:44:02 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:44:02 --> URI Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Router Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Output Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Security Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Input Class Initialized
DEBUG - 2015-07-20 18:44:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:44:02 --> Language Class Initialized
ERROR - 2015-07-20 18:44:02 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:46:38 --> Config Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:46:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:46:38 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:46:38 --> URI Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Router Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Output Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Security Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Input Class Initialized
DEBUG - 2015-07-20 18:46:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:46:38 --> Language Class Initialized
ERROR - 2015-07-20 18:46:38 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:46:39 --> Config Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:46:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:46:39 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:46:39 --> URI Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Router Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Output Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Security Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Input Class Initialized
DEBUG - 2015-07-20 18:46:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:46:39 --> Language Class Initialized
ERROR - 2015-07-20 18:46:39 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:46:45 --> Config Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:46:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:46:45 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:46:45 --> URI Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Router Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Output Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Security Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Input Class Initialized
DEBUG - 2015-07-20 18:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:46:45 --> Language Class Initialized
ERROR - 2015-07-20 18:46:45 --> 404 Page Not Found: /index
DEBUG - 2015-07-20 18:49:53 --> Config Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:49:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:49:53 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:49:53 --> URI Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Router Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Output Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Security Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Input Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:49:53 --> Language Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Loader Class Initialized
DEBUG - 2015-07-20 18:49:53 --> Helper loaded: url_helper
DEBUG - 2015-07-20 18:49:53 --> Controller Class Initialized
DEBUG - 2015-07-20 18:49:53 --> File loaded: /var/www/adwords/application/views/welcome_message.php
DEBUG - 2015-07-20 18:49:53 --> Final output sent to browser
DEBUG - 2015-07-20 18:49:53 --> Total execution time: 0.0109
DEBUG - 2015-07-20 18:49:59 --> Config Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:49:59 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:49:59 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:49:59 --> URI Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Router Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Output Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Security Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Input Class Initialized
DEBUG - 2015-07-20 18:49:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:49:59 --> Language Class Initialized
ERROR - 2015-07-20 18:49:59 --> 404 Page Not Found: PraticeAdwordExam/index
DEBUG - 2015-07-20 18:50:37 --> Config Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:50:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:50:37 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:50:37 --> URI Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Router Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Output Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Security Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Input Class Initialized
DEBUG - 2015-07-20 18:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:50:37 --> Language Class Initialized
ERROR - 2015-07-20 18:50:37 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 18:50:41 --> Config Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:50:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:50:41 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:50:41 --> URI Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Router Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Output Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Security Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Input Class Initialized
DEBUG - 2015-07-20 18:50:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:50:41 --> Language Class Initialized
ERROR - 2015-07-20 18:50:41 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 18:52:07 --> Config Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:52:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:52:07 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:52:07 --> URI Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Router Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Output Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Security Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Input Class Initialized
DEBUG - 2015-07-20 18:52:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:52:07 --> Language Class Initialized
ERROR - 2015-07-20 18:52:07 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 18:52:08 --> Config Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Hooks Class Initialized
DEBUG - 2015-07-20 18:52:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 18:52:08 --> Utf8 Class Initialized
DEBUG - 2015-07-20 18:52:08 --> URI Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Router Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Output Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Security Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Input Class Initialized
DEBUG - 2015-07-20 18:52:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 18:52:08 --> Language Class Initialized
ERROR - 2015-07-20 18:52:08 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:02:29 --> Config Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:02:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:02:29 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:02:29 --> URI Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Router Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Output Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Security Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Input Class Initialized
DEBUG - 2015-07-20 19:02:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:02:29 --> Language Class Initialized
ERROR - 2015-07-20 19:02:29 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:02:31 --> Config Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:02:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:02:31 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:02:31 --> URI Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Router Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Output Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Security Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Input Class Initialized
DEBUG - 2015-07-20 19:02:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:02:31 --> Language Class Initialized
ERROR - 2015-07-20 19:02:31 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:11:41 --> Config Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:11:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:11:41 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:11:41 --> URI Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Router Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Output Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Security Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Input Class Initialized
DEBUG - 2015-07-20 19:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:11:41 --> Language Class Initialized
ERROR - 2015-07-20 19:11:41 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:16:34 --> Config Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:16:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:16:34 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:16:34 --> URI Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Router Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Output Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Security Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Input Class Initialized
DEBUG - 2015-07-20 19:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:16:34 --> Language Class Initialized
ERROR - 2015-07-20 19:16:34 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:16:35 --> Config Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:16:35 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:16:35 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:16:35 --> URI Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Router Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Output Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Security Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Input Class Initialized
DEBUG - 2015-07-20 19:16:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:16:35 --> Language Class Initialized
ERROR - 2015-07-20 19:16:35 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 19:46:43 --> Config Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Hooks Class Initialized
DEBUG - 2015-07-20 19:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 19:46:43 --> Utf8 Class Initialized
DEBUG - 2015-07-20 19:46:43 --> URI Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Router Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Output Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Security Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Input Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 19:46:43 --> Language Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Loader Class Initialized
DEBUG - 2015-07-20 19:46:43 --> Helper loaded: url_helper
DEBUG - 2015-07-20 19:46:43 --> Controller Class Initialized
DEBUG - 2015-07-20 19:46:43 --> File loaded: /var/www/adwords/application/views/welcome_message.php
DEBUG - 2015-07-20 19:46:43 --> Final output sent to browser
DEBUG - 2015-07-20 19:46:43 --> Total execution time: 0.0408
DEBUG - 2015-07-20 20:31:14 --> Config Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:31:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:31:14 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:31:14 --> URI Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Router Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Output Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Security Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Input Class Initialized
DEBUG - 2015-07-20 20:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:31:14 --> Language Class Initialized
ERROR - 2015-07-20 20:31:14 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 20:33:26 --> Config Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:33:26 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:33:26 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:33:26 --> URI Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Router Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Output Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Security Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Input Class Initialized
DEBUG - 2015-07-20 20:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:33:26 --> Language Class Initialized
ERROR - 2015-07-20 20:33:26 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 20:33:27 --> Config Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:33:27 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:33:27 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:33:27 --> URI Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Router Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Output Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Security Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Input Class Initialized
DEBUG - 2015-07-20 20:33:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:33:27 --> Language Class Initialized
ERROR - 2015-07-20 20:33:27 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 20:34:18 --> Config Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:34:18 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:34:18 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:34:18 --> URI Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Router Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Output Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Security Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Input Class Initialized
DEBUG - 2015-07-20 20:34:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:34:18 --> Language Class Initialized
ERROR - 2015-07-20 20:34:18 --> 404 Page Not Found: Praticeadwordexam/index
DEBUG - 2015-07-20 20:35:04 --> Config Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:35:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:35:04 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:35:04 --> URI Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Router Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Output Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Security Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Input Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:35:04 --> Language Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Loader Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:35:04 --> Controller Class Initialized
DEBUG - 2015-07-20 20:35:04 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Config Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:36:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:36:15 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:36:15 --> URI Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Router Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Output Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Security Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Input Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:36:15 --> Language Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Loader Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:36:15 --> Controller Class Initialized
DEBUG - 2015-07-20 20:36:15 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Config Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:37:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:37:08 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:37:08 --> URI Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Router Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Output Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Security Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Input Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:37:08 --> Language Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Loader Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:37:08 --> Controller Class Initialized
DEBUG - 2015-07-20 20:37:08 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Config Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:37:09 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:37:09 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:37:09 --> URI Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Router Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Output Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Security Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Input Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:37:09 --> Language Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Loader Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:37:09 --> Controller Class Initialized
DEBUG - 2015-07-20 20:37:09 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Config Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:38:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:38:38 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:38:38 --> URI Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Router Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Output Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Security Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Input Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:38:38 --> Language Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Loader Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:38:38 --> Controller Class Initialized
DEBUG - 2015-07-20 20:38:38 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Config Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:38:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:38:39 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:38:39 --> URI Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Router Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Output Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Security Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Input Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:38:39 --> Language Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Loader Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:38:39 --> Controller Class Initialized
DEBUG - 2015-07-20 20:38:39 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Config Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:40:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:40:37 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:40:37 --> URI Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Router Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Output Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Security Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Input Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:40:37 --> Language Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Loader Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:40:37 --> Controller Class Initialized
DEBUG - 2015-07-20 20:40:37 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Config Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:40:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:40:38 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:40:38 --> URI Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Router Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Output Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Security Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Input Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:40:38 --> Language Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Loader Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:40:38 --> Controller Class Initialized
DEBUG - 2015-07-20 20:40:38 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Config Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:40:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:40:39 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:40:39 --> URI Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Router Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Output Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Security Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Input Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:40:39 --> Language Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Loader Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:40:39 --> Controller Class Initialized
DEBUG - 2015-07-20 20:40:39 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Config Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:40:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:40:48 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:40:48 --> URI Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Router Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Output Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Security Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Input Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:40:48 --> Language Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Loader Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:40:48 --> Controller Class Initialized
DEBUG - 2015-07-20 20:40:48 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Config Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:46:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:46:44 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:46:44 --> URI Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Router Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Output Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Security Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Input Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:46:44 --> Language Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Loader Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:46:44 --> Controller Class Initialized
DEBUG - 2015-07-20 20:46:44 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Config Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:46:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:46:45 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:46:45 --> URI Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Router Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Output Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Security Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Input Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:46:45 --> Language Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Loader Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:46:45 --> Controller Class Initialized
DEBUG - 2015-07-20 20:46:45 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Config Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:48:51 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:48:51 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:48:51 --> URI Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Router Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Output Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Security Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Input Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:48:51 --> Language Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Loader Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:48:51 --> Controller Class Initialized
DEBUG - 2015-07-20 20:48:51 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Config Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:49:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:49:45 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:49:45 --> URI Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Router Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Output Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Security Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Input Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:49:45 --> Language Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Loader Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:49:45 --> Controller Class Initialized
DEBUG - 2015-07-20 20:49:45 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Config Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:50:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:50:20 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:50:20 --> URI Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Router Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Output Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Security Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Input Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:50:20 --> Language Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Loader Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:50:20 --> Controller Class Initialized
DEBUG - 2015-07-20 20:50:20 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Config Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:50:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:50:46 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:50:46 --> URI Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Router Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Output Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Security Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Input Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:50:46 --> Language Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Loader Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:50:46 --> Controller Class Initialized
DEBUG - 2015-07-20 20:50:46 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:50:46 --> File loaded: /var/www/adwords/application/views/about.php
DEBUG - 2015-07-20 20:50:46 --> Final output sent to browser
DEBUG - 2015-07-20 20:50:46 --> Total execution time: 0.0065
DEBUG - 2015-07-20 20:51:34 --> Config Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:51:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:51:34 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:51:34 --> URI Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Router Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Output Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Security Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Input Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:51:34 --> Language Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Loader Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:51:34 --> Controller Class Initialized
DEBUG - 2015-07-20 20:51:34 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Config Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:54:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:54:00 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:54:00 --> URI Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Router Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Output Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Security Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Input Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:54:00 --> Language Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Loader Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:54:00 --> Controller Class Initialized
DEBUG - 2015-07-20 20:54:00 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:54:00 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 20:54:00 --> Final output sent to browser
DEBUG - 2015-07-20 20:54:00 --> Total execution time: 0.0052
DEBUG - 2015-07-20 20:54:20 --> Config Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:54:20 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:54:20 --> URI Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Router Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Output Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Security Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Input Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:54:20 --> Language Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Loader Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:54:20 --> Controller Class Initialized
DEBUG - 2015-07-20 20:54:20 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:54:20 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 20:54:20 --> Final output sent to browser
DEBUG - 2015-07-20 20:54:20 --> Total execution time: 0.0032
DEBUG - 2015-07-20 20:55:23 --> Config Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:55:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:55:23 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:55:23 --> URI Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Router Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Output Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Security Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Input Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:55:23 --> Language Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Loader Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:55:23 --> Controller Class Initialized
DEBUG - 2015-07-20 20:55:23 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:55:23 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 20:55:23 --> Final output sent to browser
DEBUG - 2015-07-20 20:55:23 --> Total execution time: 0.0059
DEBUG - 2015-07-20 20:55:43 --> Config Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Hooks Class Initialized
DEBUG - 2015-07-20 20:55:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 20:55:43 --> Utf8 Class Initialized
DEBUG - 2015-07-20 20:55:43 --> URI Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Router Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Output Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Security Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Input Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 20:55:43 --> Language Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Loader Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Helper loaded: url_helper
DEBUG - 2015-07-20 20:55:43 --> Controller Class Initialized
DEBUG - 2015-07-20 20:55:43 --> Database Driver Class Initialized
DEBUG - 2015-07-20 20:55:43 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 20:55:43 --> Final output sent to browser
DEBUG - 2015-07-20 20:55:43 --> Total execution time: 0.0064
DEBUG - 2015-07-20 21:00:55 --> Config Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Hooks Class Initialized
DEBUG - 2015-07-20 21:00:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 21:00:55 --> Utf8 Class Initialized
DEBUG - 2015-07-20 21:00:55 --> URI Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Router Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Output Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Security Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Input Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 21:00:55 --> Language Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Loader Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Helper loaded: url_helper
DEBUG - 2015-07-20 21:00:55 --> Controller Class Initialized
DEBUG - 2015-07-20 21:00:55 --> Database Driver Class Initialized
DEBUG - 2015-07-20 21:00:55 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 21:00:55 --> Final output sent to browser
DEBUG - 2015-07-20 21:00:55 --> Total execution time: 0.0050
DEBUG - 2015-07-20 21:02:09 --> Config Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Hooks Class Initialized
DEBUG - 2015-07-20 21:02:09 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 21:02:09 --> Utf8 Class Initialized
DEBUG - 2015-07-20 21:02:09 --> URI Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Router Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Output Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Security Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Input Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 21:02:09 --> Language Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Loader Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Helper loaded: url_helper
DEBUG - 2015-07-20 21:02:09 --> Controller Class Initialized
DEBUG - 2015-07-20 21:02:09 --> Database Driver Class Initialized
DEBUG - 2015-07-20 21:02:09 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 21:02:09 --> Final output sent to browser
DEBUG - 2015-07-20 21:02:09 --> Total execution time: 0.0084
DEBUG - 2015-07-20 21:03:58 --> Config Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Hooks Class Initialized
DEBUG - 2015-07-20 21:03:58 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 21:03:58 --> Utf8 Class Initialized
DEBUG - 2015-07-20 21:03:58 --> URI Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Router Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Output Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Security Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Input Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 21:03:58 --> Language Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Loader Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Helper loaded: url_helper
DEBUG - 2015-07-20 21:03:58 --> Controller Class Initialized
DEBUG - 2015-07-20 21:03:58 --> Database Driver Class Initialized
DEBUG - 2015-07-20 21:03:58 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 21:03:58 --> Final output sent to browser
DEBUG - 2015-07-20 21:03:58 --> Total execution time: 0.0087
DEBUG - 2015-07-20 21:04:08 --> Config Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Hooks Class Initialized
DEBUG - 2015-07-20 21:04:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-20 21:04:08 --> Utf8 Class Initialized
DEBUG - 2015-07-20 21:04:08 --> URI Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Router Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Output Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Security Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Input Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-20 21:04:08 --> Language Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Loader Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Helper loaded: url_helper
DEBUG - 2015-07-20 21:04:08 --> Controller Class Initialized
DEBUG - 2015-07-20 21:04:08 --> Database Driver Class Initialized
DEBUG - 2015-07-20 21:04:08 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-20 21:04:08 --> Final output sent to browser
DEBUG - 2015-07-20 21:04:08 --> Total execution time: 0.0028
