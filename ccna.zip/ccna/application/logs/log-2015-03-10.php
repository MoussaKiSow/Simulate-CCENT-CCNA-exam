<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-03-10 19:11:50 --> Config Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:11:50 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:11:50 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:11:50 --> URI Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Router Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Output Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Security Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Input Class Initialized
DEBUG - 2015-03-10 19:11:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:11:50 --> Language Class Initialized
ERROR - 2015-03-10 19:11:50 --> 404 Page Not Found: /index
DEBUG - 2015-03-10 19:11:55 --> Config Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:11:55 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:11:55 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:11:55 --> URI Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Router Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Output Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Security Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Input Class Initialized
DEBUG - 2015-03-10 19:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:11:55 --> Language Class Initialized
ERROR - 2015-03-10 19:11:55 --> 404 Page Not Found: /index
DEBUG - 2015-03-10 19:12:02 --> Config Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:12:02 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:12:02 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:12:02 --> URI Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Router Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Output Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Security Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Input Class Initialized
DEBUG - 2015-03-10 19:12:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:12:02 --> Language Class Initialized
ERROR - 2015-03-10 19:12:02 --> 404 Page Not Found: TheGame/index
DEBUG - 2015-03-10 19:12:04 --> Config Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:12:04 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:12:04 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:12:04 --> URI Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Router Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Output Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Security Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Input Class Initialized
DEBUG - 2015-03-10 19:12:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:12:04 --> Language Class Initialized
ERROR - 2015-03-10 19:12:04 --> 404 Page Not Found: TheGame/index
DEBUG - 2015-03-10 19:12:15 --> Config Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:12:15 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:12:15 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:12:15 --> URI Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Router Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Output Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Security Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Input Class Initialized
DEBUG - 2015-03-10 19:12:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:12:15 --> Language Class Initialized
ERROR - 2015-03-10 19:12:15 --> 404 Page Not Found: HeGame/index
DEBUG - 2015-03-10 19:12:21 --> Config Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Hooks Class Initialized
DEBUG - 2015-03-10 19:12:21 --> UTF-8 Support Enabled
DEBUG - 2015-03-10 19:12:21 --> Utf8 Class Initialized
DEBUG - 2015-03-10 19:12:21 --> URI Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Router Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Output Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Security Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Input Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-03-10 19:12:21 --> Language Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Loader Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Helper loaded: url_helper
DEBUG - 2015-03-10 19:12:21 --> Controller Class Initialized
DEBUG - 2015-03-10 19:12:21 --> Database Driver Class Initialized
DEBUG - 2015-03-10 19:12:21 --> File loaded: /var/www/WhoWantsToBeAMilionaire/application/views/thegame.php
DEBUG - 2015-03-10 19:12:21 --> Final output sent to browser
DEBUG - 2015-03-10 19:12:21 --> Total execution time: 0.1654
