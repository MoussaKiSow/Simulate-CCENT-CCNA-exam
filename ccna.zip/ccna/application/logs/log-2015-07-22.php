<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2015-07-22 16:23:33 --> Config Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:23:33 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:23:33 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:23:33 --> URI Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Router Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Output Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Security Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Input Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:23:33 --> Language Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Loader Class Initialized
DEBUG - 2015-07-22 16:23:33 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:23:33 --> Controller Class Initialized
DEBUG - 2015-07-22 16:23:33 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:23:33 --> Final output sent to browser
DEBUG - 2015-07-22 16:23:33 --> Total execution time: 0.0033
DEBUG - 2015-07-22 16:26:04 --> Config Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:26:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:26:04 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:26:04 --> URI Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Router Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Output Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Security Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Input Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:26:04 --> Language Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Loader Class Initialized
DEBUG - 2015-07-22 16:26:04 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:26:04 --> Controller Class Initialized
DEBUG - 2015-07-22 16:26:04 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:26:04 --> Final output sent to browser
DEBUG - 2015-07-22 16:26:04 --> Total execution time: 0.0050
DEBUG - 2015-07-22 16:26:31 --> Config Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:26:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:26:31 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:26:31 --> URI Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Router Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Output Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Security Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Input Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:26:31 --> Language Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Loader Class Initialized
DEBUG - 2015-07-22 16:26:31 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:26:31 --> Controller Class Initialized
DEBUG - 2015-07-22 16:26:31 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:26:31 --> Final output sent to browser
DEBUG - 2015-07-22 16:26:31 --> Total execution time: 0.0019
DEBUG - 2015-07-22 16:26:34 --> Config Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:26:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:26:34 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:26:34 --> URI Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Router Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Output Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Security Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Input Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:26:34 --> Language Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Loader Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:26:34 --> Controller Class Initialized
DEBUG - 2015-07-22 16:26:34 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:26:34 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:26:34 --> A session cookie was not found.
DEBUG - 2015-07-22 16:26:34 --> Session: Creating new session (50cac30c226d7c75e1af0f1bed3f63d4)
DEBUG - 2015-07-22 16:26:34 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:30:19 --> Config Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:30:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:30:19 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:30:19 --> URI Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Router Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Output Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Security Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Input Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:30:19 --> Language Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Loader Class Initialized
DEBUG - 2015-07-22 16:30:19 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:30:19 --> Controller Class Initialized
DEBUG - 2015-07-22 16:30:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:30:19 --> Final output sent to browser
DEBUG - 2015-07-22 16:30:19 --> Total execution time: 0.0023
DEBUG - 2015-07-22 16:30:24 --> Config Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:30:24 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:30:24 --> URI Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Router Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Output Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Security Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Input Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:30:24 --> Language Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Loader Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:30:24 --> Controller Class Initialized
DEBUG - 2015-07-22 16:30:24 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:30:24 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:30:24 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:33:21 --> Config Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:33:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:33:21 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:33:21 --> URI Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Router Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Output Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Security Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Input Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:33:21 --> Language Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Loader Class Initialized
DEBUG - 2015-07-22 16:33:21 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:33:21 --> Controller Class Initialized
DEBUG - 2015-07-22 16:33:21 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:33:21 --> Final output sent to browser
DEBUG - 2015-07-22 16:33:21 --> Total execution time: 0.0025
DEBUG - 2015-07-22 16:33:26 --> Config Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:33:26 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:33:26 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:33:26 --> URI Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Router Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Output Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Security Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Input Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:33:26 --> Language Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Loader Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:33:26 --> Controller Class Initialized
DEBUG - 2015-07-22 16:33:26 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:33:26 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:33:26 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:40:12 --> Config Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:40:12 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:40:12 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:40:12 --> URI Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Router Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Output Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Security Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Input Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:40:12 --> Language Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Loader Class Initialized
DEBUG - 2015-07-22 16:40:12 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:40:12 --> Controller Class Initialized
DEBUG - 2015-07-22 16:40:12 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:40:12 --> Final output sent to browser
DEBUG - 2015-07-22 16:40:12 --> Total execution time: 0.0026
DEBUG - 2015-07-22 16:40:17 --> Config Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:40:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:40:17 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:40:17 --> URI Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Router Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Output Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Security Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Input Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:40:17 --> Language Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Loader Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:40:17 --> Controller Class Initialized
DEBUG - 2015-07-22 16:40:17 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:40:17 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:40:17 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:44:38 --> Config Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:44:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:44:38 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:44:38 --> URI Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Router Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Output Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Security Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Input Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:44:38 --> Language Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Loader Class Initialized
DEBUG - 2015-07-22 16:44:38 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:44:38 --> Controller Class Initialized
DEBUG - 2015-07-22 16:44:38 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:44:38 --> Final output sent to browser
DEBUG - 2015-07-22 16:44:38 --> Total execution time: 0.0032
DEBUG - 2015-07-22 16:44:43 --> Config Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:44:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:44:43 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:44:43 --> URI Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Router Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Output Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Security Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Input Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:44:43 --> Language Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Loader Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:44:43 --> Controller Class Initialized
DEBUG - 2015-07-22 16:44:43 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:44:43 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:44:43 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:46:14 --> Config Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:46:14 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:46:14 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:46:14 --> URI Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Router Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Output Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Security Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Input Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:46:14 --> Language Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Loader Class Initialized
DEBUG - 2015-07-22 16:46:14 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:46:14 --> Controller Class Initialized
DEBUG - 2015-07-22 16:46:14 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:46:14 --> Final output sent to browser
DEBUG - 2015-07-22 16:46:14 --> Total execution time: 0.0022
DEBUG - 2015-07-22 16:46:25 --> Config Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:46:25 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:46:25 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:46:25 --> URI Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Router Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Output Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Security Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Input Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:46:25 --> Language Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Loader Class Initialized
DEBUG - 2015-07-22 16:46:25 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:46:25 --> Controller Class Initialized
DEBUG - 2015-07-22 16:46:25 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:46:25 --> Final output sent to browser
DEBUG - 2015-07-22 16:46:25 --> Total execution time: 0.0022
DEBUG - 2015-07-22 16:46:43 --> Config Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:46:43 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:46:43 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:46:43 --> URI Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Router Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Output Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Security Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Input Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:46:43 --> Language Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Loader Class Initialized
DEBUG - 2015-07-22 16:46:43 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:46:43 --> Controller Class Initialized
DEBUG - 2015-07-22 16:46:43 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:46:43 --> Final output sent to browser
DEBUG - 2015-07-22 16:46:43 --> Total execution time: 0.0033
DEBUG - 2015-07-22 16:46:45 --> Config Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:46:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:46:45 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:46:45 --> URI Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Router Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Output Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Security Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Input Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:46:45 --> Language Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Loader Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:46:45 --> Controller Class Initialized
DEBUG - 2015-07-22 16:46:45 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:46:45 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:46:45 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:47:34 --> Config Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:47:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:47:34 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:47:34 --> URI Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Router Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Output Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Security Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Input Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:47:34 --> Language Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Loader Class Initialized
DEBUG - 2015-07-22 16:47:34 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:47:34 --> Controller Class Initialized
DEBUG - 2015-07-22 16:47:34 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:47:34 --> Final output sent to browser
DEBUG - 2015-07-22 16:47:34 --> Total execution time: 0.0042
DEBUG - 2015-07-22 16:47:36 --> Config Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:47:36 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:47:36 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:47:36 --> URI Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Router Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Output Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Security Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Input Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:47:36 --> Language Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Loader Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:47:36 --> Controller Class Initialized
DEBUG - 2015-07-22 16:47:36 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:47:36 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:47:36 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:48:24 --> Config Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:48:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:48:24 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:48:24 --> URI Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Router Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Output Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Security Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Input Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:48:24 --> Language Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Loader Class Initialized
DEBUG - 2015-07-22 16:48:24 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:48:24 --> Controller Class Initialized
DEBUG - 2015-07-22 16:48:24 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:48:24 --> Final output sent to browser
DEBUG - 2015-07-22 16:48:24 --> Total execution time: 0.0026
DEBUG - 2015-07-22 16:48:26 --> Config Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:48:26 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:48:26 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:48:26 --> URI Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Router Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Output Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Security Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Input Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:48:26 --> Language Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Loader Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:48:26 --> Controller Class Initialized
DEBUG - 2015-07-22 16:48:26 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:48:26 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:48:26 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:51:11 --> Config Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:51:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:51:11 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:51:11 --> URI Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Router Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Output Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Security Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Input Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:51:11 --> Language Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Loader Class Initialized
DEBUG - 2015-07-22 16:51:11 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:51:11 --> Controller Class Initialized
DEBUG - 2015-07-22 16:51:11 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:51:11 --> Final output sent to browser
DEBUG - 2015-07-22 16:51:11 --> Total execution time: 0.0033
DEBUG - 2015-07-22 16:51:13 --> Config Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:51:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:51:13 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:51:13 --> URI Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Router Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Output Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Security Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Input Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:51:13 --> Language Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Loader Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:51:13 --> Controller Class Initialized
DEBUG - 2015-07-22 16:51:13 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:51:13 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:51:13 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:54:15 --> Config Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:54:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:54:15 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:54:15 --> URI Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Router Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Output Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Security Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Input Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:54:15 --> Language Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Loader Class Initialized
DEBUG - 2015-07-22 16:54:15 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:54:15 --> Controller Class Initialized
DEBUG - 2015-07-22 16:54:15 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:54:15 --> Final output sent to browser
DEBUG - 2015-07-22 16:54:15 --> Total execution time: 0.0019
DEBUG - 2015-07-22 16:54:20 --> Config Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:54:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:54:20 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:54:20 --> URI Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Router Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Output Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Security Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Input Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:54:20 --> Language Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Loader Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:54:20 --> Controller Class Initialized
DEBUG - 2015-07-22 16:54:20 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:54:20 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:54:20 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:55:18 --> Config Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:55:18 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:55:18 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:55:18 --> URI Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Router Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Output Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Security Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Input Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:55:18 --> Language Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Loader Class Initialized
DEBUG - 2015-07-22 16:55:18 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:55:18 --> Controller Class Initialized
DEBUG - 2015-07-22 16:55:18 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:55:18 --> Final output sent to browser
DEBUG - 2015-07-22 16:55:18 --> Total execution time: 0.0029
DEBUG - 2015-07-22 16:55:19 --> Config Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:55:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:55:19 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:55:19 --> URI Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Router Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Output Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Security Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Input Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:55:19 --> Language Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Loader Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:55:19 --> Controller Class Initialized
DEBUG - 2015-07-22 16:55:19 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:55:19 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:55:19 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:55:51 --> Config Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:55:51 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:55:51 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:55:51 --> URI Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Router Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Output Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Security Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Input Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:55:51 --> Language Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Loader Class Initialized
DEBUG - 2015-07-22 16:55:51 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:55:51 --> Controller Class Initialized
DEBUG - 2015-07-22 16:55:51 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:55:51 --> Final output sent to browser
DEBUG - 2015-07-22 16:55:51 --> Total execution time: 0.0038
DEBUG - 2015-07-22 16:55:52 --> Config Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:55:52 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:55:52 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:55:52 --> URI Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Router Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Output Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Security Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Input Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:55:52 --> Language Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Loader Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:55:52 --> Controller Class Initialized
DEBUG - 2015-07-22 16:55:52 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:55:52 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:55:52 --> CI_Session routines successfully run
DEBUG - 2015-07-22 16:56:06 --> Config Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:56:06 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:56:06 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:56:06 --> URI Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Router Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Output Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Security Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Input Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:56:06 --> Language Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Loader Class Initialized
DEBUG - 2015-07-22 16:56:06 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:56:06 --> Controller Class Initialized
DEBUG - 2015-07-22 16:56:06 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 16:56:06 --> Final output sent to browser
DEBUG - 2015-07-22 16:56:06 --> Total execution time: 0.0032
DEBUG - 2015-07-22 16:56:08 --> Config Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Hooks Class Initialized
DEBUG - 2015-07-22 16:56:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 16:56:08 --> Utf8 Class Initialized
DEBUG - 2015-07-22 16:56:08 --> URI Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Router Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Output Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Security Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Input Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 16:56:08 --> Language Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Loader Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Helper loaded: url_helper
DEBUG - 2015-07-22 16:56:08 --> Controller Class Initialized
DEBUG - 2015-07-22 16:56:08 --> Database Driver Class Initialized
DEBUG - 2015-07-22 16:56:08 --> CI_Session Class Initialized
DEBUG - 2015-07-22 16:56:08 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:07:57 --> Config Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:07:57 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:07:57 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:07:57 --> URI Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Router Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Output Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Security Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Input Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:07:57 --> Language Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Loader Class Initialized
DEBUG - 2015-07-22 17:07:57 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:07:57 --> Controller Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Config Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:08:20 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:08:20 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:08:20 --> URI Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Router Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Output Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Security Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Input Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:08:20 --> Language Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Loader Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:08:20 --> Controller Class Initialized
DEBUG - 2015-07-22 17:08:20 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:08:20 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:08:20 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:09:30 --> Config Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:09:30 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:09:30 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:09:30 --> URI Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Router Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Output Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Security Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Input Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:09:30 --> Language Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Loader Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:09:30 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:09:30 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:09:30 --> Controller Class Initialized
DEBUG - 2015-07-22 17:09:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:09:49 --> Config Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:09:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:09:49 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:09:49 --> URI Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Router Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Output Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Security Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Input Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:09:49 --> Language Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Loader Class Initialized
DEBUG - 2015-07-22 17:09:49 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:09:49 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:09:49 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:09:49 --> Controller Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Config Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:10:28 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:10:28 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:10:28 --> URI Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Router Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Output Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Security Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Input Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:10:28 --> Language Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Loader Class Initialized
DEBUG - 2015-07-22 17:10:28 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:10:28 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:10:28 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:10:28 --> Controller Class Initialized
DEBUG - 2015-07-22 17:10:28 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:10:28 --> Final output sent to browser
DEBUG - 2015-07-22 17:10:28 --> Total execution time: 0.0097
DEBUG - 2015-07-22 17:10:30 --> Config Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:10:30 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:10:30 --> URI Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Router Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Output Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Security Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Input Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:10:30 --> Language Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Loader Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:10:30 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:10:30 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:10:30 --> Controller Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:10:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:11:08 --> Config Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:11:08 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:11:08 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:11:08 --> URI Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Router Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Output Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Security Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Input Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:11:08 --> Language Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Loader Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:11:08 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:11:08 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:11:08 --> Controller Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:11:08 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:14:11 --> Config Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:14:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:14:11 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:14:11 --> URI Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Router Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Output Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Security Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Input Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:14:11 --> Language Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Loader Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:14:11 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:14:11 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:14:11 --> Controller Class Initialized
DEBUG - 2015-07-22 17:14:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:14:21 --> Config Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:14:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:14:21 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:14:21 --> URI Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Router Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Output Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Security Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Input Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:14:21 --> Language Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Loader Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:14:21 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:14:21 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:14:21 --> Controller Class Initialized
DEBUG - 2015-07-22 17:14:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:14:21 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:14:21 --> Final output sent to browser
DEBUG - 2015-07-22 17:14:21 --> Total execution time: 0.0031
DEBUG - 2015-07-22 17:14:23 --> Config Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:14:23 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:14:23 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:14:23 --> URI Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Router Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Output Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Security Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Input Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:14:23 --> Language Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Loader Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:14:23 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:14:23 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:14:23 --> Controller Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:14:23 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:15:10 --> Config Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:15:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:15:10 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:15:10 --> URI Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Router Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Output Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Security Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Input Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:15:10 --> Language Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Loader Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:15:10 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:15:10 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:15:10 --> Controller Class Initialized
DEBUG - 2015-07-22 17:15:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:15:10 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:15:10 --> Final output sent to browser
DEBUG - 2015-07-22 17:15:10 --> Total execution time: 0.0199
DEBUG - 2015-07-22 17:15:39 --> Config Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:15:39 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:15:39 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:15:39 --> URI Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Router Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Output Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Security Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Input Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:15:39 --> Language Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Loader Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:15:39 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:15:39 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:15:39 --> Controller Class Initialized
DEBUG - 2015-07-22 17:15:39 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:16:19 --> Config Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:16:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:16:19 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:16:19 --> URI Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Router Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Output Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Security Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Input Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:16:19 --> Language Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Loader Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:16:19 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:16:19 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:16:19 --> Controller Class Initialized
DEBUG - 2015-07-22 17:16:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:16:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:16:19 --> Final output sent to browser
DEBUG - 2015-07-22 17:16:19 --> Total execution time: 0.0041
DEBUG - 2015-07-22 17:18:05 --> Config Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:18:05 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:18:05 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:18:05 --> URI Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Router Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Output Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Security Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Input Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:18:05 --> Language Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Loader Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:18:05 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:18:05 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:18:05 --> Controller Class Initialized
DEBUG - 2015-07-22 17:18:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:18:05 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:18:05 --> Final output sent to browser
DEBUG - 2015-07-22 17:18:05 --> Total execution time: 0.0072
DEBUG - 2015-07-22 17:19:45 --> Config Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:19:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:19:45 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:19:45 --> URI Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Router Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Output Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Security Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Input Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:19:45 --> Language Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Loader Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:19:45 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:19:45 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:19:45 --> Controller Class Initialized
DEBUG - 2015-07-22 17:19:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:19:45 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:19:45 --> Final output sent to browser
DEBUG - 2015-07-22 17:19:45 --> Total execution time: 0.0049
DEBUG - 2015-07-22 17:22:19 --> Config Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:22:19 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:22:19 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:22:19 --> URI Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Router Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Output Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Security Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Input Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:22:19 --> Language Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Loader Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:22:19 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:22:19 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:22:19 --> Controller Class Initialized
DEBUG - 2015-07-22 17:22:19 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:22:19 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:22:19 --> Final output sent to browser
DEBUG - 2015-07-22 17:22:19 --> Total execution time: 0.0048
DEBUG - 2015-07-22 17:22:21 --> Config Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:22:21 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:22:21 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:22:21 --> URI Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Router Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Output Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Security Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Input Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:22:21 --> Language Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Loader Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:22:21 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:22:21 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:22:21 --> Controller Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:22:21 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:25:32 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:32 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:32 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:32 --> Language Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Loader Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:25:32 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:25:32 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:25:32 --> Controller Class Initialized
DEBUG - 2015-07-22 17:25:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:25:32 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:25:32 --> Final output sent to browser
DEBUG - 2015-07-22 17:25:32 --> Total execution time: 0.0093
DEBUG - 2015-07-22 17:25:34 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:34 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:34 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:34 --> Language Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:42 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:42 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:42 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:42 --> Language Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Loader Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:25:42 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:25:42 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:25:42 --> Controller Class Initialized
DEBUG - 2015-07-22 17:25:42 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:25:42 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:25:42 --> Final output sent to browser
DEBUG - 2015-07-22 17:25:42 --> Total execution time: 0.0044
DEBUG - 2015-07-22 17:25:44 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:44 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:44 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:44 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:44 --> Language Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:56 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:56 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:56 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:56 --> Language Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Loader Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:25:56 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:25:56 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:25:56 --> Controller Class Initialized
DEBUG - 2015-07-22 17:25:56 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:25:56 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:25:56 --> Final output sent to browser
DEBUG - 2015-07-22 17:25:56 --> Total execution time: 0.0029
DEBUG - 2015-07-22 17:25:59 --> Config Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:25:59 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:25:59 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:25:59 --> URI Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Router Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Output Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Security Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Input Class Initialized
DEBUG - 2015-07-22 17:25:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:25:59 --> Language Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Config Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:28:24 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:28:24 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:28:24 --> URI Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Router Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Output Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Security Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Input Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:28:24 --> Language Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Loader Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:28:24 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:28:24 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:28:24 --> Controller Class Initialized
DEBUG - 2015-07-22 17:28:24 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:28:24 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:28:24 --> Final output sent to browser
DEBUG - 2015-07-22 17:28:24 --> Total execution time: 0.0026
DEBUG - 2015-07-22 17:28:26 --> Config Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:28:26 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:28:26 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:28:26 --> URI Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Router Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Output Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Security Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Input Class Initialized
DEBUG - 2015-07-22 17:28:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:28:26 --> Language Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Config Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:28:57 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:28:57 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:28:57 --> URI Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Router Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Output Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Security Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Input Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:28:57 --> Language Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Loader Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:28:57 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:28:57 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:28:57 --> Controller Class Initialized
DEBUG - 2015-07-22 17:28:57 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:28:57 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:28:57 --> Final output sent to browser
DEBUG - 2015-07-22 17:28:57 --> Total execution time: 0.0041
DEBUG - 2015-07-22 17:28:58 --> Config Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:28:58 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:28:58 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:28:58 --> URI Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Router Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Output Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Security Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Input Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:28:58 --> Language Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Loader Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:28:58 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:28:58 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:28:58 --> Controller Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:28:58 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:29:10 --> Config Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:29:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:29:10 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:29:10 --> URI Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Router Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Output Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Security Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Input Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:29:10 --> Language Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Loader Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:29:10 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:29:10 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:29:10 --> Controller Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:29:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:31:36 --> Config Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:31:36 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:31:36 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:31:36 --> URI Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Router Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Output Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Security Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Input Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:31:36 --> Language Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Loader Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:31:36 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:31:36 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:31:36 --> Controller Class Initialized
DEBUG - 2015-07-22 17:31:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:31:36 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:31:36 --> Final output sent to browser
DEBUG - 2015-07-22 17:31:36 --> Total execution time: 0.0068
DEBUG - 2015-07-22 17:31:37 --> Config Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:31:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:31:37 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:31:37 --> URI Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Router Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Output Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Security Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Input Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:31:37 --> Language Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Loader Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:31:37 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:31:37 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:31:37 --> Controller Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:31:37 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:38:47 --> Config Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:38:47 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:38:47 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:38:47 --> URI Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Router Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Output Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Security Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Input Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:38:47 --> Language Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Loader Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:38:47 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:38:47 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:38:47 --> Controller Class Initialized
DEBUG - 2015-07-22 17:38:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:38:47 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:38:47 --> Final output sent to browser
DEBUG - 2015-07-22 17:38:47 --> Total execution time: 0.0042
DEBUG - 2015-07-22 17:38:48 --> Config Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:38:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:38:48 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:38:48 --> URI Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Router Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Output Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Security Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Input Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:38:48 --> Language Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Loader Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:38:48 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:38:48 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:38:48 --> Controller Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:38:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:39:27 --> Config Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:39:27 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:39:27 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:39:27 --> URI Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Router Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Output Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Security Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Input Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:39:27 --> Language Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Loader Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:39:27 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:39:27 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:39:27 --> Controller Class Initialized
DEBUG - 2015-07-22 17:39:27 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:39:27 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:39:27 --> Final output sent to browser
DEBUG - 2015-07-22 17:39:27 --> Total execution time: 0.0027
DEBUG - 2015-07-22 17:39:29 --> Config Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:39:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:39:29 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:39:29 --> URI Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Router Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Output Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Security Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Input Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:39:29 --> Language Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Loader Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:39:29 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:39:29 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:39:29 --> Controller Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:39:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:51:29 --> Config Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:51:29 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:51:29 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:51:29 --> URI Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Router Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Output Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Security Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Input Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:51:29 --> Language Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Loader Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:51:29 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:51:29 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:51:29 --> Controller Class Initialized
DEBUG - 2015-07-22 17:51:29 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:51:29 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:51:29 --> Final output sent to browser
DEBUG - 2015-07-22 17:51:29 --> Total execution time: 0.0058
DEBUG - 2015-07-22 17:51:31 --> Config Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:51:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:51:31 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:51:31 --> URI Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Router Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Output Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Security Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Input Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:51:31 --> Language Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Loader Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:51:31 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:51:31 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:51:31 --> Controller Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:51:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:51:41 --> Config Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:51:41 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:51:41 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:51:41 --> URI Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Router Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Output Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Security Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Input Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:51:41 --> Language Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Loader Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:51:41 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:51:41 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:51:41 --> Controller Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:51:41 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:53:45 --> Config Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:53:45 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:53:45 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:53:45 --> URI Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Router Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Output Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Security Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Input Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:53:45 --> Language Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Loader Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:53:45 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:53:45 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:53:45 --> Controller Class Initialized
DEBUG - 2015-07-22 17:53:45 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:53:45 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:53:45 --> Final output sent to browser
DEBUG - 2015-07-22 17:53:45 --> Total execution time: 0.0532
DEBUG - 2015-07-22 17:53:46 --> Config Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:53:46 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:53:46 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:53:46 --> URI Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Router Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Output Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Security Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Input Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:53:46 --> Language Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Loader Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:53:46 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:53:46 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:53:46 --> Controller Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:53:46 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:53:55 --> Config Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:53:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:53:55 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:53:55 --> URI Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Router Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Output Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Security Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Input Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:53:55 --> Language Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Loader Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:53:55 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:53:55 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:53:55 --> Controller Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:53:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:54:28 --> Config Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:54:28 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:54:28 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:54:28 --> URI Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Router Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Output Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Security Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Input Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:54:28 --> Language Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Loader Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:54:28 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:54:28 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:54:28 --> Controller Class Initialized
DEBUG - 2015-07-22 17:54:28 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:54:28 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:54:28 --> Final output sent to browser
DEBUG - 2015-07-22 17:54:28 --> Total execution time: 0.0031
DEBUG - 2015-07-22 17:54:30 --> Config Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:54:30 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:54:30 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:54:30 --> URI Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Router Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Output Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Security Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Input Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:54:30 --> Language Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Loader Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:54:30 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:54:30 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:54:30 --> Controller Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:54:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:54:36 --> Config Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:54:36 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:54:36 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:54:36 --> URI Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Router Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Output Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Security Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Input Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:54:36 --> Language Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Loader Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:54:36 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:54:36 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:54:36 --> Controller Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:54:36 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:55:47 --> Config Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:55:47 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:55:47 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:55:47 --> URI Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Router Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Output Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Security Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Input Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:55:47 --> Language Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Loader Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:55:47 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:55:47 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:55:47 --> Controller Class Initialized
DEBUG - 2015-07-22 17:55:47 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:55:47 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:55:47 --> Final output sent to browser
DEBUG - 2015-07-22 17:55:47 --> Total execution time: 0.0045
DEBUG - 2015-07-22 17:55:48 --> Config Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:55:48 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:55:48 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:55:48 --> URI Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Router Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Output Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Security Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Input Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:55:48 --> Language Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Loader Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:55:48 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:55:48 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:55:48 --> Controller Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:55:48 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:55:55 --> Config Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:55:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:55:55 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:55:55 --> URI Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Router Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Output Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Security Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Input Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:55:55 --> Language Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Loader Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:55:55 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:55:55 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:55:55 --> Controller Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:55:55 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:57:00 --> Config Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:57:00 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:57:00 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:57:00 --> URI Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Router Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Output Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Security Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Input Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:57:00 --> Language Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Loader Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:57:00 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Session: Regenerate ID
DEBUG - 2015-07-22 17:57:00 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:57:00 --> Controller Class Initialized
DEBUG - 2015-07-22 17:57:00 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:57:00 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 17:57:00 --> Final output sent to browser
DEBUG - 2015-07-22 17:57:00 --> Total execution time: 0.0033
DEBUG - 2015-07-22 17:57:04 --> Config Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:57:04 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:57:04 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:57:04 --> URI Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Router Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Output Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Security Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Input Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:57:04 --> Language Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Loader Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:57:04 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:57:04 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:57:04 --> Controller Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:57:04 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 17:57:18 --> Config Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Hooks Class Initialized
DEBUG - 2015-07-22 17:57:18 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 17:57:18 --> Utf8 Class Initialized
DEBUG - 2015-07-22 17:57:18 --> URI Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Router Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Output Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Security Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Input Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 17:57:18 --> Language Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Loader Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Helper loaded: url_helper
DEBUG - 2015-07-22 17:57:18 --> CI_Session Class Initialized
DEBUG - 2015-07-22 17:57:18 --> CI_Session routines successfully run
DEBUG - 2015-07-22 17:57:18 --> Controller Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Database Driver Class Initialized
DEBUG - 2015-07-22 17:57:18 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:10:30 --> Config Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:10:30 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:10:30 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:10:30 --> URI Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Router Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Output Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Security Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Input Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:10:30 --> Language Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Loader Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:10:30 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Session: Regenerate ID
DEBUG - 2015-07-22 18:10:30 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:10:30 --> Controller Class Initialized
DEBUG - 2015-07-22 18:10:30 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:10:30 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 18:10:30 --> Final output sent to browser
DEBUG - 2015-07-22 18:10:30 --> Total execution time: 0.0044
DEBUG - 2015-07-22 18:10:31 --> Config Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:10:31 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:10:31 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:10:31 --> URI Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Router Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Output Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Security Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Input Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:10:31 --> Language Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Loader Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:10:31 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:10:31 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:10:31 --> Controller Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Database Driver Class Initialized
DEBUG - 2015-07-22 18:10:31 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:10:38 --> Config Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:10:38 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:10:38 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:10:38 --> URI Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Router Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Output Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Security Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Input Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:10:38 --> Language Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Loader Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:10:38 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:10:38 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:10:38 --> Controller Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Database Driver Class Initialized
DEBUG - 2015-07-22 18:10:38 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:25:10 --> Config Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:25:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:25:10 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:25:10 --> URI Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Router Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Output Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Security Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Input Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:25:10 --> Language Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Loader Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:25:10 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Session: Regenerate ID
DEBUG - 2015-07-22 18:25:10 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:25:10 --> Controller Class Initialized
DEBUG - 2015-07-22 18:25:10 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:25:10 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 18:25:10 --> Final output sent to browser
DEBUG - 2015-07-22 18:25:10 --> Total execution time: 0.0029
DEBUG - 2015-07-22 18:25:11 --> Config Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:25:11 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:25:11 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:25:11 --> URI Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Router Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Output Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Security Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Input Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:25:11 --> Language Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Loader Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:25:11 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:25:11 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:25:11 --> Controller Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Database Driver Class Initialized
DEBUG - 2015-07-22 18:25:11 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:25:17 --> Config Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:25:17 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:25:17 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:25:17 --> URI Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Router Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Output Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Security Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Input Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:25:17 --> Language Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Loader Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:25:17 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:25:17 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:25:17 --> Controller Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Database Driver Class Initialized
DEBUG - 2015-07-22 18:25:17 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:51:49 --> Config Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:51:49 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:51:49 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:51:49 --> URI Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Router Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Output Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Security Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Input Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:51:49 --> Language Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Loader Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:51:49 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Session: Regenerate ID
DEBUG - 2015-07-22 18:51:49 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:51:49 --> Controller Class Initialized
DEBUG - 2015-07-22 18:51:49 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:51:49 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 18:51:49 --> Final output sent to browser
DEBUG - 2015-07-22 18:51:49 --> Total execution time: 0.0032
DEBUG - 2015-07-22 18:51:51 --> Config Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:51:51 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:51:51 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:51:51 --> URI Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Router Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Output Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Security Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Input Class Initialized
DEBUG - 2015-07-22 18:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:51:51 --> Language Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Config Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:54:32 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:54:32 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:54:32 --> URI Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Router Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Output Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Security Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Input Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:54:32 --> Language Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Loader Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:54:32 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:54:32 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:54:32 --> Controller Class Initialized
DEBUG - 2015-07-22 18:54:32 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:54:32 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 18:54:32 --> Final output sent to browser
DEBUG - 2015-07-22 18:54:32 --> Total execution time: 0.0027
DEBUG - 2015-07-22 18:54:34 --> Config Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:54:34 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:54:34 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:54:34 --> URI Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Router Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Output Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Security Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Input Class Initialized
DEBUG - 2015-07-22 18:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:54:34 --> Language Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Config Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:55:05 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:55:05 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:55:05 --> URI Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Router Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Output Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Security Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Input Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:55:05 --> Language Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Loader Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Helper loaded: url_helper
DEBUG - 2015-07-22 18:55:05 --> CI_Session Class Initialized
DEBUG - 2015-07-22 18:55:05 --> CI_Session routines successfully run
DEBUG - 2015-07-22 18:55:05 --> Controller Class Initialized
DEBUG - 2015-07-22 18:55:05 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 18:55:05 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 18:55:05 --> Final output sent to browser
DEBUG - 2015-07-22 18:55:05 --> Total execution time: 0.0027
DEBUG - 2015-07-22 18:55:07 --> Config Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Hooks Class Initialized
DEBUG - 2015-07-22 18:55:07 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 18:55:07 --> Utf8 Class Initialized
DEBUG - 2015-07-22 18:55:07 --> URI Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Router Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Output Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Security Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Input Class Initialized
DEBUG - 2015-07-22 18:55:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 18:55:07 --> Language Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Config Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:39:10 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:39:10 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:39:10 --> URI Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Router Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Output Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Security Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Input Class Initialized
DEBUG - 2015-07-22 20:39:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:39:10 --> Language Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Config Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:39:37 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:39:37 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:39:37 --> URI Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Router Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Output Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Security Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Input Class Initialized
DEBUG - 2015-07-22 20:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:39:37 --> Language Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Config Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:40:13 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:40:13 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:40:13 --> URI Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Router Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Output Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Security Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Input Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:40:13 --> Language Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Loader Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Helper loaded: url_helper
DEBUG - 2015-07-22 20:40:13 --> CI_Session Class Initialized
DEBUG - 2015-07-22 20:40:13 --> CI_Session routines successfully run
DEBUG - 2015-07-22 20:40:13 --> Controller Class Initialized
DEBUG - 2015-07-22 20:40:13 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 20:40:13 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 20:40:13 --> Final output sent to browser
DEBUG - 2015-07-22 20:40:13 --> Total execution time: 0.0065
DEBUG - 2015-07-22 20:40:15 --> Config Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:40:15 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:40:15 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:40:15 --> URI Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Router Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Output Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Security Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Input Class Initialized
DEBUG - 2015-07-22 20:40:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:40:15 --> Language Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Config Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:40:53 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:40:53 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:40:53 --> URI Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Router Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Output Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Security Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Input Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:40:53 --> Language Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Loader Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Helper loaded: url_helper
DEBUG - 2015-07-22 20:40:53 --> CI_Session Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Session: Regenerate ID
DEBUG - 2015-07-22 20:40:53 --> CI_Session routines successfully run
DEBUG - 2015-07-22 20:40:53 --> Controller Class Initialized
DEBUG - 2015-07-22 20:40:53 --> Session has already been instantiated as 'session'. Second attempt aborted.
DEBUG - 2015-07-22 20:40:53 --> File loaded: /var/www/adwords/application/views/googleadwordsexam.php
DEBUG - 2015-07-22 20:40:53 --> Final output sent to browser
DEBUG - 2015-07-22 20:40:53 --> Total execution time: 0.0047
DEBUG - 2015-07-22 20:40:55 --> Config Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Hooks Class Initialized
DEBUG - 2015-07-22 20:40:55 --> UTF-8 Support Enabled
DEBUG - 2015-07-22 20:40:55 --> Utf8 Class Initialized
DEBUG - 2015-07-22 20:40:55 --> URI Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Router Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Output Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Security Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Input Class Initialized
DEBUG - 2015-07-22 20:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2015-07-22 20:40:55 --> Language Class Initialized
