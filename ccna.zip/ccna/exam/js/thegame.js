	
		
function gotoplay(url){
	var _name1=$('#username').val();
	var par={
		"username":_name1
		};
	//alert(url);
	
	$.ajax({
		data:par,
		url:url,
		type:'post',
		beforeSend:function(){
			$("#divplaying").html('<img src="<?=base_url()?>amilionaire/img/loader.gif" class="loadoing">');
			},
		success:function(result){
			//alert(result);
			$("#divplaying").html(result);
			}
		
		});
   // updateprize();
}

	function checkcorrect(answer,quest,num){
	
	 var txt=confirm('Is that your final anwser?');
	// alert(txt+" quest: "+quest+" answer:"+answer);
   
	if(txt==true){
		// go to check
		//alert("Entro aca");
		var par={
			"answer":answer,
			"quest":quest,
			"currentprize":num
			};
			var myurl="<?=base_url()?>index.php/ThegameAjaxAnswer";
			
		$.ajax({
			data:par,
			url:myurl,
			type:'POST',
			beforeSend:function(){
			$("#divplaying").html('<img src="<?=base_url()?>amilionaire/img/loader.gif" class="loadoing">');
			},
			success:function(result){
			// usar el resultado par sacar en pantalla el resultado	
			$('#divplaying').html(result);
			//buscar que valor hay okorno
			var goodid=$("#idgoodanswer").val();
			var yourid=$("#youranswer").val();
	
			if(yourid==goodid){
			$("#youranswer"+goodid).css("background-color","green");
			$('#ultakeaway').show();
			/*continue playing or takeaqy*/
			
			
			} else if(yourid!=goodid){
			$("#youranswer"+yourid).css("background-color","red");
			$("#erroranswer").show();
			}
			
			}
			});
		
	}else{
		$("#tdclassanswer"+num).css("background-color","");
	}
    
	 
}
	

	 
function continueplay(url){
	var numero=eval(document.getElementById("currentprize").value);
	//alert("continue play"+numero);
	///gotochangeprize(numero);
	var par={"currentprize":numero};
	$.ajax({
		data:par,
		url:url,
		type:'post',
		beforeSend:function(){
			$("#divplaying").html('<img src="<?=base_url()?>amilionaire/img/loader.gif" class="loadoing">');
			},
		success:function(result){
			//alert(result);
			$("#divplaying").html(result);
			}
		
		});

}	 	
 
 function take(){
	 location.reload();
	 }
 
	
function SendanEmail(){
	var _name=document.getElementById("name").value;
	var _email=document.getElementById("email").value;	
	var _subject=document.getElementById("subject").value;
	var _message=document.getElementById("message").value;
	var _par={"name":_name,"email":_email,"subject":_subject,"message":_message};
	var myurl="<?=base_url()?>index.php/Sendanemail";
	alert(myurl);
	$.ajax({
		data:_par,
		url:myurl,
		type:"post",
		beforeSend:function(){
		$("#sendemail").html('<img src="<?=base_url()?>amilionaire/img/loader.gif" class="loadoing">');
		},
		success:function(result){
		//alert(result);
		$("#sendemail").html(result);	
			}
		});

	
	}
